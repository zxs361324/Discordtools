# Discord Tools — مشروع Android

تطبيق أدوات مستقل بواجهة عربية مستوحاة من ألوان Discord. ليس تطبيقاً رسمياً من Discord ولا يتصل بحسابك.

## الأدوات الموجودة
- تحليل Discord Snowflake ID
- إنشاء Discord Timestamp
- منشئ روابط الدعوة
- حاسبة صلاحيات البوت
- مصمم Embed JSON
- محول HEX/RGB
- منشئ Webhook JSON (لا يرسل الرسائل)
- معاينة Markdown
- مخطط قنوات السيرفر
- رابط دعوة البوت OAuth2
- إنشاء رابط صورة المستخدم من Avatar Hash
- تحويل Unix Timestamp

## البناء إلى APK
يتطلب Android Studio أو Android SDK وJDK 17+ واتصالاً أولياً لتنزيل Android Gradle Plugin.

من مجلد المشروع:

```bash
gradle assembleDebug
```

أو افتح المجلد في Android Studio ثم اختر Build > Build APK(s).

الناتج المتوقع:
`app/build/outputs/apk/debug/app-debug.apk`

## ملاحظات
- minSdk 23 (Android 6.0+).
- معظم الأدوات تعمل دون إنترنت.
- لم يتم تضمين تسجيل دخول Discord أو أي تكامل API يتطلب OAuth/توكن.

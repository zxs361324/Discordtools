'use strict';
/* ============================================================
   chat.js — Discord-style live chat (gestures, replies, profile
   popup, emoji picker) + channel / member pickers
   Gestures:  swipe → (right) = reply · swipe ← (left) = mention
              long-press = edit own message (menu for others)
   ============================================================ */
function quoteReply(msg, o) {
  const name = displayName(msg.author, msg.member).replace(/[\[\]]/g, '');
  const jump = `https://discord.com/channels/${o.guildId || '@me'}/${o.channelId}/${msg.id}`;
  const snip = plainSnip(msg.content, 60) || 'مرفق';
  return `-# ↪ [${name}](${jump}) ${snip}`;
}

/* ---------------- profile popup ---------------- */
const BADGES = [[0, '🛠️ Discord Staff'], [1, '🤝 Partner'], [2, 'HypeSquad Events'], [3, '🐛 Bug Hunter'], [6, 'Bravery'], [7, 'Brilliance'], [8, 'Balance'], [9, '⭐ Early Supporter'], [14, '🐛 Bug Hunter 2'], [16, '✅ Verified Bot'], [17, 'Early Bot Dev'], [18, '🛡️ Mod Alumni'], [22, '💻 Active Developer']];
const roleCache = {};
function getRoles(token, gid) {
  if (!gid) return Promise.resolve([]);
  if (!roleCache[gid]) roleCache[gid] = dapi('GET', `/guilds/${gid}/roles`, { token }).catch(() => []);
  return roleCache[gid];
}
async function showProfile(p) {
  const u0 = p.user || {};
  const s = openSheet('', { title: '' });
  s.wrap.querySelector('.sheet').classList.add('prof-sheet');
  let user = u0, mem = null, roles = [];
  const draw = () => {
    const name = (mem && mem.nick) || user.global_name || user.username || 'مستخدم';
    const av = mem && mem.avatar ? memberAvatar(p.guildId, mem, 256) : userAvatar(user, 256);
    const accent = user.accent_color != null ? '#' + Number(user.accent_color).toString(16).padStart(6, '0') : '#5865f2';
    const banner = user.banner ? `url(${CDN}/banners/${user.id}/${user.banner}.${String(user.banner).startsWith('a_') ? 'gif' : 'png'}?size=600) center/cover` : accent;
    const flags = BigInt(user.public_flags || 0);
    const badges = BADGES.filter(([b]) => (flags >> BigInt(b)) & 1n).map(x => x[1]);
    if (user.bot || p.webhook) badges.unshift(p.webhook ? '🪝 ويبهوك' : '🤖 بوت');
    const myRoles = mem ? roles.filter(r => (mem.roles || []).includes(r.id) && r.name !== '@everyone').sort((a, b) => b.position - a.position) : [];
    const btn = (k, ic, t, cls) => `<button class="btn ${cls || 'sec'} sm" data-pf="${k}">${ic} ${t}</button>`;
    s.el.innerHTML = `<div class="prof"><div class="pbanner" style="background:${banner}"></div>
      <img class="pav" src="${esc(av)}" alt="">
      <div class="pbody"><div class="pname"><span class="uc">${esc(name)}</span></div><div class="puser">@<span class="uc">${esc(user.username || '')}</span> ${user.id ? '· ' + esc(user.id) : ''}</div>
      ${badges.length ? `<div class="pbadges">${badges.map(b => `<span class="pill"><span class="uc">${esc(b)}</span></span>`).join('')}</div>` : ''}
      <div class="pcard"><div class="plbl">عضو في ديسكورد منذ</div><div>${user.id ? new Date(snowflakeMs(user.id)).toLocaleDateString(LOC, { year: 'numeric', month: 'long', day: 'numeric' }) : '—'}</div>
      ${mem && mem.joined_at ? `<div class="plbl" style="margin-top:10px">انضم للسيرفر</div><div>${new Date(mem.joined_at).toLocaleDateString(LOC, { year: 'numeric', month: 'long', day: 'numeric' })}</div>` : ''}
      ${myRoles.length ? `<div class="plbl" style="margin-top:10px">الرتب</div><div class="proles">${myRoles.map(r => `<span class="role"><i style="background:${r.color ? embedColor(r.color) : '#80848e'}"></i><span class="uc">${esc(r.name)}</span></span>`).join('')}</div>` : ''}</div>
      <div class="pbtns">${p.onUse ? btn('use', '🎭', p.useLabel || 'استخدم هذه الهوية', 'green') : ''}${p.onMention ? btn('mention', '@', 'منشن', '') : ''}${p.onReply ? btn('reply', '↩️', 'رد', '') : ''}${p.onManage ? btn('manage', '🛡️', 'إدارة العضو', '') : ''}${user.id ? btn('copy', '🆔', 'نسخ المعرّف', '') : ''}</div></div></div>`;
    s.el.querySelectorAll('[data-pf]').forEach(b => b.onclick = () => {
      const k = b.dataset.pf;
      if (k === 'copy') return copyText(user.id);
      s.close();
      if (k === 'use') p.onUse({ name, avatar: av.replace(/size=\d+/, 'size=128'), id: user.id });
      else if (k === 'mention') p.onMention(user);
      else if (k === 'reply') p.onReply(user);
      else if (k === 'manage') p.onManage(user, mem);
    });
  };
  draw();
  if (p.token && !p.webhook && user.id) {
    try { user = Object.assign({}, user, await dapi('GET', `/users/${user.id}`, { token: p.token })); draw(); } catch (e) { /* optional */ }
    if (p.guildId) {
      try { mem = await dapi('GET', `/guilds/${p.guildId}/members/${user.id}`, { token: p.token }); roles = await getRoles(p.token, p.guildId); draw(); } catch (e) { /* not a member */ }
    }
  }
}

/* ---------------- emoji picker ---------------- */
const EMOJI_GROUPS = {
  '😀': '😀😃😄😁😆😅🤣😂🙂🙃😉😊😇🥰😍🤩😘😗😚😋😛😜🤪😝🤑🤗🤭🤫🤔🤐🤨😐😑😶😏😒🙄😬😮‍💨🤥😌😔😪🤤😴😷🤒🤕🤢🤮🥵🥶🥴😵🤯🤠🥳😎🤓🧐😕😟🙁😮😯😲😳🥺😦😧😨😰😥😢😭😱😖😣😞😓😩😫🥱😤😡😠🤬😈👿💀☠️💩🤡👹👺👻👽👾🤖',
  '👍': '👍👎👊✊🤛🤜👏🙌👐🤲🤝🙏✌️🤞🤟🤘👌🤌🤏👈👉👆👇☝️✋🤚🖐️🖖👋🤙💪🦾🖕✍️🤳💅👀👁️🧠🫀👄👅👂👃',
  '❤️': '❤️🧡💛💚💙💜🖤🤍🤎💔❣️💕💞💓💗💖💘💝💟☮️✝️☪️🕉️☸️✡️🔯☯️♈♉♊♋♌♍♎♏♐♑♒♓🆔⚛️',
  '🎉': '🎉🎊🎈🎁🏆🥇🥈🥉🏅🎖️🎯🎮🕹️🎲🧩🎨🎬🎤🎧🎼🎹🥁🎷🎺🎸🎻⚽🏀🏈⚾🎾🏐🏉🎱🏓🏸🥊🥋⛳🎣🤿🎿🛷',
  '🔥': '🔥✨⭐🌟💫⚡☄️💥🌈☀️🌤️⛅☁️🌧️⛈️❄️☃️🌙🌍🌎🌏💧🌊🍀🌹🌸🌼🌻🍁🍂🌴🌵🍎🍕🍔🍟🌭🍿🍩🍪🎂🍰☕🍺🍷',
  '⚙️': '⚙️🔧🔨🛠️⛏️🔩🧰🔑🔒🔓🔔🔕📢📣💬💭🗨️📌📍📎🖇️📝📁📂📅📆🗑️📊📈📉💻🖥️📱⌨️🖱️💾💿📷📹🔍🔎💡🔦🕯️💰💳💎⚖️🧪🔬🔭📡🛡️⚔️🏹✅❌⚠️🚫⛔❓❗💯🆗🆕🔴🟠🟡🟢🔵🟣⚫⚪'
};
const guildEmojiCache = {};
const EMOJI_CATS = [['😀', 'face', 'وجوه'], ['👍', 'hand', 'أشخاص'], ['❤️', 'heart', 'قلوب ورموز'], ['🎉', 'ball', 'أنشطة'], ['🔥', 'leaf', 'طبيعة وطعام'], ['⚙️', 'bulb', 'أشياء']];
const emojiList = str => typeof Intl.Segmenter === 'function' ? Array.from(new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(str), x => x.segment) : Array.from(str);
const emojiFace = e => (typeof Twemoji !== 'undefined' && Twemoji.enabled()) ? Twemoji.img(e) : e;
async function emojiSheet(insert, token, gid) {
  const s = openSheet(`<div class="ep"><div class="ep-search">${Icons.svg('search')}<input id="ep-q" type="search" placeholder="ابحث عن إيموجي" autocomplete="off" dir="auto"></div><div class="ep-body" id="ep-body"></div><div class="ep-bar" id="ep-bar"></div></div>`, { title: 'الإيموجي' });
  s.wrap.querySelector('.sheet').classList.add('ep-sheet');
  const body = $('#ep-body', s.el), bar = $('#ep-bar', s.el), q = $('#ep-q', s.el);
  const loaded = {}; let guilds = [], order = [];
  const secHTML = (id, title, inner, cls) => `<section class="ep-sec" data-sec="${esc(id)}"><div class="ep-t">${title}</div><div class="ep-g ${cls || ''}">${inner}</div></section>`;
  const srvInner = es => es.map(e => `<button data-c="${esc(`<${e.animated ? 'a' : ''}:${e.name}:${e.id}>`)}" data-n="${esc((e.name || '').toLowerCase())}" title="${esc(e.name)}"><img class="ce" loading="lazy" src="${CDN}/emojis/${e.id}.${e.animated ? 'gif' : 'webp'}?size=48" alt=""></button>`).join('');
  const addGuild = async g => {
    if (loaded[g.id]) return loaded[g.id];
    let es = guildEmojiCache[g.id];
    if (!es) { try { es = guildEmojiCache[g.id] = await dapi('GET', `/guilds/${g.id}/emojis`, { token }); } catch (e) { es = []; } }
    const el = document.createElement('div');
    el.innerHTML = secHTML('g' + g.id, `<span class="uc">${esc(g.name)}</span>`, es.length ? srvInner(es) : '<div class="empty" style="grid-column:1/-1;padding:8px">لا إيموجيات مخصصة هنا</div>');
    const node = el.firstElementChild;
    const firstStd = body.querySelector('[data-sec^="u"]');
    if (firstStd) body.insertBefore(node, firstStd); else body.appendChild(node);
    loaded[g.id] = node; return node;
  };
  const buildBar = () => {
    const gb = guilds.map(g => `<button class="ep-b" data-gb="${esc(g.id)}" title="${esc(g.name)}">${g.icon ? `<img src="${esc(guildIcon(g))}" alt="">` : `<span class="uc">${esc((g.name || '?')[0])}</span>`}</button>`).join('');
    bar.innerHTML = gb + (gb ? '<i class="ep-sep"></i>' : '') + EMOJI_CATS.map(c => `<button class="ep-b" data-cat="${esc(c[0])}" title="${esc(c[2])}">${Icons.svg(c[1])}</button>`).join('');
  };
  EMOJI_CATS.forEach(c => { body.insertAdjacentHTML('beforeend', secHTML('u' + c[0], c[2], emojiList(EMOJI_GROUPS[c[0]]).map(e => `<button data-c="${esc(e)}">${emojiFace(e)}</button>`).join(''), 'std')); });
  buildBar();
  if (!token) body.insertAdjacentHTML('afterbegin', '<div class="ep-hint">لعرض إيموجيات السيرفر سجّل دخول بوت من تبويب «البوتات» (يجب أن يكون في السيرفر). يمكنك أيضاً كتابة <code>&lt;:اسم:ID&gt;</code> يدوياً.</div>');
  else {
    try {
      guilds = await dapi('GET', '/users/@me/guilds', { token, query: { limit: 200 } }); emojiSheet.guilds = guilds;
      const cg = guilds.find(g => g.id === gid) || guilds[0];
      if (cg) { guilds = [cg].concat(guilds.filter(g => g !== cg)); await addGuild(cg); }
      buildBar();
    } catch (e) { body.insertAdjacentHTML('afterbegin', `<div class="ep-hint">⚠️ ${esc(e.message)}</div>`); }
  }
  const goto = el => { if (el) body.scrollTo({ top: el.offsetTop - body.offsetTop, behavior: 'smooth' }); };
  bar.onclick = async e => {
    const gb = e.target.closest('[data-gb]'), cb = e.target.closest('[data-cat]');
    q.value = ''; filter('');
    if (gb) { const node = await addGuild(guilds.find(g => g.id === gb.dataset.gb)); goto(node); }
    else if (cb) goto(body.querySelector(`[data-sec="${CSS.escape('u' + cb.dataset.cat)}"]`));
  };
  const filter = v => {
    v = v.trim().toLowerCase();
    body.querySelectorAll('.ep-sec').forEach(sec => {
      let any = false;
      sec.querySelectorAll('button[data-c]').forEach(b => { const ok = !v || (b.dataset.n || '').includes(v); b.style.display = ok ? '' : 'none'; if (ok) any = true; });
      sec.style.display = any ? '' : 'none';
    });
    let ne = body.querySelector('.ep-none');
    const shown = body.querySelectorAll('.ep-sec:not([style*="none"])').length;
    if (v && !shown) { if (!ne) body.insertAdjacentHTML('beforeend', '<div class="empty ep-none">لا نتائج — البحث بالاسم يعمل على إيموجيات السيرفر</div>'); } else if (ne) ne.remove();
  };
  q.addEventListener('input', async () => { if (q.value.trim() && token) { for (const g of guilds) await addGuild(g); } filter(q.value); });
  body.addEventListener('click', e => { const b = e.target.closest('button[data-c]'); if (b) insert(b.dataset.c); });
}

/* ---------------- ChatView ---------------- */
class ChatView {
  constructor(root, o) {
    this.o = o; this.root = root;
    this.msgs = []; this.reply = null; this.editing = null; this.files = [];
    this.sig = ''; this.first = true; this.timer = null; this.busy = false;
    this.ping = true; this.newCount = 0; this.lastId = null; this.skipClick = false; this.g = null;
    root.innerHTML = `<div class="chat">
      <div class="chat-list"></div>
      <button class="jump hidden" data-op="jump">⬇ رسائل جديدة</button>
      <div class="chat-hint hidden"></div>
      <div class="cbar">
        <div class="cctx hidden"></div>
        <div class="cfiles"></div>
        <div class="crow"><button class="cplus" data-op="attach" title="إرفاق">${Icons.svg('plus')}</button>
          <div class="cpill"><textarea rows="1" placeholder="${esc(o.placeholder || 'اكتب رسالة…')}" dir="auto"></textarea>
          <button class="ibtn cemo" data-op="emoji" title="إيموجي">${Icons.svg('smile')}</button></div>
          <button class="cact" data-op="send" title="إرسال">${Icons.svg('send')}</button></div>
        <div class="crec hidden"><button class="rdel" data-op="recx" title="حذف">${Icons.svg('trash')}</button><span class="rdot"></span><span class="rtime">0:00</span><span class="rwave"></span><button class="cact" data-op="recsend" title="إرسال">${Icons.svg('send')}</button></div>
      </div></div>`;
    this.list = $('.chat-list', root); this.hint = $('.chat-hint', root); this.ctxBar = $('.cctx', root);
    this.crow = $('.crow', root); this.rec = $('.crec', root); this.act = $('.cact', root); this.filesBar = $('.cfiles', root); this.ta = $('textarea', root); this.jumpBtn = $('.jump', root);
    this.fi = document.createElement('input');
    this.fi.type = 'file'; this.fi.multiple = true; this.fi.style.display = 'none';
    root.appendChild(this.fi);
    this.fi.addEventListener('change', () => { Array.from(this.fi.files || []).forEach(f => this.files.push(f)); this.fi.value = ''; this.drawFiles(); });
    this.ta.addEventListener('input', () => { autoGrow(this.ta); this.syncAct(); });
    this.syncAct();
    this.bindMentionPop();
    root.addEventListener('click', e => this.onClick(e));
    this.list.addEventListener('scroll', () => { if (this.nearBottom()) { this.newCount = 0; this.jumpBtn.classList.add('hidden'); } }, { passive: true });
    this.bindGestures();
  }
  nearBottom() { const L = this.list; return L.scrollHeight - L.scrollTop - L.clientHeight < 90; }
  start() {
    this.load();
    this.timer = setInterval(() => {
      if (document.hidden || !this.root.isConnected || this.root.offsetParent === null) return;
      this.load(true);
    }, this.o.intervalMs || 3500);
  }
  stop() { clearInterval(this.timer); this.timer = null; }

  /* ----- gestures: swipe right = reply, swipe left = mention, long-press = edit ----- */
  bindGestures() {
    const L = this.list, THRESH = 64;
    const reset = el => { if (el) { el.style.transform = ''; el.style.transition = 'transform .15s'; delete el.dataset.sw; setTimeout(() => { el.style.transition = ''; }, 170); } };
    L.addEventListener('pointerdown', e => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      const el = e.target.closest('.msg');
      if (!el || e.target.closest('[data-act],.att-img,.av,.un,.reply')) { this.g = null; return; }
      const g = this.g = { el, x: e.clientX, y: e.clientY, dx: 0, moved: false, long: false, dead: false };
      g.timer = setTimeout(() => { if (!g.moved && !g.dead) { g.long = true; try { navigator.vibrate && navigator.vibrate(18); } catch (er) { /* ignore */ } this.onLong(el); } }, 480);
    });
    L.addEventListener('pointermove', e => {
      const g = this.g; if (!g || g.dead || g.long) return;
      const dx = e.clientX - g.x, dy = e.clientY - g.y;
      if (!g.moved && Math.abs(dy) > 12 && Math.abs(dy) > Math.abs(dx)) { g.dead = true; clearTimeout(g.timer); return; }
      if (Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy)) {
        g.moved = true; clearTimeout(g.timer); g.dx = dx;
        g.el.style.transform = `translateX(${Math.max(-110, Math.min(110, dx))}px)`;
        g.el.dataset.sw = dx > 0 ? 'reply' : 'mention';
        g.el.classList.toggle('swarm', Math.abs(dx) > THRESH);
      }
    });
    const end = () => {
      const g = this.g; if (!g) return;
      clearTimeout(g.timer);
      const act = g.moved && Math.abs(g.dx) > THRESH ? (g.dx > 0 ? 'reply' : 'mention') : null;
      g.el.classList.remove('swarm'); reset(g.el);
      if (g.moved || g.long) { this.skipClick = true; setTimeout(() => { this.skipClick = false; }, 400); }
      const m = this.msgs.find(x => x.id === g.el.dataset.mid);
      this.g = null;
      if (act && m) { if (act === 'reply') this.setReply(m); else this.insertMention(m.author && m.author.id); }
    };
    L.addEventListener('pointerup', end);
    L.addEventListener('pointercancel', end);
    L.addEventListener('contextmenu', e => { if (e.target.closest('.msg')) e.preventDefault(); });
  }
  onLong(el) {
    const m = this.msgs.find(x => x.id === el.dataset.mid); if (!m) return;
    if (this.o.isMine(m)) this.setEditing(m); else this.openActions(m);
  }
  insertMention(id) {
    if (!id) return;
    const ta = this.ta, s = ta.selectionStart == null ? ta.value.length : ta.selectionStart, v = ta.value;
    const ins = `<@${id}> `;
    ta.value = v.slice(0, s) + ins + v.slice(ta.selectionEnd == null ? s : ta.selectionEnd);
    ta.focus(); ta.selectionStart = ta.selectionEnd = s + ins.length; autoGrow(ta);
    toast('تمت إضافة منشن', 'ok');
  }

  onClick(e) {
    if (this.skipClick) return;
    const op = e.target.closest('[data-op]');
    if (op) {
      const k = op.dataset.op;
      if (k === 'attach') this.pickFiles();
      else if (k === 'mic') this.startRec();
      else if (k === 'recx') this.stopRec(true);
      else if (k === 'recsend') this.stopRec(false);
      else if (k === 'send') this.doSend(op);
      else if (k === 'ctxclear') this.clearCtx();
      else if (k === 'ping') { this.ping = !this.ping; op.textContent = this.ping ? '@ تشغيل' : '@ إيقاف'; op.classList.toggle('off', !this.ping); }
      else if (k === 'rmfile') { this.files.splice(+op.dataset.i, 1); this.drawFiles(); }
      else if (k === 'jump') { this.list.scrollTop = this.list.scrollHeight; }
      else if (k === 'emoji') emojiSheet(t => { const ta = this.ta, s = ta.selectionStart == null ? ta.value.length : ta.selectionStart; ta.value = ta.value.slice(0, s) + t + ta.value.slice(ta.selectionEnd == null ? s : ta.selectionEnd); ta.selectionStart = ta.selectionEnd = s + t.length; autoGrow(ta); }, this.o.token, this.o.guildId);
      return;
    }
    const rx = e.target.closest('[data-rx]');
    if (rx) { this.toggleReaction(rx); return; }
    const im = e.target.closest('.att-img');
    if (im && !im.classList.contains('sp')) { lightbox(im.getAttribute('src')); return; }
    if (e.target.closest('[data-act]') || im) return;
    const jump = e.target.closest('[data-jump]');
    if (jump) { this.jumpTo(jump.dataset.jump); return; }
    const el = e.target.closest('.msg'); if (!el) return;
    const m = this.msgs.find(x => x.id === el.dataset.mid); if (!m) return;
    if (e.target.closest('.av,.un')) { this.openProfile(m); return; }
    this.openActions(m);
  }
  jumpTo(id) {
    const t = id && this.list.querySelector(`[data-mid="${id}"]`);
    if (!t) return toast('الرسالة الأصلية غير ظاهرة في المحادثة الحالية');
    t.scrollIntoView({ block: 'center', behavior: 'smooth' });
    t.classList.add('hl'); setTimeout(() => t.classList.remove('hl'), 1600);
  }
  openProfile(m) {
    const a = m.author || {}, o = this.o, pr = o.profile || {};
    showProfile({
      token: o.token, guildId: o.guildId, user: a, webhook: !!m.webhook_id,
      onUse: pr.onUse, useLabel: pr.useLabel,
      onMention: () => this.insertMention(a.id), onReply: () => this.setReply(m),
      onManage: pr.onManage && !m.webhook_id ? (u, mem) => pr.onManage(u, mem) : null
    });
  }

  async load(silent) {
    let list;
    try { list = await this.o.getMessages(); }
    catch (err) {
      if (!silent) this.list.innerHTML = `<div class="empty">⚠️ ${esc(err.message)}</div>`;
      else if (err.status === 401 || err.status === 403 || err.status === 404) { this.stop(); if (this.o.onFatal) this.o.onFatal(err); }
      return;
    }
    this.msgs = list.slice().reverse();
    const sig = this.msgs.map(m => m.id + ':' + (m.edited_timestamp || '') + ':' + (m.content || '').length + ':' + (m.reactions ? m.reactions.map(r => r.count).join(',') : '')).join('|');
    if (sig === this.sig) return;
    this.sig = sig;
    this.render();
  }
  render() {
    const L = this.list;
    const nb = this.first || this.nearBottom();
    const users = {};
    this.msgs.forEach(m => {
      if (m.author) users[m.author.id] = displayName(m.author, m.member);
      (m.mentions || []).forEach(u => { users[u.id] = displayName(u, u.member); });
    });
    const ctx = { users, channels: this.o.channelNames || {}, roles: this.o.roleNames || {} };
    let prev = null, html = '', pd = '';
    this.msgs.forEach(m => {
      const a = m.author || {}, d = new Date(m.timestamp), dk = isNaN(d) ? '' : d.toDateString();
      if (dk && dk !== pd) { html += `<div class="divider"><span><span class="uc">${esc(d.toLocaleDateString(LOC, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }))}</span></span></div>`; pd = dk; prev = null; }
      const compact = !!(prev && prev.author && prev.author.id === a.id && !!prev.webhook_id === !!m.webhook_id && !m.referenced_message && !parseQuoteReply(m.content) && !ReplyMap.get(m.id) &&
        (d - new Date(prev.timestamp)) < 420000 && m.type === 0 && prev.type === 0 && a.username === prev.author.username);
      if (m.type !== 0 && m.type !== 19 && m.type !== 20) html += `<div class="sys">• ${esc(this.sysText(m))}</div>`;
      else html += renderMessage(m, { compact, ctx });
      prev = m;
    });
    const lastId = this.msgs.length ? this.msgs[this.msgs.length - 1].id : null;
    const added = this.lastId && lastId !== this.lastId ? this.msgs.filter(m => BigInt(m.id) > BigInt(this.lastId)).length : 0;
    this.lastId = lastId;
    L.innerHTML = html || '<div class="empty">لا توجد رسائل بعد — ابدأ المحادثة 👋</div>';
    if (nb) { L.scrollTop = L.scrollHeight; this.newCount = 0; this.jumpBtn.classList.add('hidden'); }
    else if (added) { this.newCount += added; this.jumpBtn.textContent = `⬇ ${this.newCount} رسائل جديدة`; this.jumpBtn.classList.remove('hidden'); }
    this.first = false;
    const blank = this.msgs.filter(m => !(m.author && (m.author.bot || m.webhook_id)) && m.type === 0 && !m.content && !(m.attachments || []).length && !(m.embeds || []).length && !(m.sticker_items || []).length);
    if (blank.length >= 2) { this.hint.textContent = 'ℹ️ بعض رسائل الأعضاء تظهر فارغة: فعّل «Message Content Intent» للبوت من Developer Portal لقراءة نصوصها.'; this.hint.classList.remove('hidden'); }
    else this.hint.classList.add('hidden');
  }
  sysText(m) {
    const n = displayName(m.author, m.member);
    return { 7: n + ' انضم للسيرفر', 6: n + ' ثبّت رسالة', 8: 'تعزيز للسيرفر', 1: 'إضافة مستلم', 4: 'تغيير اسم القناة' }[m.type] || 'رسالة نظام';
  }

  openActions(m) {
    const o = this.o, mine = o.isMine(m);
    const items = [
      { icon: '↩️', label: 'رد', fn: () => this.setReply(m) },
      { icon: '@', label: 'منشن الكاتب', fn: () => this.insertMention(m.author && m.author.id) },
      mine && m.content !== undefined && { icon: '✏️', label: 'تعديل', fn: () => this.setEditing(m) },
      o.react && { icon: '😀', label: 'تفاعل', fn: () => this.reactPicker(m) },
      { icon: '👤', label: 'عرض الملف الشخصي', fn: () => this.openProfile(m) },
      { icon: '📋', label: 'نسخ النص', fn: () => copyText(m.content || '') },
      { icon: '🆔', label: 'نسخ معرّف الرسالة', fn: () => copyText(m.id) },
      { icon: '🔗', label: 'نسخ رابط الرسالة', fn: () => copyText(`https://discord.com/channels/${o.guildId || '@me'}/${o.channelId}/${m.id}`) },
      mine && { icon: '🗑️', label: 'حذف', cls: 'red', fn: () => this.doDelete(m, o.del) },
      !mine && o.botDel && { icon: '🗑️', label: 'حذف (بصلاحيات البوت)', cls: 'red', fn: () => this.doDelete(m, o.botDel) }
    ];
    menuSheet(clip(displayName(m.author, m.member) + ': ' + (m.content || '…'), 40), items);
  }
  async doDelete(m, fn) {
    if (!await confirmDlg('هل تريد حذف هذه الرسالة؟', { danger: true, ok: 'حذف' })) return;
    try { await fn(m); toast('تم الحذف', 'ok'); this.load(); } catch (e) { toast(e.message, 'bad'); }
  }
  async toggleReaction(span) {
    const el = span.closest('.msg'); const m = el && this.msgs.find(x => x.id === el.dataset.mid); if (!m) return;
    const key = span.dataset.rx; if (!key) return;
    try {
      if (span.classList.contains('me')) { if (this.o.unreact) await this.o.unreact(m, key); else return toast('إزالة التفاعل غير متاحة هنا'); }
      else if (this.o.react) await this.o.react(m, key);
      this.load(true);
    } catch (e) { toast(e.message, 'bad'); }
  }
  bindMentionPop() {
    const pop = document.createElement('div'); pop.className = 'mpop hidden'; this.ctxBar.parentNode.insertBefore(pop, this.ctxBar);
    let tm = null, seq = 0;
    const hide = () => { pop.classList.add('hidden'); pop.innerHTML = ''; };
    this.ta.addEventListener('input', () => {
      clearTimeout(tm);
      const ta = this.ta, pos = ta.selectionStart == null ? ta.value.length : ta.selectionStart, m = /(?:^|\s)@([^\s@<>]{1,32})$/.exec(ta.value.slice(0, pos));
      if (!m || !this.o.token || !this.o.guildId) { hide(); return; }
      const q = m[1], my = ++seq;
      tm = setTimeout(async () => {
        try {
          const r = await dapi('GET', `/guilds/${this.o.guildId}/members/search`, { token: this.o.token, query: { query: q, limit: 6 } });
          if (my !== seq) return;
          if (!r.length) { hide(); return; }
          pop.innerHTML = r.map((mem, i) => `<button data-i="${i}"><img src="${esc(memberAvatar(this.o.guildId, mem, 32))}" alt=""><b><span class="uc">${esc(displayName(mem.user, mem))}</span></b><small>@<span class="uc">${esc(mem.user.username)}</span></small></button>`).join('');
          pop.classList.remove('hidden');
          pop.querySelectorAll('button').forEach(b => b.onmousedown = ev => ev.preventDefault());
          pop.querySelectorAll('button').forEach(b => b.onclick = () => {
            const mem = r[+b.dataset.i], p2 = ta.selectionStart == null ? ta.value.length : ta.selectionStart, head = ta.value.slice(0, p2).replace(/@[^\s@<>]{1,32}$/, `<@${mem.user.id}> `);
            ta.value = head + ta.value.slice(p2); ta.focus(); ta.selectionStart = ta.selectionEnd = head.length; autoGrow(ta); hide();
          });
        } catch (e) { hide(); }
      }, 220);
    });
    this.ta.addEventListener('blur', () => setTimeout(hide, 150));
  }
  reactPicker(m) {
    const em = ['👍', '❤️', '😂', '😮', '😢', '🔥', '🎉', '✅', '❌', '👀'];
    const s = openSheet(`<div class="row wrap" style="justify-content:center;gap:10px">${em.map(x => `<button class="btn sec" style="font-size:24px;min-width:54px" data-e="${x}">${x}</button>`).join('')}</div>`, { title: 'اختر تفاعلاً' });
    s.el.querySelectorAll('[data-e]').forEach(b => b.onclick = async () => {
      s.close();
      try { await this.o.react(m, b.dataset.e); this.load(); } catch (e) { toast(e.message, 'bad'); }
    });
  }

  setReply(m) {
    this.editing = null; this.reply = m; this.ping = true;
    this.showCtx(`↩️ رد على <b><span class="uc">${esc(displayName(m.author, m.member))}</span></b>`, `<button class="pingtog" data-op="ping">@ تشغيل</button>`);
    this.ta.focus();
  }
  setEditing(m) {
    this.reply = null; this.editing = m;
    this.showCtx('✏️ <b>تعديل رسالة</b>');
    this.ta.value = (parseQuoteReply(m.content) ? parseQuoteReply(m.content).rest : m.content) || '';
    this.editPrefix = parseQuoteReply(m.content) ? m.content.slice(0, m.content.length - parseQuoteReply(m.content).rest.length) : '';
    autoGrow(this.ta); this.ta.focus();
  }
  showCtx(html, extra) {
    this.ctxBar.innerHTML = `<span>${html}</span>${extra || ''}<button class="x" data-op="ctxclear">✕</button>`;
    this.ctxBar.classList.remove('hidden'); this.crow.classList.add('ctx');
  }
  clearCtx() {
    if (this.editing) { this.ta.value = ''; autoGrow(this.ta); }
    this.reply = null; this.editing = null; this.editPrefix = '';
    this.ctxBar.classList.add('hidden'); this.crow.classList.remove('ctx');
  }
  syncAct() {
    const voice = !!(this.o.sendVoice && typeof Media !== 'undefined' && Media.canRecord());
    const empty = !this.ta.value.trim() && !this.files.length && !this.editing;
    const mic = voice && empty;
    this.act.dataset.op = mic ? 'mic' : 'send';
    this.act.innerHTML = Icons.svg(mic ? 'mic' : 'send'); this.act.classList.toggle('mic', mic);
  }
  async pickFiles() {
    try { const fs = await Media.pick({ max: 10 }); fs.forEach(f => this.files.push(f)); this.drawFiles(); }
    catch (e) { toast(e.message || String(e), 'bad'); }
  }
  async startRec() {
    if (this.recOn) return;
    const r = await Media.recStart();
    if (r !== 'ok') { toast(r === 'permission' ? 'لم تُمنح صلاحية المايك' : r === 'unsupported' ? 'الرسائل الصوتية تتطلب أندرويد 10 أو أحدث' : 'تعذر بدء التسجيل', 'bad'); return; }
    this.recOn = true; this.recT0 = Date.now();
    this.crow.classList.add('hidden'); this.rec.classList.remove('hidden');
    const w = $('.rwave', this.rec); w.innerHTML = '<i></i>'.repeat(26);
    const tm = $('.rtime', this.rec);
    this.recTick = setInterval(() => { const s = Math.floor((Date.now() - this.recT0) / 1000); tm.textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }, 250);
  }
  async stopRec(cancel) {
    if (!this.recOn) return;
    this.recOn = false; clearInterval(this.recTick);
    this.rec.classList.add('hidden'); this.crow.classList.remove('hidden');
    if (cancel) { Media.recCancel(); return; }
    if (this.busy) return;
    try {
      this.busy = true;
      const v = await Media.recStop();
      const rt = this.reply, local = rt && this.o.replyMode === 'local';
      const sent = await this.o.sendVoice({ voice: v, replyTo: local ? null : rt, ping: this.ping });
      if (local && sent && sent.id) ReplyMap.set(sent.id, { id: rt.id, name: displayName(rt.author, rt.member), av: userAvatar(rt.author, 32), snip: plainSnip(rt.content, 70) || 'مرفق' });
      this.clearCtx(); this.first = true; await this.load();
    } catch (e) { toast(e.message || String(e), 'bad'); }
    finally { this.busy = false; }
  }
  drawFiles() {
    this.syncAct();
    this.filesBar.innerHTML = this.files.map((f, i) => `<div class="cfile">📎 <span><span class="uc">${esc(f.name)}</span></span><button data-op="rmfile" data-i="${i}">✕</button></div>`).join('');
  }

  async doSend(btn) {
    if (this.busy) return;
    const text = this.ta.value.trim();
    try {
      this.busy = true;
      if (this.editing) {
        if (!text) { toast('النص فارغ'); return; }
        await withBusy(btn, () => this.o.edit(this.editing, (this.editPrefix || '') + text));
        this.clearCtx(); toast('تم التعديل', 'ok');
      } else {
        if (!text && !this.files.length) return;
        let out = text, replyTo = this.reply;
        const rt = replyTo, local = rt && this.o.replyMode === 'local';
        if (rt && this.o.replyMode === 'quote') {
          out = quoteReply(rt, this.o) + '\n' + (this.ping && rt.author ? `<@${rt.author.id}> ` : '') + text;
          replyTo = null;
        } else if (local) {
          out = (this.ping && rt.author ? `<@${rt.author.id}> ` : '') + text; replyTo = null;
        }
        const sent = await withBusy(btn, () => this.o.send({ text: out, files: this.files.slice(), replyTo, ping: this.ping }));
        if (local && sent && sent.id) ReplyMap.set(sent.id, { id: rt.id, name: displayName(rt.author, rt.member), av: userAvatar(rt.author, 32), snip: plainSnip(rt.content, 70) || 'مرفق' });
        this.ta.value = ''; autoGrow(this.ta); this.files = []; this.drawFiles(); this.clearCtx();
      }
      this.first = true;
      await this.load();
    } catch (e) { toast(e.message || String(e), 'bad'); }
    finally { this.busy = false; }
  }
}

/* ---------------- pickers ---------------- */
function pickChannel(token) {
  return new Promise(res => {
    let done = false;
    const s = openSheet(loadingHTML(), { title: 'اختر قناة', onClose: () => { if (!done) { done = true; res(null); } } });
    const fin = v => { done = true; s.close(); res(v); };
    const showGuilds = async () => {
      s.el.innerHTML = loadingHTML();
      try {
        const gs = await dapi('GET', '/users/@me/guilds', { token, query: { limit: 200 } });
        if (!gs.length) { s.el.innerHTML = '<div class="empty">البوت ليس في أي سيرفر. ادعُه أولاً.</div>'; return; }
        s.el.innerHTML = gs.map(g => `<button class="list-item" data-g="${esc(g.id)}">${g.icon ? `<img src="${esc(guildIcon(g))}" alt="">` : `<span class="ph"><span class="uc">${esc((g.name || '?')[0])}</span></span>`}<div><div class="n"><span class="uc">${esc(g.name)}</span></div></div></button>`).join('');
        s.el.querySelectorAll('[data-g]').forEach(b => b.onclick = () => showChannels(gs.find(x => x.id === b.dataset.g)));
      } catch (e) { s.el.innerHTML = `<div class="empty">⚠️ ${esc(e.message)}</div>`; }
    };
    const showChannels = async g => {
      s.el.innerHTML = loadingHTML();
      try {
        const chs = await dapi('GET', `/guilds/${g.id}/channels`, { token });
        const cats = chs.filter(c => c.type === 4).sort((a, b) => a.position - b.position);
        const text = chs.filter(c => c.type === 0 || c.type === 5).sort((a, b) => a.position - b.position);
        const groups = [{ name: '', items: text.filter(c => !c.parent_id || !cats.find(k => k.id === c.parent_id)) }]
          .concat(cats.map(k => ({ name: k.name, items: text.filter(c => c.parent_id === k.id) })));
        let h = `<button class="btn sec sm" data-back style="margin-bottom:8px">→ السيرفرات</button>`;
        groups.forEach(gr => {
          if (!gr.items.length) return;
          if (gr.name) h += `<div class="cat"><span class="uc">${esc(gr.name)}</span></div>`;
          h += gr.items.map(c => `<button class="chan" data-c="${esc(c.id)}"><span class="h">${c.type === 5 ? '📢' : '#'}</span><span class="uc">${esc(c.name)}</span></button>`).join('');
        });
        s.el.innerHTML = h + (text.length ? '' : '<div class="empty">لا توجد قنوات نصية ظاهرة للبوت</div>');
        s.el.querySelector('[data-back]').onclick = showGuilds;
        s.el.querySelectorAll('[data-c]').forEach(b => b.onclick = () => { const c = text.find(x => x.id === b.dataset.c); fin({ id: c.id, name: c.name, guild_id: g.id, guild_name: g.name }); });
      } catch (e) { s.el.innerHTML = `<div class="empty">⚠️ ${esc(e.message)}</div><button class="btn sec" data-back>رجوع</button>`; s.el.querySelector('[data-back]').onclick = showGuilds; }
    };
    showGuilds();
  });
}

async function lookupMember(token, guildId, id) {
  try { return await dapi('GET', `/guilds/${guildId}/members/${id}`, { token }); }
  catch (e) {
    if (e.status !== 404 && e.status !== 400) throw e;
    const u = await dapi('GET', `/users/${id}`, { token });
    return { user: u, nick: null, avatar: null, _notMember: true };
  }
}

function pickMember(token, guildId) {
  return new Promise(res => {
    let done = false;
    const s = openSheet(`<div class="field"><input type="text" class="ltr" placeholder="اسم العضو أو الـ ID" data-q></div><div data-out><div class="empty">اكتب للبحث</div></div>`,
      { title: 'اختيار عضو', onClose: () => { if (!done) { done = true; res(null); } } });
    const q = s.el.querySelector('[data-q]'), out = s.el.querySelector('[data-out]');
    let timer = null, seq = 0;
    const show = (members, extra) => {
      out.innerHTML = (extra || '') + (members.length ? members.map((m, i) => `<button class="list-item" data-i="${i}"><img src="${esc(memberAvatar(guildId, m, 64))}" alt=""><div><div class="n"><span class="uc">${esc(displayName(m.user, m))}</span></div><div class="s">@<span class="uc">${esc(m.user.username)}</span> · <span class="uc">${esc(m.user.id)}</span></div></div></button>`).join('') : '<div class="empty">لا نتائج</div>');
      out.querySelectorAll('[data-i]').forEach(b => b.onclick = () => { done = true; s.close(); res(members[+b.dataset.i]); });
    };
    const run = async () => {
      const v = q.value.trim(), my = ++seq;
      if (!v) { out.innerHTML = '<div class="empty">اكتب للبحث</div>'; return; }
      out.innerHTML = loadingHTML();
      try {
        let list = [];
        if (isId(v)) list = [await lookupMember(token, guildId, v)];
        else list = await dapi('GET', `/guilds/${guildId}/members/search`, { token, query: { query: v, limit: 15 } });
        if (my === seq) show(list, list[0] && list[0]._notMember ? '<div class="note info">هذا المستخدم ليس عضواً في السيرفر — سيُستخدم اسمه وصورته العامة.</div>' : '');
      } catch (e) { if (my === seq) out.innerHTML = `<div class="empty">⚠️ ${esc(e.message)}</div>`; }
    };
    q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(run, 350); });
    setTimeout(() => q.focus(), 80);
  });
}

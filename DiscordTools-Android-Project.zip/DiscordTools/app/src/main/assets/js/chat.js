'use strict';
/* ============================================================
   chat.js — reusable live chat view + channel / member pickers
   ============================================================ */
function quoteReply(msg, o) {
  const name = displayName(msg.author, msg.member).replace(/[\[\]]/g, '');
  const jump = `https://discord.com/channels/${o.guildId || '@me'}/${o.channelId}/${msg.id}`;
  const snip = clip((msg.content || '').replace(/<(@|#|a?:)[^>]*>/g, '').replace(/@(everyone|here)/g, '@​$1').replace(/\s+/g, ' '), 60) || '📎';
  return `> ↪ [${name}](${jump}) ${snip}`;
}

class ChatView {
  constructor(root, o) {
    this.o = o;
    this.root = root;
    this.msgs = [];
    this.reply = null;
    this.editing = null;
    this.files = [];
    this.sig = '';
    this.first = true;
    this.timer = null;
    this.busy = false;
    root.innerHTML = `<div class="chat">
      <div class="chat-list"></div>
      <div class="chat-hint hidden"></div>
      <div class="cbar">
        <div class="cctx hidden"></div>
        <div class="cfiles"></div>
        <div class="crow"><button class="ibtn" data-op="attach" title="إرفاق">＋</button>
          <textarea rows="1" placeholder="اكتب رسالة…" dir="auto"></textarea>
          <button class="ibtn send" data-op="send" title="إرسال">➤</button></div>
      </div></div>`;
    this.list = $('.chat-list', root);
    this.hint = $('.chat-hint', root);
    this.ctxBar = $('.cctx', root);
    this.crow = $('.crow', root);
    this.filesBar = $('.cfiles', root);
    this.ta = $('textarea', root);
    this.fi = document.createElement('input');
    this.fi.type = 'file';
    this.fi.multiple = true;
    this.fi.style.display = 'none';
    root.appendChild(this.fi);
    this.fi.addEventListener('change', () => {
      Array.from(this.fi.files || []).forEach(f => this.files.push(f));
      this.fi.value = '';
      this.drawFiles();
    });
    this.ta.addEventListener('input', () => autoGrow(this.ta));
    root.addEventListener('click', e => this.onClick(e));
  }

  start() {
    this.load();
    this.timer = setInterval(() => {
      if (document.hidden || !this.root.isConnected || this.root.offsetParent === null) return;
      this.load(true);
    }, this.o.intervalMs || 3500);
  }
  stop() { clearInterval(this.timer); this.timer = null; }

  onClick(e) {
    const op = e.target.closest('[data-op]');
    if (op) {
      const k = op.dataset.op;
      if (k === 'attach') this.fi.click();
      else if (k === 'send') this.doSend(op);
      else if (k === 'ctxclear') this.clearCtx();
      else if (k === 'rmfile') { this.files.splice(+op.dataset.i, 1); this.drawFiles(); }
      return;
    }
    if (e.target.closest('[data-act]') || e.target.closest('.att-img')) return;
    const el = e.target.closest('.msg');
    if (!el) return;
    const m = this.msgs.find(x => x.id === el.dataset.mid);
    if (m) this.openActions(m);
  }

  async load(silent) {
    let list;
    try { list = await this.o.getMessages(); }
    catch (err) {
      if (!silent) { this.list.innerHTML = `<div class="empty">⚠️ ${esc(err.message)}</div>`; }
      else if (err.status === 401 || err.status === 403 || err.status === 404) { this.stop(); if (this.o.onFatal) this.o.onFatal(err); }
      return;
    }
    this.msgs = list.slice().reverse();
    const sig = this.msgs.map(m => m.id + ':' + (m.edited_timestamp || '') + ':' + (m.content || '').length + ':' + (m.reactions ? m.reactions.map(r => r.count).join(',') : '')).join('|');
    if (sig === this.sig) return;
    this.sig = sig;
    this.render();
  }

  render() {
    const L = this.list;
    const nearBottom = this.first || (L.scrollHeight - L.scrollTop - L.clientHeight < 90);
    const users = {};
    this.msgs.forEach(m => {
      if (m.author) users[m.author.id] = displayName(m.author, m.member);
      (m.mentions || []).forEach(u => { users[u.id] = displayName(u, u.member); });
    });
    const ctx = { users, channels: this.o.channelNames || {}, roles: this.o.roleNames || {} };
    let prev = null, html = '';
    this.msgs.forEach(m => {
      const a = m.author || {};
      const compact = !!(prev && prev.author && prev.author.id === a.id && !!prev.webhook_id === !!m.webhook_id &&
        !m.referenced_message && (new Date(m.timestamp) - new Date(prev.timestamp)) < 420000 && m.type === 0 && prev.type === 0 &&
        (a.username === prev.author.username));
      if (m.type !== 0 && m.type !== 19 && m.type !== 20) {
        html += `<div class="sys">• ${esc(this.sysText(m))}</div>`;
      } else {
        html += renderMessage(m, { compact, ctx });
      }
      prev = m;
    });
    L.innerHTML = html || '<div class="empty">لا توجد رسائل بعد — ابدأ المحادثة 👋</div>';
    if (nearBottom) L.scrollTop = L.scrollHeight;
    this.first = false;
    const blank = this.msgs.filter(m => !(m.author && (m.author.bot || m.webhook_id)) && m.type === 0 && !m.content && !(m.attachments || []).length && !(m.embeds || []).length && !(m.sticker_items || []).length);
    if (blank.length >= 2) {
      this.hint.textContent = 'ℹ️ بعض رسائل الأعضاء تظهر فارغة: فعّل «Message Content Intent» للبوت من Developer Portal لقراءة نصوصها.';
      this.hint.classList.remove('hidden');
    } else this.hint.classList.add('hidden');
  }
  sysText(m) {
    const n = displayName(m.author, m.member);
    return { 7: n + ' انضم للسيرفر', 6: n + ' ثبّت رسالة', 8: 'تعزيز للسيرفر', 1: 'إضافة مستلم', 4: 'تغيير اسم القناة' }[m.type] || 'رسالة نظام';
  }

  openActions(m) {
    const o = this.o, mine = o.isMine(m);
    const items = [
      { icon: '↩️', label: 'رد', fn: () => this.setReply(m) },
      mine && m.content !== undefined && { icon: '✏️', label: 'تعديل', fn: () => this.setEditing(m) },
      o.react && { icon: '😀', label: 'تفاعل', fn: () => this.reactPicker(m) },
      { icon: '📋', label: 'نسخ النص', fn: () => copyText(m.content || '') },
      { icon: '🆔', label: 'نسخ ID الرسالة', fn: () => copyText(m.id) },
      { icon: '🔗', label: 'نسخ رابط الرسالة', fn: () => copyText(`https://discord.com/channels/${o.guildId || '@me'}/${o.channelId}/${m.id}`) },
      mine && { icon: '🗑️', label: 'حذف', cls: 'red', fn: () => this.doDelete(m, o.del) },
      !mine && o.botDel && { icon: '🗑️', label: 'حذف (بصلاحيات البوت)', cls: 'red', fn: () => this.doDelete(m, o.botDel) }
    ];
    menuSheet(clip(displayName(m.author, m.member) + ': ' + (m.content || '…'), 40), items);
  }
  async doDelete(m, fn) {
    if (!await confirmDlg('هل تريد حذف هذه الرسالة؟', { danger: true, ok: 'حذف' })) return;
    try { await fn(m); toast('تم الحذف', 'ok'); this.load(); }
    catch (e) { toast(e.message, 'bad'); }
  }
  reactPicker(m) {
    const em = ['👍', '❤️', '😂', '😮', '😢', '🔥', '🎉', '✅', '❌', '👀'];
    const s = openSheet(`<div class="row wrap" style="justify-content:center;gap:10px">${em.map(x => `<button class="btn sec" style="font-size:24px;min-width:54px" data-e="${x}">${x}</button>`).join('')}</div>`, { title: 'اختر تفاعلاً' });
    s.el.querySelectorAll('[data-e]').forEach(b => b.onclick = async () => {
      s.close();
      try { await this.o.react(m, b.dataset.e); this.load(); } catch (e) { toast(e.message, 'bad'); }
    });
  }

  setReply(m) {
    this.editing = null;
    this.reply = m;
    this.showCtx(`↩️ رد على <b>${esc(displayName(m.author, m.member))}</b>: ${esc(clip((m.content || '📎').replace(/\n/g, ' '), 40))}`);
    this.ta.focus();
  }
  setEditing(m) {
    this.reply = null;
    this.editing = m;
    this.showCtx('✏️ <b>تعديل رسالة</b>');
    this.ta.value = m.content || '';
    autoGrow(this.ta);
    this.ta.focus();
  }
  showCtx(html) {
    this.ctxBar.innerHTML = `<span>${html}</span><button class="x" data-op="ctxclear">✕</button>`;
    this.ctxBar.classList.remove('hidden');
    this.crow.classList.add('ctx');
  }
  clearCtx() {
    if (this.editing) { this.ta.value = ''; autoGrow(this.ta); }
    this.reply = null;
    this.editing = null;
    this.ctxBar.classList.add('hidden');
    this.crow.classList.remove('ctx');
  }
  drawFiles() {
    this.filesBar.innerHTML = this.files.map((f, i) => `<div class="cfile">📎 <span>${esc(f.name)}</span><button data-op="rmfile" data-i="${i}">✕</button></div>`).join('');
  }

  async doSend(btn) {
    if (this.busy) return;
    const text = this.ta.value.trim();
    try {
      this.busy = true;
      if (this.editing) {
        if (!text) { toast('النص فارغ'); return; }
        await withBusy(btn, () => this.o.edit(this.editing, text));
        this.clearCtx();
        toast('تم التعديل', 'ok');
      } else {
        if (!text && !this.files.length) return;
        let out = text, replyTo = this.reply;
        if (replyTo && this.o.replyMode === 'quote') { out = quoteReply(replyTo, this.o) + '\n' + text; replyTo = null; }
        await withBusy(btn, () => this.o.send({ text: out, files: this.files.slice(), replyTo }));
        this.ta.value = '';
        autoGrow(this.ta);
        this.files = [];
        this.drawFiles();
        this.clearCtx();
      }
      this.first = true;
      await this.load();
    } catch (e) { toast(e.message || String(e), 'bad'); }
    finally { this.busy = false; }
  }
}

/* ---------------- pickers ---------------- */
function pickChannel(token) {
  return new Promise(res => {
    let done = false;
    const s = openSheet(loadingHTML(), { title: 'اختر قناة', onClose: () => { if (!done) { done = true; res(null); } } });
    const fin = v => { done = true; s.close(); res(v); };
    const showGuilds = async () => {
      s.el.innerHTML = loadingHTML();
      try {
        const gs = await dapi('GET', '/users/@me/guilds', { token, query: { limit: 200 } });
        if (!gs.length) { s.el.innerHTML = '<div class="empty">البوت ليس في أي سيرفر. ادعُه أولاً.</div>'; return; }
        s.el.innerHTML = gs.map(g => `<button class="list-item" data-g="${esc(g.id)}">${g.icon ? `<img src="${esc(guildIcon(g))}" alt="">` : `<span class="ph">${esc((g.name || '?')[0])}</span>`}<div><div class="n">${esc(g.name)}</div></div></button>`).join('');
        s.el.querySelectorAll('[data-g]').forEach(b => b.onclick = () => showChannels(gs.find(x => x.id === b.dataset.g)));
      } catch (e) { s.el.innerHTML = `<div class="empty">⚠️ ${esc(e.message)}</div>`; }
    };
    const showChannels = async g => {
      s.el.innerHTML = loadingHTML();
      try {
        const chs = await dapi('GET', `/guilds/${g.id}/channels`, { token });
        const cats = chs.filter(c => c.type === 4).sort((a, b) => a.position - b.position);
        const text = chs.filter(c => c.type === 0 || c.type === 5).sort((a, b) => a.position - b.position);
        const groups = [{ name: '', items: text.filter(c => !c.parent_id || !cats.find(k => k.id === c.parent_id)) }]
          .concat(cats.map(k => ({ name: k.name, items: text.filter(c => c.parent_id === k.id) })));
        let h = `<button class="btn sec sm" data-back style="margin-bottom:8px">→ السيرفرات</button>`;
        groups.forEach(gr => {
          if (!gr.items.length) return;
          if (gr.name) h += `<div class="cat">${esc(gr.name)}</div>`;
          h += gr.items.map(c => `<button class="chan" data-c="${esc(c.id)}"><span class="h">${c.type === 5 ? '📢' : '#'}</span>${esc(c.name)}</button>`).join('');
        });
        s.el.innerHTML = h + (text.length ? '' : '<div class="empty">لا توجد قنوات نصية ظاهرة للبوت</div>');
        s.el.querySelector('[data-back]').onclick = showGuilds;
        s.el.querySelectorAll('[data-c]').forEach(b => b.onclick = () => {
          const c = text.find(x => x.id === b.dataset.c);
          fin({ id: c.id, name: c.name, guild_id: g.id, guild_name: g.name });
        });
      } catch (e) { s.el.innerHTML = `<div class="empty">⚠️ ${esc(e.message)}</div><button class="btn sec" data-back>رجوع</button>`; s.el.querySelector('[data-back]').onclick = showGuilds; }
    };
    showGuilds();
  });
}

async function lookupMember(token, guildId, id) {
  try { return await dapi('GET', `/guilds/${guildId}/members/${id}`, { token }); }
  catch (e) {
    if (e.status !== 404 && e.status !== 400) throw e;
    const u = await dapi('GET', `/users/${id}`, { token });
    return { user: u, nick: null, avatar: null, _notMember: true };
  }
}

function pickMember(token, guildId) {
  return new Promise(res => {
    let done = false;
    const s = openSheet(`<div class="field"><input type="text" class="ltr" placeholder="اسم العضو أو الـ ID" data-q></div><div data-out><div class="empty">اكتب للبحث</div></div>`,
      { title: 'اختيار عضو', onClose: () => { if (!done) { done = true; res(null); } } });
    const q = s.el.querySelector('[data-q]'), out = s.el.querySelector('[data-out]');
    let timer = null, seq = 0;
    const show = (members, extra) => {
      out.innerHTML = (extra || '') + (members.length ? members.map((m, i) => `<button class="list-item" data-i="${i}"><img src="${esc(memberAvatar(guildId, m, 64))}" alt=""><div><div class="n">${esc(displayName(m.user, m))}</div><div class="s">@${esc(m.user.username)} · ${esc(m.user.id)}</div></div></button>`).join('') : '<div class="empty">لا نتائج</div>');
      out.querySelectorAll('[data-i]').forEach(b => b.onclick = () => { done = true; s.close(); res(members[+b.dataset.i]); });
    };
    const run = async () => {
      const v = q.value.trim(), my = ++seq;
      if (!v) { out.innerHTML = '<div class="empty">اكتب للبحث</div>'; return; }
      out.innerHTML = loadingHTML();
      try {
        let list = [];
        if (isId(v)) { list = [await lookupMember(token, guildId, v)]; }
        else list = await dapi('GET', `/guilds/${guildId}/members/search`, { token, query: { query: v, limit: 15 } });
        if (my === seq) show(list, list[0] && list[0]._notMember ? '<div class="note info">هذا المستخدم ليس عضواً في السيرفر — سيُستخدم اسمه وصورته العامة.</div>' : '');
      } catch (e) { if (my === seq) out.innerHTML = `<div class="empty">⚠️ ${esc(e.message)}</div>`; }
    };
    q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(run, 350); });
    setTimeout(() => q.focus(), 80);
  });
}

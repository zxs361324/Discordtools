'use strict';
/* ============================================================
   media.js — in-app gallery picker, voice recorder, Discord-style emoji images
   ============================================================ */

/* ---------- Emoji images (Twemoji, the set Discord uses) ---------- */
const Twemoji = (() => {
  const BASE = 'https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/72x72/';
  const RE = /(?:\p{RI}\p{RI}|[#*0-9]️?⃣|\p{Extended_Pictographic}(?:️|\p{EMod})?(?:‍\p{Extended_Pictographic}(?:️|\p{EMod})?)*)/gu;
  const enabled = () => settings.all.emojiImages !== false;
  const code = s => {
    const t = s.indexOf('‍') < 0 ? s.replace(/️/g, '') : s;
    return Array.from(t, c => c.codePointAt(0).toString(16)).join('-');
  };
  const url = s => BASE + code(s) + '.png';
  const img = (s, cls) => `<img class="emoji${cls ? ' ' + cls : ''}" draggable="false" alt="${esc(s)}" src="${url(s)}">`;
  /* html: already escaped markup. Only text outside tags and outside <code>/<pre> is converted. */
  function html(h) {
    if (!enabled() || !h) return h;
    let depth = 0;
    return h.split(/(<[^>]+>)/).map(part => {
      if (part.charAt(0) === '<') {
        if (/^<(code|pre)[\s>]/i.test(part)) depth++;
        else if (/^<\/(code|pre)>/i.test(part)) depth = Math.max(0, depth - 1);
        return part;
      }
      return depth ? part : part.replace(RE, m => img(m));
    }).join('');
  }
  document.addEventListener('error', e => {
    const t = e.target;
    if (t && t.tagName === 'IMG' && t.classList && t.classList.contains('emoji')) t.replaceWith(document.createTextNode(t.alt || ''));
  }, true);
  return { html, img, url, RE, enabled };
})();

/* ---------- Gallery + files + voice ---------- */
const Media = (() => {
  const HOST = 'https://appmedia.local';
  const N = () => (window.Native && typeof Native.listMedia === 'function') ? Native : null;
  const waits = {};
  window.__permResp = (id, ok) => { const f = waits[id]; if (f) { delete waits[id]; f(ok === true || ok === 'true'); } };
  const askPerm = fn => new Promise(res => {
    const id = uid(); waits[id] = res; Native[fn](id);
    setTimeout(() => { if (waits[id]) { delete waits[id]; res(false); } }, 90000);
  });

  function systemFiles(accept) {
    return new Promise(res => {
      const i = document.createElement('input');
      i.type = 'file'; i.multiple = true; if (accept) i.accept = accept; i.style.display = 'none';
      document.body.appendChild(i);
      const done = list => { i.remove(); res(list); };
      i.addEventListener('change', () => done(Array.from(i.files || [])));
      i.addEventListener('cancel', () => done([]));
      i.click();
    });
  }

  const fetchFile = async it => {
    const r = await fetch(`${HOST}/f/${it.video ? 'v' : 'i'}/${it.id}`);
    if (!r.ok) throw new Error('تعذر قراءة الملف');
    const b = await r.blob();
    return new File([b], it.name || 'media', { type: it.mime || b.type });
  };

  async function pick(opts) {
    opts = opts || {};
    const max = opts.max || 10;
    if (!N()) return systemFiles();
    let ok = false;
    try { ok = N().hasMedia(); } catch (e) { ok = false; }
    if (!ok) {
      ok = await askPerm('askMedia');
      if (!ok) { toast('لم تُمنح صلاحية الصور — يمكنك اختيار الملفات', 'bad'); return systemFiles(); }
    }
    return new Promise(resolve => {
      const sel = []; let offset = 0, loading = false, end = false, settled = false;
      const finish = v => { if (!settled) { settled = true; resolve(v); } };
      const s = openSheet(`<div class="mg-top"><button class="btn sec sm" data-mg="files">${Icons.svg('folder')} الملفات</button><span class="mg-note" id="mg-n"></span></div><div class="mg" id="mg"></div><div class="mg-foot hidden" id="mg-f"><button class="btn block" id="mg-ok"></button></div>`, { title: 'الصور والفيديو', onClose: () => finish([]) });
      s.wrap.querySelector('.sheet').classList.add('mg-sheet');
      const grid = $('#mg', s.el), foot = $('#mg-f', s.el), ok2 = $('#mg-ok', s.el);
      const items = [];
      const sync = () => {
        grid.querySelectorAll('.mc').forEach(b => {
          const n = sel.indexOf(items[+b.dataset.i]);
          b.classList.toggle('on', n >= 0); b.querySelector('.mk').textContent = n >= 0 ? String(n + 1) : '';
        });
        foot.classList.toggle('hidden', !sel.length); ok2.textContent = `إرسال ${sel.length} ${sel.length === 1 ? 'ملف' : 'ملفات'}`;
      };
      const more = () => {
        if (loading || end) return; loading = true;
        let list = [];
        try { list = JSON.parse(N().listMedia(offset, 60) || '[]'); } catch (e) { list = []; }
        if (list.length < 60) end = true;
        offset += list.length;
        const base = items.length;
        list.forEach(it => items.push(it));
        grid.insertAdjacentHTML('beforeend', list.map((it, k) => `<button class="mc" data-i="${base + k}"><img loading="lazy" alt="" src="${HOST}/t/${it.video ? 'v' : 'i'}/${it.id}">${it.video ? `<span class="mv">${Icons.svg('play')}</span>` : ''}<span class="mk"></span></button>`).join(''));
        if (!items.length) grid.innerHTML = '<div class="empty" style="grid-column:1/-1">لا توجد صور على الجهاز</div>';
        loading = false;
      };
      grid.addEventListener('click', e => {
        const b = e.target.closest('.mc'); if (!b) return;
        const it = items[+b.dataset.i], i = sel.indexOf(it);
        if (i >= 0) sel.splice(i, 1); else if (sel.length < max) sel.push(it); else toast(`الحد الأقصى ${max} ملفات`);
        sync();
      });
      grid.addEventListener('scroll', () => { if (grid.scrollHeight - grid.scrollTop - grid.clientHeight < 400) { more(); sync(); } }, { passive: true });
      s.el.querySelector('[data-mg=files]').onclick = async () => { settled = true; s.close(); resolve(await systemFiles()); };
      ok2.onclick = async () => {
        ok2.disabled = true;
        try { const out = []; for (const it of sel) out.push(await fetchFile(it)); settled = true; s.close(); resolve(out); }
        catch (e) { ok2.disabled = false; toast(e.message, 'bad'); }
      };
      more(); sync();
    });
  }

  /* ----- voice ----- */
  const canRecord = () => !!(window.Native && typeof Native.recStart === 'function');
  async function recStart() {
    if (!canRecord()) return 'unsupported';
    let ok = false;
    try { ok = Native.hasMic(); } catch (e) { ok = false; }
    if (!ok) { ok = await askPerm('askMic'); if (!ok) return 'permission'; }
    return Native.recStart();
  }
  async function recStop() {
    const r = JSON.parse(Native.recStop(false) || '{}');
    if (!r.ok) throw new Error('فشل التسجيل');
    if (r.duration < 0.6) throw new Error('التسجيل قصير جداً');
    const resp = await fetch(`${HOST}/r/voice-message.ogg`); if (!resp.ok) throw new Error('تعذر قراءة التسجيل');
    const blob = await resp.blob();
    return { file: new File([blob], 'voice-message.ogg', { type: 'audio/ogg' }), duration: Math.max(1, Math.round(r.duration * 10) / 10), waveform: r.waveform };
  }
  function recCancel() { try { Native.recStop(true); } catch (e) { /* ignore */ } }

  /* Build the multipart body Discord expects for a voice message */
  async function voiceJson(v, extra) {
    return { json: Object.assign({ flags: 8192, attachments: [{ id: 0, filename: 'voice-message.ogg', duration_secs: v.duration, waveform: v.waveform }] }, extra || {}), files: await filesPayload([v.file]) };
  }
  return { pick, systemFiles, canRecord, recStart, recStop, recCancel, voiceJson };
})();

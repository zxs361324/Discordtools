'use strict';
/* ============================================================
   render.js — Discord-flavoured markdown + message/embed renderer
   Everything is escaped first; never inject raw user HTML.
   ============================================================ */
function fmtTs(t, f) {
  const d = new Date(t * 1000), L = LOC;
  try {
    switch (f) {
      case 't': return d.toLocaleTimeString(L, { hour: 'numeric', minute: '2-digit' });
      case 'T': return d.toLocaleTimeString(L);
      case 'd': return d.toLocaleDateString(L);
      case 'D': return d.toLocaleDateString(L, { dateStyle: 'long' });
      case 'F': return d.toLocaleString(L, { dateStyle: 'full', timeStyle: 'short' });
      case 'R': return relTime(t);
      default: return d.toLocaleString(L, { dateStyle: 'long', timeStyle: 'short' });
    }
  } catch (e) { return d.toString(); }
}
function relTime(t) {
  const s = t - Math.floor(Date.now() / 1000), a = Math.abs(s);
  const u = [[31536000, 'year'], [2592000, 'month'], [86400, 'day'], [3600, 'hour'], [60, 'minute'], [1, 'second']];
  for (const [n, name] of u) {
    if (a >= n || n === 1) {
      const v = Math.round(s / n);
      try { return new Intl.RelativeTimeFormat(LOC, { numeric: 'auto' }).format(v, name); }
      catch (e) { return v + ' ' + name; }
    }
  }
  return '';
}

function md(src, ctx) {
  ctx = ctx || {};
  const tokens = [];
  const stash = h => { tokens.push(h); return '\u0000' + (tokens.length - 1) + '\u0000'; };
  let s = String(src == null ? '' : src);

  s = s.replace(/```(?:([\w+-]+)\n)?([\s\S]*?)```/g, (m, lang, code) =>
    stash(`<pre class="codeblock"><code>${esc(code.replace(/^\n+|\n+$/g, ''))}</code></pre>`));
  s = s.replace(/``([^`]+?)``|`([^`\n]+?)`/g, (m, a, b) => stash(`<code class="inline">${esc(a || b)}</code>`));
  s = esc(s);

  s = s.replace(/&lt;(a?):(\w{2,32}):(\d{15,25})&gt;/g, (m, an, name, id) =>
    stash(`<img class="emoji" alt=":${name}:" src="${CDN}/emojis/${id}.${an ? 'gif' : 'webp'}?size=48&amp;quality=lossless">`));
  s = s.replace(/&lt;@!?(\d{15,25})&gt;/g, (m, id) => stash(`<span class="mention">@${esc((ctx.users && ctx.users[id]) || 'مستخدم')}</span>`));
  s = s.replace(/&lt;@&amp;(\d{15,25})&gt;/g, (m, id) => stash(`<span class="mention">@${esc((ctx.roles && ctx.roles[id]) || 'رتبة')}</span>`));
  s = s.replace(/&lt;#(\d{15,25})&gt;/g, (m, id) => stash(`<span class="mention">#${esc((ctx.channels && ctx.channels[id]) || 'قناة')}</span>`));
  s = s.replace(/@(everyone|here)\b/g, m => stash(`<span class="mention">${m}</span>`));
  s = s.replace(/&lt;t:(-?\d{1,13})(?::([tTdDfFR]))?&gt;/g, (m, t, f) => stash(`<span class="ts">${esc(fmtTs(Number(t), f || 'f'))}</span>`));

  s = s.replace(/\[([^\]\n]+)\]\((https?:\/\/(?:[^\s)&]|&amp;)+)\)/g, (m, t, u) =>
    stash(`<a class="lnk" data-act="open" data-url="${u}">${t}</a>`));
  s = s.replace(/(https?:\/\/(?:[^\s&<\u0000]|&amp;)+)/g, (m, u) => {
    let tail = '';
    const mm = u.match(/[.,!?;:)\]]+$/);
    if (mm) { tail = mm[0]; u = u.slice(0, -tail.length); }
    return stash(`<a class="lnk" data-act="open" data-url="${u}">${u}</a>`) + tail;
  });

  const inline = t => {
    t = t.replace(/\|\|([\s\S]+?)\|\|/g, (m, a) => `<span class="spoiler" data-act="spoiler">${a}</span>`);
    t = t.replace(/\*\*\*([\s\S]+?)\*\*\*/g, '<b><i>$1</i></b>');
    t = t.replace(/\*\*([\s\S]+?)\*\*/g, '<b>$1</b>');
    t = t.replace(/__([\s\S]+?)__/g, '<u>$1</u>');
    t = t.replace(/(^|[^\w*])\*(?!\s)([^*\n]+?)\*(?!\w)/g, '$1<i>$2</i>');
    t = t.replace(/(^|[^\w])_(?!\s)([^_\n]+?)_(?!\w)/g, '$1<i>$2</i>');
    t = t.replace(/~~([\s\S]+?)~~/g, '<s>$1</s>');
    return t;
  };

  const lines = s.split('\n');
  let res = '', prevText = false, i = 0, m;
  const block = h => { res += h; prevText = false; };
  const text = h => { if (prevText) res += '<br>'; res += h; prevText = true; };
  while (i < lines.length) {
    const ln = lines[i];
    if ((m = ln.match(/^&gt;&gt;&gt; ?([\s\S]*)$/))) {
      block(`<blockquote>${[m[1]].concat(lines.slice(i + 1)).map(inline).join('<br>')}</blockquote>`);
      break;
    }
    if (/^&gt; ?/.test(ln)) {
      const q = [];
      while (i < lines.length && /^&gt; ?/.test(lines[i])) { q.push(lines[i].replace(/^&gt; ?/, '')); i++; }
      block(`<blockquote>${q.map(inline).join('<br>')}</blockquote>`);
      continue;
    }
    if ((m = ln.match(/^(#{1,3}) (.+)$/))) { block(`<div class="h${m[1].length}">${inline(m[2])}</div>`); i++; continue; }
    if ((m = ln.match(/^-# (.+)$/))) { block(`<div class="sub">${inline(m[1])}</div>`); i++; continue; }
    if ((m = ln.match(/^\s*[-*] (.+)$/))) { block(`<div class="li">${inline(m[1])}</div>`); i++; continue; }
    if ((m = ln.match(/^\s*(\d+)\. (.+)$/))) { block(`<div class="li"><span class="num">${m[1]}.</span> ${inline(m[2])}</div>`); i++; continue; }
    text(inline(ln));
    i++;
  }
  for (let k = 0; k < 4; k++) res = res.replace(/\u0000(\d+)\u0000/g, (mm, n) => tokens[+n] != null ? tokens[+n] : '');
  return res;
}

function embedColor(c) {
  if (c == null || c === '' || isNaN(Number(c))) return '#1e1f22';
  return '#' + (Number(c) & 0xFFFFFF).toString(16).padStart(6, '0');
}
function resolveImg(u, ctx) {
  if (!u) return '';
  if (/^attachment:\/\//i.test(u)) { const n = decodeURIComponent(u.slice(13)); return (ctx && ctx.attachmentUrls && ctx.attachmentUrls[n]) || ''; }
  return safeUrl(u);
}
function renderEmbed(e, ctx) {
  const thumb = resolveImg(e.thumbnail && (e.thumbnail.proxy_url || e.thumbnail.url), ctx);
  let h = `<div class="embed ${thumb ? 'hasthumb' : ''}" style="border-left-color:${embedColor(e.color)}"><div class="embed-in">`;
  if (e.provider && e.provider.name && !e.author) h += `<div class="sub">${esc(e.provider.name)}</div>`;
  if (e.author && e.author.name) {
    const ic = resolveImg(e.author.icon_url, ctx);
    const nm = safeUrl(e.author.url) ? `<a class="lnk" style="color:inherit;text-decoration:none" data-act="open" data-url="${esc(e.author.url)}">${esc(e.author.name)}</a>` : esc(e.author.name);
    h += `<div class="e-author">${ic ? `<img src="${esc(ic)}" alt="">` : ''}<span>${nm}</span></div>`;
  }
  if (e.title) h += `<div class="e-title" dir="auto">${safeUrl(e.url) ? `<a data-act="open" data-url="${esc(e.url)}">${esc(e.title)}</a>` : esc(e.title)}</div>`;
  if (e.description) h += `<div class="e-desc">${md(e.description, ctx)}</div>`;
  if (e.fields && e.fields.length) {
    h += '<div class="e-fields">' + e.fields.map(f => `<div class="e-field ${f.inline ? 'inl' : ''}"><div class="fn" dir="auto">${esc(f.name)}</div><div class="fv">${md(f.value, ctx)}</div></div>`).join('') + '</div>';
  }
  const img = resolveImg(e.image && (e.image.proxy_url || e.image.url), ctx);
  if (img) h += `<img class="e-img" src="${esc(img)}" alt="">`;
  if (e.video && e.video.url && !img) h += `<div class="sub">🎞 ${esc(clip(e.video.url, 60))}</div>`;
  if (e.footer && e.footer.text || e.timestamp) {
    const ic = resolveImg(e.footer && e.footer.icon_url, ctx);
    const parts = [];
    if (e.footer && e.footer.text) parts.push(esc(e.footer.text));
    if (e.timestamp) { const d = new Date(e.timestamp); if (!isNaN(d)) parts.push(esc(d.toLocaleString(LOC))); }
    h += `<div class="e-foot">${ic ? `<img src="${esc(ic)}" alt="">` : ''}<span dir="auto">${parts.join(' • ')}</span></div>`;
  }
  if (thumb) h += `<img class="e-thumb" src="${esc(thumb)}" alt="">`;
  return h + '</div></div>';
}

function fmtSize(n) {
  n = Number(n) || 0;
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}
function renderComponents(rows) {
  if (!rows || !rows.length) return '';
  return rows.map(r => {
    if (!r || !Array.isArray(r.components)) return '';
    return '<div class="btnrow">' + r.components.map(c => {
      if (c.type === 2) {
        const emoji = c.emoji && c.emoji.name ? esc(c.emoji.name) + ' ' : '';
        if (c.style === 5 && safeUrl(c.url)) return `<button class="dbtn link" data-act="open" data-url="${esc(c.url)}">${emoji}${esc(c.label || '')} <span style="opacity:.7">↗</span></button>`;
        const cls = { 1: 'p', 2: '', 3: 's', 4: 'd' }[c.style] || '';
        return `<span class="dbtn ${cls} off">${emoji}${esc(c.label || '')}</span>`;
      }
      return `<span class="dbtn off">${esc(c.placeholder || '▾ قائمة')}</span>`;
    }).join('') + '</div>';
  }).join('');
}

function msgTime(ts) {
  const d = new Date(ts);
  if (isNaN(d)) return '';
  const now = new Date();
  const t = d.toLocaleTimeString(LOC, { hour: '2-digit', minute: '2-digit' });
  return d.toDateString() === now.toDateString() ? t : d.toLocaleDateString(LOC) + ' ' + t;
}
const ReplyMap = (() => {
  let m = null;
  const load = () => { if (!m) { try { m = store.get('reply_map', {}); } catch (e) { m = {}; } } return m; };
  return {
    get: id => load()[id] || null,
    set: (id, v) => { const o = load(); o[id] = v; const ks = Object.keys(o); if (ks.length > 300) ks.slice(0, ks.length - 300).forEach(k => delete o[k]); store.set('reply_map', o); }
  };
})();
function plainSnip(t, n) {
  let x = String(t || '').replace(/```[\s\S]*?```/g, ' [كود] ').replace(/<a?:(\w+):\d+>/g, ':$1:').replace(/<t:(\d+)(?::[a-zA-Z])?>/g, '').replace(/<(@&?|#)!?\d+>/g, '').replace(/\[([^\]]+)\]\([^)]+\)/g, '$1').replace(/https?:\/\/\S+/g, 'رابط').replace(/[*_~`|>#]+/g, '').replace(/\s+/g, ' ').trim();
  return x.length > (n || 60) ? x.slice(0, (n || 60) - 1) + '…' : x;
}
function parseQuoteReply(content) {
  const m = /^(?:-# |> )↪ \[([^\]\n]*)\]\((https?:\/\/[^)\s]+)\) ?([^\n]*)(?:\n|$)([\s\S]*)$/.exec(content || '');
  if (!m) return null;
  const idm = /\/(\d{15,25})$/.exec(m[2]);
  return { name: m[1], url: m[2], id: idm ? idm[1] : null, snip: m[3], rest: m[4] };
}
function renderMessage(m, o) {
  o = o || {};
  const a = m.author || {};
  const name = o.name || (m.member && m.member.nick) || a.global_name || a.username || 'مستخدم';
  const av = o.avatar || userAvatar(a, 64);
  const isApp = !!(m.webhook_id || a.bot || o.app);
  const compact = !!o.compact;
  let h = `<div class="msg ${compact ? 'compact' : 'first'}" data-mid="${esc(m.id || '')}"><img class="av" data-uid="${esc(a.id || '')}" src="${esc(av)}" alt="">`;
  h += '<div class="mb">';
  if (!compact) h += `<div class="mh"><span class="un" data-uid="${esc(a.id || '')}">${esc(name)}</span>${isApp ? '<span class="tag">APP</span>' : ''}<time>${esc(m.timestamp ? msgTime(m.timestamp) : (o.timeLabel || ''))}</time></div>`;
  const ref = m.referenced_message;
  const qr = !ref ? parseQuoteReply(m.content) : null;
  const lr = !ref && !qr && m.id ? ReplyMap.get(m.id) : null;
  if (ref && ref.author) h += `<div class="reply" data-jump="${esc(ref.id || '')}"><img src="${esc(userAvatar(ref.author, 32))}" alt=""><b>${esc(displayName(ref.author, ref.member))}</b><span dir="auto">${esc(plainSnip(ref.content, 70) || 'مرفق')}</span></div>`;
  else if (lr) h += `<div class="reply" data-jump="${esc(lr.id || '')}">${lr.av ? `<img src="${esc(lr.av)}" alt="">` : ''}<b>@${esc(lr.name)}</b><span dir="auto">${esc(lr.snip || '')}</span></div>`;
  else if (qr) h += `<div class="reply" data-jump="${esc(qr.id || '')}"><b>@${esc(qr.name)}</b><span dir="auto">${esc(clip(qr.snip, 70))}</span></div>`;
  const body = qr ? qr.rest : m.content;
  if (body) h += `<div class="mcontent" dir="auto">${md(body, o.ctx)}${m.edited_timestamp ? '<span class="edited">(معدّلة)</span>' : ''}</div>`;
  (m.attachments || []).forEach(at => {
    const url = at.proxy_url || at.url || at.blobUrl || '';
    const sp = /^SPOILER_/i.test(at.filename || '');
    if (/^image\//.test(at.content_type || '') && url) h += `<img class="att-img ${sp ? 'sp' : ''}" src="${esc(url)}" alt="" ${sp ? 'data-act="unblur"' : ''}>`;
    else h += `<div class="att-file"><span>📄</span><div><div>${esc(at.filename || 'ملف')}</div><small>${fmtSize(at.size)}</small></div></div>`;
  });
  (m.embeds || []).forEach(e => { h += renderEmbed(e, o.ctx); });
  (m.sticker_items || []).forEach(st => { h += `<div class="att-file">🏷 ${esc(st.name)}</div>`; });
  h += renderComponents(m.components);
  if (m.reactions && m.reactions.length) {
    h += '<div class="rx">' + m.reactions.map(r => `<span class="${r.me ? 'me' : ''}" data-rx="${esc(r.emoji && r.emoji.id ? r.emoji.name + ':' + r.emoji.id : ((r.emoji && r.emoji.name) || ''))}">${r.emoji && r.emoji.id ? `<img class="emoji" src="${CDN}/emojis/${r.emoji.id}.webp?size=32" alt="">` : esc((r.emoji && r.emoji.name) || '')} ${r.count}</span>`).join('') + '</div>';
  }
  return h + '</div></div>';
}

registerActions({
  open: t => openLink(t.dataset.url),
  spoiler: t => t.classList.toggle('open'),
  unblur: t => t.classList.remove('sp')
});

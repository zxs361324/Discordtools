'use strict';
/* ============================================================
   app.js — shell: tabs, settings, back handling, startup
   ============================================================ */
const App = (() => {
  const TABS = [
    ['tools', '🧰', 'الأدوات', Tools],
    ['composer', '✉️', 'المرسل', Composer],
    ['session', '🎭', 'الجلسة', Session],
    ['bots', '🤖', 'البوتات', Bots]
  ];
  let cur = 'tools';
  const mounted = {};
  const flexTabs = {};

  function goTab(id) {
    cur = id;
    TABS.forEach(([k, , , mod]) => {
      const v = $('#v-' + k);
      v.classList.toggle('hidden', k !== id);
      $('#tab-' + k).classList.toggle('on', k === id);
      if (k === id && !mounted[k]) { mounted[k] = true; mod.mount(v); }
    });
  }
  function settingsSheet() {
    const st = settings.all;
    const s = openSheet(`
      <label class="switch"><span>السماح بـ @everyone والرتب في رسائلك<br><small class="sub">الافتراضي: منشن الأعضاء فقط (أكثر أماناً)</small></span><input type="checkbox" id="st-ev" ${st.allowEveryone ? 'checked' : ''}></label>
      <label class="switch"><span>تذكّر التوكن والوجهة على الجهاز</span><input type="checkbox" id="st-rem" ${st.remember ? 'checked' : ''}></label>
      <div class="field"><label>سرعة تحديث المحادثة</label><select id="st-poll"><option value="2500">سريع (2.5 ث)</option><option value="3500">عادي (3.5 ث)</option><option value="6000">موفّر (6 ث)</option></select></div>
      <button class="btn red block" id="st-clear">🧹 مسح كل البيانات المحفوظة</button>
      <p class="sub" style="margin-top:14px;text-align:center">Discord Tools 2.0 · تطبيق مستقل وليس تطبيقاً رسمياً من Discord<br>البيانات (التوكنات والويبهوكات) تُخزَّن على جهازك فقط.</p>`, { title: '⚙️ الإعدادات' });
    $('#st-poll', s.el).value = String(st.pollMs);
    $('#st-ev', s.el).onchange = e => settings.set('allowEveryone', e.target.checked);
    $('#st-rem', s.el).onchange = e => { settings.set('remember', e.target.checked); if (!e.target.checked) { Tokens.clear(); } };
    $('#st-poll', s.el).onchange = e => settings.set('pollMs', +e.target.value);
    $('#st-clear', s.el).onclick = async () => {
      if (await confirmDlg('سيتم مسح التوكنات والقوالب والمسودات والسجل. الويبهوكات المعلّقة تبقى لتتمكن من حذفها. متابعة؟', { danger: true, ok: 'مسح' })) {
        const keep = Pending.all(); store.clear(); store.set('pending_hooks', keep); s.close(); toast('تم المسح — أعد فتح التطبيق', 'ok');
      }
    };
  }
  function back() {
    if (closeTopSheet()) return true;
    const mod = TABS.find(t => t[0] === cur)[3];
    if (mounted[cur] && mod.back && mod.back()) return true;
    if (cur !== 'tools') { goTab('tools'); return true; }
    return false;
  }
  function init() {
    $('#tabs').innerHTML = TABS.map(([k, e, l]) => `<button id="tab-${k}" data-act="app.tab" data-t="${k}"><span class="e">${e}</span>${l}</button>`).join('');
    $('#views').innerHTML = TABS.map(([k]) => `<div id="v-${k}" class="view hidden"></div>`).join('');
    registerActions({ 'app.tab': t => goTab(t.dataset.t), 'app.settings': settingsSheet });
    goTab('tools');
  }
  window.__back = back;
  window.addEventListener('unhandledrejection', e => { const m = e.reason && e.reason.message; if (m) toast(m, 'bad'); });
  return { init, goTab };
})();
App.init();

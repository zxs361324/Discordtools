'use strict';
/* ============================================================
   app.js — shell: tabs, settings, back handling, startup
   ============================================================ */
const App = (() => {
  const TABS = [
    ['tools', '<path d="M14.5 5.5a4 4 0 0 0-5 5L4 16l4 4 5.5-5.5a4 4 0 0 0 5-5l-3 3-3-1-1-3z"/>', 'الأدوات', Tools],
    ['composer', '<path d="M21 4 3 11l7 3 3 7zM10 14l11-10"/>', 'المرسل', Composer],
    ['session', '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.5-4 3-6 6.5-6s6 2 6.5 6M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2 .6 3.3 2.5 3.5 6"/>', 'الجلسة', Session],
    ['bots', '<rect x="4" y="8" width="16" height="11" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9.5 16.5h5"/>', 'البوتات', Bots]
  ];
  let cur = 'tools';
  const mounted = {};
  const flexTabs = {};

  function goTab(id) {
    cur = id;
    TABS.forEach(([k, , , mod]) => {
      const v = $('#v-' + k);
      v.classList.toggle('hidden', k !== id);
      $('#tab-' + k).classList.toggle('on', k === id);
      if (k === id && !mounted[k]) { mounted[k] = true; mod.mount(v); }
    });
  }
  /* ---------- preferences engine ---------- */
  const ACCENTS = [['#5865f2', 'بلوربل'], ['#23a55a', 'أخضر'], ['#eb459e', 'وردي'], ['#f0b232', 'ذهبي'], ['#e67e22', 'برتقالي'], ['#1abc9c', 'تركواز'], ['#f23f43', 'أحمر'], ['#9b59b6', 'بنفسجي']];
  function shade(hex, f) { const n = parseInt(hex.slice(1), 16); const c = i => Math.max(0, Math.min(255, Math.round(((n >> i) & 255) * f))); return '#' + [16, 8, 0].map(i => c(i).toString(16).padStart(2, '0')).join(''); }
  function applyPrefs() {
    const st = settings.all, r = document.documentElement, b = document.body;
    const ac = /^#[0-9a-f]{6}$/i.test(st.accent) ? st.accent : '#5865f2';
    r.style.setProperty('--brand', ac); r.style.setProperty('--brand2', shade(ac, .82)); r.style.setProperty('--mention', ac);
    const dark = window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches;
    const light = st.theme === 'light' || (st.theme === 'auto' && !dark);
    r.dataset.theme = light ? 'light' : 'dark';
    const mt = document.querySelector('meta[name=theme-color]'); const barc = light ? '#ffffff' : '#1a191e'; if (mt) mt.content = barc;
    try { if (NATIVE && NATIVE.setBars && applyPrefs.last !== barc) NATIVE.setBars(barc, light); applyPrefs.last = barc; } catch (e) { /* ignore */ }
    const z = Math.max(80, Math.min(150, +st.zoom || 100)) / 100;
    b.style.setProperty('--z', z); b.classList.toggle('zoomed', z !== 1);
    b.classList.toggle('compact-ui', st.density === 'compact'); b.classList.toggle('nomotion', st.motion === false); b.classList.toggle('noav', st.avatars === false);
  }
  const POLLS = [['2500', 'سريع (2.5 ث)'], ['3500', 'عادي (3.5 ث)'], ['6000', 'موفّر (6 ث)'], ['12000', 'بطيء جداً (12 ث)']];
  const ZOOMS = [['85', 'صغير جداً'], ['92', 'صغير'], ['100', 'عادي'], ['110', 'كبير'], ['120', 'كبير جداً'], ['135', 'ضخم']];
  const GENERAL = [
    { t: 'sec', l: 'المظهر' },
    { k: 'theme', t: 'select', l: 'السمة', o: [['dark', 'داكن'], ['light', 'فاتح'], ['auto', 'حسب النظام']] },
    { k: 'accent', t: 'swatch', l: 'لون التطبيق الرئيسي', o: ACCENTS },
    { k: 'zoom', t: 'select', l: 'حجم الواجهة', h: 'يكبّر أو يصغّر كل العناصر', o: ZOOMS },
    { k: 'density', t: 'select', l: 'كثافة العرض', o: [['cozy', 'مريح'], ['compact', 'مضغوط (محتوى أكثر)']] },
    { k: 'avatars', t: 'switch', l: 'إظهار الصور الشخصية في الرسائل' },
    { k: 'motion', t: 'switch', l: 'الحركات والانتقالات', h: 'أوقفها لأداء أخف' },
    { k: 'timeFmt', t: 'select', l: 'صيغة الوقت', o: [['auto', 'تلقائي'], ['12', '12 ساعة'], ['24', '24 ساعة']] },
    { t: 'sec', l: 'السلوك' },
    { k: 'startTab', t: 'select', l: 'القسم عند فتح التطبيق', o: [['tools', 'الأدوات'], ['composer', 'المرسل'], ['session', 'الجلسة'], ['bots', 'البوتات']] },
    { k: 'pollMs', t: 'select', l: 'سرعة تحديث المحادثات', h: 'يسري عند فتح المحادثة', o: POLLS },
    { k: 'confirmSend', t: 'switch', l: 'تأكيد قبل إرسال الرسائل' },
    { k: 'pingDefault', t: 'switch', l: 'تنبيه صاحب الرسالة عند الرد (افتراضي)' },
    { k: 'autoScroll', t: 'switch', l: 'النزول التلقائي للرسائل الجديدة' },
    { k: 'swipe', t: 'switch', l: 'إيماءات السحب على الرسائل' },
    { k: 'haptics', t: 'switch', l: 'اهتزاز خفيف عند النجاح والخطأ' },
    { t: 'sec', l: 'الخلفية والإشعارات' },
    { k: 'bg', t: 'switch', l: 'خدمة الخلفية', h: 'تُرسل الرسائل المجدولة والتطبيق مغلق. تُظهر إشعاراً دائماً وتستهلك بطارية أكثر قليلاً', fn: v => { if (NATIVE && NATIVE.serviceSet) { NATIVE.serviceSet(!!v); toast(v ? 'فُعّلت الخدمة الخلفية' : 'أُوقفت الخدمة الخلفية', 'ok'); } else toast('متاحة في تطبيق أندرويد فقط', 'bad'); } },
    { k: 'notifyBg', t: 'switch', l: 'إشعار برسائل جديدة', h: 'عند وصول رسائل في محادثة مفتوحة والتطبيق في الخلفية (يلزم تفعيل الخدمة الخلفية)' },
    { t: 'sec', l: 'الخصوصية والأمان' },
    { k: 'allowEveryone', t: 'switch', l: 'السماح بـ @everyone والرتب في رسائلك', h: 'الافتراضي: منشن الأعضاء فقط (أكثر أماناً)' },
    { k: 'remember', t: 'switch', l: 'تذكّر التوكن والوجهة على الجهاز', fn: v => { if (!v) Tokens.clear(); } },
    { k: 'emojiImages', t: 'switch', l: 'إيموجي بصور ديسكورد (Twemoji)', h: 'تحتاج إنترنت وإلا تظهر رموز الهاتف' },
    { t: 'sec', l: 'الحسابات' },
    { t: 'button', l: 'الحسابات والملفات (توكنات وإعدادات منفصلة)', fn: () => profilesSheet() },
    { t: 'sec', l: 'البيانات' },
    { t: 'button', l: 'نسخة احتياطية كاملة (كل البيانات والتوكنات)', fn: () => { const o = {}; store.absKeys().forEach(k => { const v = store.absGet(k); if (v != null) o[k] = v; }); copyText(JSON.stringify({ app: 'discord-tools', v: APP_VERSION, data: o }), 'تم نسخ النسخة الكاملة — احفظها في مكان آمن'); } },
    { t: 'button', l: 'استعادة نسخة كاملة', keep: true, fn: async () => { const v = await promptDlg({ title: 'الصق النسخة الكاملة', value: '' }); if (!v) return; try { const o = JSON.parse(v); if (!o || o.app !== 'discord-tools' || !o.data) throw 0; Object.keys(o.data).forEach(k => store.absPut(k, o.data[k])); toast('تمت الاستعادة — أعد فتح التطبيق', 'ok'); } catch (e) { toast('النسخة غير صالحة', 'bad'); } } },
    { t: 'button', l: 'نسخ نسخة احتياطية من الإعدادات', fn: () => copyText(JSON.stringify(store.get('settings', {})), 'تم نسخ الإعدادات') },
    { t: 'button', l: 'استيراد إعدادات', fn: async () => { const v = await promptDlg({ title: 'الصق الإعدادات (JSON)', value: '' }); if (!v) return; try { const o = JSON.parse(v); if (!o || typeof o !== 'object') throw 0; Object.keys(o).filter(k => k in SETTING_DEFAULTS).forEach(k => settings.set(k, o[k])); applyPrefs(); toast('تم الاستيراد', 'ok'); } catch (e) { toast('JSON غير صالح', 'bad'); } }, keep: true },
    { t: 'button', l: 'إعادة ضبط كل الإعدادات', fn: async () => { if (await confirmDlg('إعادة كل الإعدادات (بما فيها إعدادات الأقسام) للوضع الافتراضي؟', { ok: 'إعادة' })) { store.del('settings'); ['session', 'bots', 'composer', 'tools'].forEach(p => Place.reset(p)); applyPrefs(); toast('تمت الإعادة', 'ok'); } } },
    { t: 'button', l: 'مسح كل البيانات المحفوظة', danger: true, fn: async () => { if (await confirmDlg('سيتم مسح التوكنات والقوالب والمسودات والسجل. الويبهوكات المعلّقة تبقى لتتمكن من حذفها. متابعة؟', { danger: true, ok: 'مسح' })) { const keep = Pending.all(); store.clear(); store.set('pending_hooks', keep); toast('تم المسح — أعد فتح التطبيق', 'ok'); } } }
  ];
  const PLACES = {
    session: { title: 'إعدادات الجلسة', sub: 'تخص محادثة الجلسة والهوية الحالية', items: [
      { t: 'sec', l: 'المحادثة' },
      { k: 'pollMs', t: 'select', l: 'سرعة التحديث', h: 'يسري عند فتح المحادثة', o: POLLS },
      { k: 'live', t: 'switch', l: 'تحديث فوري (Gateway) ومؤشر الكتابة', h: 'يعمل والتطبيق مفتوح، ويعود للتحديث الدوري تلقائياً عند الفشل' },
      { k: 'pingDefault', t: 'switch', l: 'تنبيه صاحب الرسالة عند الرد' },
      { k: 'confirmSend', t: 'switch', l: 'تأكيد قبل الإرسال' },
      { k: 'autoScroll', t: 'switch', l: 'النزول التلقائي للجديد' },
      { t: 'sec', l: 'إجراءات' },
      { t: 'button', l: 'تغيير الهوية', act: 'sess.ident' }, { t: 'button', l: 'التنقل بين القنوات', act: 'sess.nav' }, { t: 'button', l: 'حذف ويبهوكات الجلسة', act: 'sess.cleanup' }, { t: 'button', l: 'إنهاء الجلسة', act: 'sess.end', danger: true }] },
    bots: { title: 'إعدادات البوتات', sub: 'تخص محادثات البوت وإدارة السيرفر', items: [
      { t: 'sec', l: 'المحادثة' },
      { k: 'pollMs', t: 'select', l: 'سرعة التحديث', h: 'يسري عند فتح المحادثة', o: POLLS },
      { k: 'live', t: 'switch', l: 'تحديث فوري (Gateway) ومؤشر الكتابة', h: 'يعمل والتطبيق مفتوح، ويعود للتحديث الدوري تلقائياً عند الفشل' },
      { k: 'pingDefault', t: 'switch', l: 'تنبيه صاحب الرسالة عند الرد' },
      { k: 'confirmSend', t: 'switch', l: 'تأكيد قبل الإرسال' },
      { k: 'autoScroll', t: 'switch', l: 'النزول التلقائي للجديد' },
      { k: 'analytics', t: 'switch', l: 'تفعيل «تحليلات القناة» في قائمة القنوات', h: 'اختياري. يجلب رسائل القناة ويحسب النشاط محلياً دون حفظ أو رفع' },
      { t: 'sec', l: 'إجراءات' },
      { t: 'button', l: 'تسجيل الخروج', act: 'bot.logout', danger: true }] },
    composer: { title: 'إعدادات المرسل', sub: 'تخص مرسل الويبهوك والبوت', items: [
      { t: 'sec', l: 'الإرسال' },
      { k: 'confirmSend', t: 'switch', l: 'تأكيد قبل الإرسال' },
      { k: 'autosave', t: 'switch', l: 'حفظ المسودة تلقائياً', h: 'عند إيقافه تُحذف المسودة المحفوظة' },
      { t: 'sec', l: 'إجراءات' },
      { t: 'button', l: 'الوجهة (ويبهوك / بوت)', act: 'cmp.dest' }, { t: 'button', l: 'المزيد (قوالب، JSON، مسح…)', act: 'cmp.more' }] },
    tools: { title: 'إعدادات الأداة', sub: 'تخص عمل الأدوات', items: [
      { t: 'sec', l: 'النتائج' },
      { k: 'live', t: 'switch', l: 'نتيجة فورية أثناء الكتابة' },
      { k: 'autoCopy', t: 'switch', l: 'نسخ النتيجة تلقائياً' }] }
  };
  function prefControls(items, io) {
    return items.map((it, i) => {
      if (it.t === 'sec') return `<div class="pf-sec">${esc(it.l)}</div>`;
      const sub = it.h ? `<small class="sub">${esc(it.h)}</small>` : '';
      if (it.t === 'switch') return `<label class="switch"><span>${esc(it.l)}${sub ? '<br>' + sub : ''}</span><input type="checkbox" data-i="${i}" ${io.get(it.k) !== false && io.get(it.k) ? 'checked' : ''}></label>`;
      if (it.t === 'select') return `<div class="field"><label>${esc(it.l)}</label><select data-i="${i}">${it.o.map(([v, l]) => `<option value="${esc(v)}" ${String(io.get(it.k)) === String(v) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>${sub}</div>`;
      if (it.t === 'swatch') return `<div class="field"><label>${esc(it.l)}</label><div class="acc">${it.o.map(([v, l]) => `<button class="accb ${io.get(it.k).toLowerCase() === v ? 'on' : ''}" style="background:${v}" data-i="${i}" data-v="${v}" aria-label="${esc(l)}">${Icons.svg('check')}</button>`).join('')}</div></div>`;
      return `<button class="btn ${it.danger ? 'red' : 'sec'} block pf-btn" data-i="${i}">${esc(it.l)}</button>`;
    }).join('');
  }
  function openPrefs(title, items, io, extra) {
    const s = openSheet(`${extra && extra.sub ? `<p class="sub" style="margin:0 0 6px">${esc(extra.sub)}</p>` : ''}<div class="pf">${prefControls(items, io)}</div>${extra && extra.foot ? extra.foot : ''}`, { title });
    s.el.addEventListener('change', e => { const t = e.target, it = items[+t.dataset.i]; if (!it || !it.k) return; const v = t.type === 'checkbox' ? t.checked : (it.k === 'zoom' || it.k === 'pollMs' ? +t.value : t.value); io.set(it.k, v); if (it.fn) it.fn(v); applyPrefs(); });
    s.el.addEventListener('click', e => {
      const sw = e.target.closest('.accb'); if (sw) { const it = items[+sw.dataset.i]; io.set(it.k, sw.dataset.v); s.el.querySelectorAll('.accb').forEach(x => x.classList.toggle('on', x === sw)); applyPrefs(); return; }
      const b = e.target.closest('.pf-btn'); if (!b) return; const it = items[+b.dataset.i];
      if (it.act) { s.close(); setTimeout(() => { const el = document.querySelector(`[data-act="${it.act}"]`); if (el) el.click(); else toast('غير متاح الآن'); }, 260); return; }
      if (!it.keep) s.close(); setTimeout(() => it.fn && it.fn(), it.keep ? 0 : 260);
    });
    return s;
  }
  /* ---------- profiles (separate tokens + settings per profile) ---------- */
  const profiles = () => [{ id: 'default', name: 'الأساسي' }].concat((store.get('profiles', []) || []).filter(p => p && p.id && p.id !== 'default'));
  function profilesSheet() {
    const cur = store.profile;
    const draw = () => profiles().map(p => `<div class="sch ${p.id === cur ? '' : ''}"><div class="sch-t"><span class="uc">${esc(p.name)}</span> ${p.id === cur ? '<span class="chip ok">الحالي</span>' : ''}</div><div class="sch-b">${p.id === cur ? '' : `<button class="btn sm" data-sw="${esc(p.id)}">تبديل</button>`}<button class="btn sm sec" data-rn="${esc(p.id)}">إعادة تسمية</button>${p.id === 'default' || p.id === cur ? '' : `<button class="btn sm red" data-rm="${esc(p.id)}">حذف</button>`}</div></div>`).join('');
    const s = openSheet(`<p class="sub" style="margin:0 0 8px">لكل ملف توكناته ووجهاته وقوالبه وإعداداته الخاصة. التبديل بينها لا يحذف شيئاً.</p><div id="pr-l">${draw()}</div><button class="btn block" id="pr-new" style="margin-top:10px">+ ملف جديد</button>`, { title: 'الحسابات والملفات' });
    const sw = id => { store.absPut('profile_cur', id); location.reload(); };
    const save = l => store.set('profiles', l.filter(p => p.id !== 'default'));
    $('#pr-new', s.el).onclick = async () => {
      const n = await promptDlg({ title: 'اسم الملف الجديد', value: '' }); if (!n || !n.trim()) return;
      const id = Math.random().toString(36).slice(2, 8); const l = profiles(); l.push({ id, name: n.trim().slice(0, 30) }); save(l);
      if (await confirmDlg(`تم إنشاء «${n.trim()}». التبديل إليه الآن؟`, { ok: 'تبديل', cancel: 'لاحقاً' })) sw(id); else $('#pr-l', s.el).innerHTML = draw();
    };
    s.el.addEventListener('click', async e => {
      const a = e.target.closest('[data-sw]'), r = e.target.closest('[data-rn]'), d = e.target.closest('[data-rm]');
      if (a) return sw(a.dataset.sw);
      if (r) { const l = profiles(), p = l.find(x => x.id === r.dataset.rn); const n = await promptDlg({ title: 'اسم الملف', value: p.name }); if (n && n.trim()) { p.name = n.trim().slice(0, 30); save(l); $('#pr-l', s.el).innerHTML = draw(); } return; }
      if (d) { const id = d.dataset.rm; if (!await confirmDlg('حذف هذا الملف مع كل توكناته وبياناته؟', { danger: true, ok: 'حذف' })) return; store.absKeys().filter(k => k.startsWith('p_' + id + ':')).forEach(k => store.absDel(k)); save(profiles().filter(p => p.id !== id)); $('#pr-l', s.el).innerHTML = draw(); toast('تم الحذف', 'ok'); }
    });
  }
  function settingsSheet() {
    const foot = `<div class="about"><div class="ab-logo"><img src="logo.png" alt=""></div><b>Discord Tools</b><div class="ver">الإصدار ${APP_VERSION} <span>(بناء ${APP_BUILD})</span></div><div class="sub">الملف الحالي: ${esc((profiles().find(p => p.id === store.profile) || {}).name || 'الأساسي')}</div><p class="sub">تطبيق مستقل وليس تطبيقاً رسمياً من Discord.<br>التوكنات والويبهوكات تُخزَّن على جهازك فقط.<br>صور الإيموجي: Twemoji © Twitter / jdecked — CC-BY 4.0</p></div>`;
    openPrefs('الإعدادات العامة', GENERAL, { get: k => settings.all[k], set: (k, v) => settings.set(k, v) }, { foot });
  }
  function placeSettings(p) {
    const P = PLACES[p]; if (!P) return settingsSheet();
    const foot = `<button class="btn sec block" id="pf-gen" style="margin-top:14px">الإعدادات العامة للتطبيق</button><button class="btn sec block" id="pf-rst" style="margin-top:8px">إعادة ضبط هذا القسم</button><p class="sub" style="text-align:center;margin-top:12px">Discord Tools ${APP_VERSION}</p>`;
    const s = openPrefs(P.title, P.items, { get: k => Place.pref(p, k), set: (k, v) => Place.set(p, k, v) }, { sub: P.sub, foot });
    $('#pf-gen', s.el).onclick = () => { s.close(); setTimeout(settingsSheet, 260); };
    $('#pf-rst', s.el).onclick = () => { Place.reset(p); s.close(); toast('تمت إعادة الضبط', 'ok'); };
  }
  function gear() {
    const m = TABS.find(t => t[0] === cur)[3];
    const inside = cur === 'composer' || (mounted[cur] && m && m.active);
    if (inside && PLACES[cur]) placeSettings(cur); else settingsSheet();
  }
  function palette() {
    const items = [
      ...TABS.map(([k, , l]) => ({ n: l, d: 'قسم في التطبيق', k: 'قسم', f: () => goTab(k) })),
      { n: 'الإعدادات العامة', d: 'المظهر، الحجم، السلوك، الخصوصية، الإصدار', k: 'إجراء', f: settingsSheet },
      { n: 'إعدادات هذا القسم', d: 'إعدادات خاصة بالمكان الحالي', k: 'إجراء', f: gear },
      { n: 'الحسابات والملفات', d: 'تبديل بين حسابات وتوكنات منفصلة', k: 'إجراء', f: profilesSheet },
      { n: 'رسالة جديدة', d: 'فتح المرسل', k: 'إجراء', f: () => goTab('composer') },
      { n: 'جلسة جديدة بهوية عضو', d: 'فتح الجلسة', k: 'إجراء', f: () => goTab('session') },
      ...Tools.list.map(t => ({ n: t.name, d: t.desc, k: t.cat, f: () => { goTab('tools'); Tools.open(t.id); } }))
    ];
    const s = openSheet(`<input id="pl-q" class="pl-q" type="text" placeholder="ابحث عن أداة أو قسم أو إجراء" autocomplete="off"><div id="pl-r" class="pl-r"></div>`, { title: 'بحث سريع' });
    const q = $('#pl-q', s.el), r = $('#pl-r', s.el); let cur = [];
    const draw = () => {
      const t = q.value.trim().toLowerCase();
      cur = items.filter(i => !t || (i.n + ' ' + i.d + ' ' + i.k).toLowerCase().includes(t)).slice(0, 30);
      r.innerHTML = cur.map((i, n) => `<button class="pl-i" data-n="${n}"><b><span class="uc">${esc(i.n)}</span></b><small><span class="uc">${esc(i.d)}</span></small><em><span class="uc">${esc(i.k)}</span></em></button>`).join('') || '<div class="empty">لا نتائج</div>';
      r.querySelectorAll('[data-n]').forEach(b => b.onclick = () => { const it = cur[+b.dataset.n]; s.close(); it.f(); });
    };
    q.addEventListener('input', draw);
    q.addEventListener('keydown', e => { if (e.key === 'Enter' && cur[0]) { s.close(); cur[0].f(); } });
    draw(); setTimeout(() => q.focus(), 120);
  }
  function back() {
    if (closeTopSheet()) return true;
    const mod = TABS.find(t => t[0] === cur)[3];
    if (mounted[cur] && mod.back && mod.back()) return true;
    if (cur !== 'tools') { goTab('tools'); return true; }
    return false;
  }
  function init() {
    $('#tabs').innerHTML = TABS.map(([k, e, l]) => `<button id="tab-${k}" data-act="app.tab" data-t="${k}"><svg class="e" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${e}</svg>${l}</button>`).join('');
    $('#views').innerHTML = TABS.map(([k]) => `<div id="v-${k}" class="view hidden"></div>`).join('');
    registerActions({ 'app.tab': t => { Haptic.tap(); goTab(t.dataset.t); }, 'app.settings': gear, 'app.search': palette });
    applyPrefs(); try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyPrefs); } catch (e) { /* ignore */ }
    goTab(['tools', 'composer', 'session', 'bots'].includes(settings.all.startTab) ? settings.all.startTab : 'tools');
    Icons.install(); Select.install(); DatePick.install(); Sched.start();
    try { if (NATIVE && NATIVE.serviceSet && settings.all.bg && !NATIVE.serviceOn()) NATIVE.serviceSet(true); } catch (e) { /* ignore */ }
    setTimeout(takeShared, 400);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) takeShared(); });
  }
  async function takeShared() {
    let o = null; try { o = NATIVE && NATIVE.takeShared ? JSON.parse(NATIVE.takeShared() || '{}') : null; } catch (e) { o = null; }
    if (!o) return;
    if (o.go && TABS.find(t => t[0] === o.go)) goTab(o.go);
    if (o.text || (o.files && o.files.length)) { goTab('composer'); await Composer.receive(o); toast('تمت إضافة المحتوى المشترك إلى المرسل', 'ok'); }
  }
  window.__shared = takeShared;
  window.__back = back;
  window.addEventListener('unhandledrejection', e => { const m = e.reason && e.reason.message; if (m) toast(m, 'bad'); });
  return { init, goTab, applyPrefs };
})();
App.init();

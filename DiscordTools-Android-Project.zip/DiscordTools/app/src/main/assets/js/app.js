'use strict';
/* ============================================================
   app.js — shell: tabs, settings, back handling, startup
   ============================================================ */
const App = (() => {
  const TABS = [
    ['tools', '<path d="M14.5 5.5a4 4 0 0 0-5 5L4 16l4 4 5.5-5.5a4 4 0 0 0 5-5l-3 3-3-1-1-3z"/>', 'الأدوات', Tools],
    ['composer', '<path d="M21 4 3 11l7 3 3 7zM10 14l11-10"/>', 'المرسل', Composer],
    ['session', '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.5-4 3-6 6.5-6s6 2 6.5 6M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2 .6 3.3 2.5 3.5 6"/>', 'الجلسة', Session],
    ['bots', '<rect x="4" y="8" width="16" height="11" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9.5 16.5h5"/>', 'البوتات', Bots]
  ];
  let cur = 'tools';
  const mounted = {};
  const flexTabs = {};

  function goTab(id) {
    cur = id;
    TABS.forEach(([k, , , mod]) => {
      const v = $('#v-' + k);
      v.classList.toggle('hidden', k !== id);
      $('#tab-' + k).classList.toggle('on', k === id);
      if (k === id && !mounted[k]) { mounted[k] = true; mod.mount(v); }
    });
  }
  function settingsSheet() {
    const st = settings.all;
    const s = openSheet(`
      <label class="switch"><span>السماح بـ @everyone والرتب في رسائلك<br><small class="sub">الافتراضي: منشن الأعضاء فقط (أكثر أماناً)</small></span><input type="checkbox" id="st-ev" ${st.allowEveryone ? 'checked' : ''}></label>
      <label class="switch"><span>تذكّر التوكن والوجهة على الجهاز</span><input type="checkbox" id="st-rem" ${st.remember ? 'checked' : ''}></label>
      <label class="switch"><span>إيموجي بصور ديسكورد (Twemoji)<br><small class="sub">بدل رموز الهاتف — تحتاج إنترنت وإلا تظهر رموز الهاتف</small></span><input type="checkbox" id="st-twe" ${st.emojiImages !== false ? 'checked' : ''}></label>
      <div class="field"><label>سرعة تحديث المحادثة</label><select id="st-poll"><option value="2500">سريع (2.5 ث)</option><option value="3500">عادي (3.5 ث)</option><option value="6000">موفّر (6 ث)</option></select></div>
      <button class="btn red block" id="st-clear">مسح كل البيانات المحفوظة</button>
      <p class="sub" style="margin-top:14px;text-align:center">Discord Tools 2.4 · تطبيق مستقل وليس تطبيقاً رسمياً من Discord<br>البيانات (التوكنات والويبهوكات) تُخزَّن على جهازك فقط.<br>صور الإيموجي: Twemoji © Twitter / jdecked — CC-BY 4.0</p>`, { title: 'الإعدادات' });
    $('#st-poll', s.el).value = String(st.pollMs);
    $('#st-ev', s.el).onchange = e => settings.set('allowEveryone', e.target.checked);
    $('#st-rem', s.el).onchange = e => { settings.set('remember', e.target.checked); if (!e.target.checked) { Tokens.clear(); } };
    $('#st-twe', s.el).onchange = e => settings.set('emojiImages', e.target.checked);
    $('#st-poll', s.el).onchange = e => settings.set('pollMs', +e.target.value);
    $('#st-clear', s.el).onclick = async () => {
      if (await confirmDlg('سيتم مسح التوكنات والقوالب والمسودات والسجل. الويبهوكات المعلّقة تبقى لتتمكن من حذفها. متابعة؟', { danger: true, ok: 'مسح' })) {
        const keep = Pending.all(); store.clear(); store.set('pending_hooks', keep); s.close(); toast('تم المسح — أعد فتح التطبيق', 'ok');
      }
    };
  }
  function palette() {
    const items = [
      ...TABS.map(([k, , l]) => ({ n: l, d: 'قسم في التطبيق', k: 'قسم', f: () => goTab(k) })),
      { n: 'الإعدادات', d: 'التوكن، المنشن، سرعة التحديث', k: 'إجراء', f: settingsSheet },
      { n: 'رسالة جديدة', d: 'فتح المرسل', k: 'إجراء', f: () => goTab('composer') },
      { n: 'جلسة جديدة بهوية عضو', d: 'فتح الجلسة', k: 'إجراء', f: () => goTab('session') },
      ...Tools.list.map(t => ({ n: t.name, d: t.desc, k: t.cat, f: () => { goTab('tools'); Tools.open(t.id); } }))
    ];
    const s = openSheet(`<input id="pl-q" class="pl-q" type="text" placeholder="ابحث عن أداة أو قسم أو إجراء" autocomplete="off"><div id="pl-r" class="pl-r"></div>`, { title: 'بحث سريع' });
    const q = $('#pl-q', s.el), r = $('#pl-r', s.el); let cur = [];
    const draw = () => {
      const t = q.value.trim().toLowerCase();
      cur = items.filter(i => !t || (i.n + ' ' + i.d + ' ' + i.k).toLowerCase().includes(t)).slice(0, 30);
      r.innerHTML = cur.map((i, n) => `<button class="pl-i" data-n="${n}"><b><span class="uc">${esc(i.n)}</span></b><small><span class="uc">${esc(i.d)}</span></small><em><span class="uc">${esc(i.k)}</span></em></button>`).join('') || '<div class="empty">لا نتائج</div>';
      r.querySelectorAll('[data-n]').forEach(b => b.onclick = () => { const it = cur[+b.dataset.n]; s.close(); it.f(); });
    };
    q.addEventListener('input', draw);
    q.addEventListener('keydown', e => { if (e.key === 'Enter' && cur[0]) { s.close(); cur[0].f(); } });
    draw(); setTimeout(() => q.focus(), 120);
  }
  function back() {
    if (closeTopSheet()) return true;
    const mod = TABS.find(t => t[0] === cur)[3];
    if (mounted[cur] && mod.back && mod.back()) return true;
    if (cur !== 'tools') { goTab('tools'); return true; }
    return false;
  }
  function init() {
    $('#tabs').innerHTML = TABS.map(([k, e, l]) => `<button id="tab-${k}" data-act="app.tab" data-t="${k}"><svg class="e" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${e}</svg>${l}</button>`).join('');
    $('#views').innerHTML = TABS.map(([k]) => `<div id="v-${k}" class="view hidden"></div>`).join('');
    registerActions({ 'app.tab': t => goTab(t.dataset.t), 'app.settings': settingsSheet, 'app.search': palette });
    goTab('tools');
    Icons.install();
  }
  window.__back = back;
  window.addEventListener('unhandledrejection', e => { const m = e.reason && e.reason.message; if (m) toast(m, 'bad'); });
  return { init, goTab };
})();
App.init();

'use strict';
/* ============================================================
   core.js — helpers, native bridge, Discord REST client, UI kit
   ============================================================ */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const uid = () => Math.random().toString(36).slice(2, 9);
const clip = (s, n) => { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
const isId = s => /^\d{15,25}$/.test(String(s || '').trim());
const safeUrl = u => /^https?:\/\//i.test(String(u || '').trim()) ? String(u).trim() : '';
const snowflakeMs = id => Number((BigInt(id) >> 22n) + 1420070400000n);

/* ---------------- native bridge ---------------- */
const NATIVE = window.Native || null;
const pending = new Map();
let reqCounter = 0;
window.__nativeResp = (id, resp) => {
  const cb = pending.get(id);
  if (!cb) return;
  pending.delete(id);
  try { cb(JSON.parse(resp)); } catch (e) { cb({ status: 0, error: String(e) }); }
};
function nativeReq(obj) {
  return new Promise(res => {
    if (!NATIVE) return res({ status: 0, error: 'التطبيق يعمل خارج أندرويد' });
    const id = 'r' + (++reqCounter);
    pending.set(id, res);
    try { NATIVE.request(id, JSON.stringify(obj)); }
    catch (e) { pending.delete(id); res({ status: 0, error: String(e) }); }
  });
}

/* ---------------- storage ---------------- */
const store = {
  get(k, d) {
    try {
      const v = NATIVE ? NATIVE.storeGet(k) : localStorage.getItem(k);
      return v == null ? d : JSON.parse(v);
    } catch (e) { return d; }
  },
  set(k, v) {
    try {
      const s = JSON.stringify(v);
      if (NATIVE) NATIVE.storeSet(k, s); else localStorage.setItem(k, s);
    } catch (e) { /* ignore */ }
  },
  del(k) { try { if (NATIVE) NATIVE.storeDel(k); else localStorage.removeItem(k); } catch (e) { /* ignore */ } },
  clear() { try { if (NATIVE) NATIVE.storeClear(); else localStorage.clear(); } catch (e) { /* ignore */ } }
};
const settings = {
  get all() { return Object.assign({ allowEveryone: false, remember: true, pollMs: 3500 }, store.get('settings', {})); },
  set(k, v) { const s = store.get('settings', {}); s[k] = v; store.set('settings', s); }
};

function copyText(t, msg) {
  try { if (NATIVE) NATIVE.copy(String(t)); else navigator.clipboard && navigator.clipboard.writeText(String(t)); } catch (e) { /* ignore */ }
  toast(msg || 'تم النسخ', 'ok');
}
function openLink(u) {
  u = safeUrl(u);
  if (!u) return;
  try { if (NATIVE) NATIVE.openUrl(u); else window.open(u, '_blank'); } catch (e) { /* ignore */ }
}

/* ---------------- Discord REST ---------------- */
const API = 'https://discord.com/api/v10';
class DiscordError extends Error {
  constructor(status, message, data) { super(message); this.status = status; this.data = data; }
}
const ERR_AR = {
  10003: 'القناة غير موجودة', 10004: 'السيرفر غير موجود', 10008: 'الرسالة غير موجودة (ربما حُذفت)', 10013: 'المستخدم غير موجود',
  10015: 'الويبهوك غير موجود (ربما حُذف)', 10007: 'العضو ليس في السيرفر', 50001: 'البوت لا يملك وصولاً (Missing Access) — تأكد أنه في السيرفر ويرى القناة',
  50013: 'صلاحيات البوت غير كافية (Missing Permissions)', 50035: 'بيانات غير صالحة', 50027: 'توكن الويبهوك غير صالح',
  30007: 'وصلت للحد الأقصى من الويبهوكات في هذه القناة (15)', 40005: 'حجم الملفات كبير جداً', 50006: 'لا يمكن إرسال رسالة فارغة',
  50007: 'لا يمكن مراسلة هذا المستخدم', 50109: 'JSON غير صالح', 20024: 'لا يمكن تنفيذ هذا الإجراء على هذه القناة', 50024: 'لا يمكن تنفيذ الإجراء على هذا النوع من القنوات'
};
function flattenErrors(e, p = '') {
  let out = [];
  if (!e || typeof e !== 'object') return out;
  if (Array.isArray(e._errors)) e._errors.forEach(x => out.push((p ? p + ': ' : '') + x.message));
  Object.keys(e).forEach(k => { if (k !== '_errors') out = out.concat(flattenErrors(e[k], p ? p + '.' + k : k)); });
  return out;
}
function errText(status, data) {
  if (status === 0) return 'تعذر الاتصال: ' + (data && data.error ? data.error : 'تحقق من الإنترنت');
  if (status === 401) return 'التوكن غير صالح (401)';
  const code = data && data.code;
  let m = ERR_AR[code] || (data && data.message) || ('خطأ ' + status);
  if (code === 50035) {
    const f = flattenErrors(data.errors).slice(0, 3).join(' | ');
    if (f) m += ' — ' + f;
  }
  return m;
}
async function dapi(method, path, o = {}) {
  const url = /^https?:/.test(path) ? path : API + path + (o.query ? '?' + new URLSearchParams(o.query).toString() : '');
  const headers = {};
  if (o.token) headers['Authorization'] = 'Bot ' + o.token;
  if (o.reason) headers['X-Audit-Log-Reason'] = encodeURIComponent(o.reason);
  const req = { method, url, headers, binary: !!o.binary };
  if (o.json !== undefined) { req.body = JSON.stringify(o.json); req.contentType = 'application/json'; }
  if (o.files && o.files.length) req.multipart = { payload: JSON.stringify(o.json || {}), files: o.files };
  if (req.multipart) delete req.body;
  let r;
  for (let i = 0; i < 3; i++) {
    r = await nativeReq(req);
    if (r.status === 429) {
      let wait = Number(r.retryAfter) || 1;
      try { wait = Number(JSON.parse(r.body).retry_after) || wait; } catch (e) { /* ignore */ }
      await sleep(Math.min(8, wait) * 1000 + 150);
      continue;
    }
    break;
  }
  if (r.error || r.status === 0) throw new DiscordError(0, errText(0, r), r);
  let data = null;
  if (o.binary) data = { b64: r.body, type: (r.contentType || 'image/png').split(';')[0] };
  else if (r.body) { try { data = JSON.parse(r.body); } catch (e) { data = r.body; } }
  if (r.status >= 200 && r.status < 300) return data;
  throw new DiscordError(r.status, errText(r.status, data), data);
}
const fileToB64 = file => new Promise((res, rej) => {
  const fr = new FileReader();
  fr.onload = () => { const s = String(fr.result); res(s.slice(s.indexOf(',') + 1)); };
  fr.onerror = () => rej(fr.error);
  fr.readAsDataURL(file);
});
async function filesPayload(files) {
  const out = [];
  for (const f of files) out.push({ name: f.name, type: f.type || 'application/octet-stream', b64: await fileToB64(f) });
  return out;
}

/* ---------------- UI kit ---------------- */
function toast(msg, kind) {
  const box = $('#toasts');
  const t = document.createElement('div');
  t.className = 'toast ' + (kind || '');
  t.textContent = msg;
  box.appendChild(t);
  setTimeout(() => t.remove(), kind === 'bad' ? 5200 : 2600);
}
const sheets = [];
function openSheet(html, o = {}) {
  const wrap = document.createElement('div');
  wrap.className = 'sheet-wrap';
  wrap.innerHTML = `<div class="sheet-bg"></div><div class="sheet"><div class="grab"></div>${o.title ? `<div class="sheet-title">${esc(o.title)}</div>` : ''}<div class="sheet-body">${html}</div></div>`;
  document.body.appendChild(wrap);
  const api = {
    el: wrap.querySelector('.sheet-body'), wrap,
    close() {
      if (!wrap.isConnected) return;
      wrap.remove();
      const i = sheets.indexOf(api);
      if (i >= 0) sheets.splice(i, 1);
      if (o.onClose) o.onClose();
    }
  };
  wrap.querySelector('.sheet-bg').addEventListener('click', () => api.close());
  sheets.push(api);
  return api;
}
function closeTopSheet() {
  const s = sheets[sheets.length - 1];
  if (!s) return false;
  s.close();
  return true;
}
function confirmDlg(text, o = {}) {
  return new Promise(res => {
    let done = false;
    const s = openSheet(`<p style="margin:4px 0 16px;line-height:1.7">${esc(text)}</p>
      <div class="row"><button class="btn ${o.danger ? 'red' : ''} grow" data-ok>${esc(o.ok || 'تأكيد')}</button><button class="btn sec grow" data-no>إلغاء</button></div>`,
      { title: o.title || '', onClose: () => { if (!done) { done = true; res(false); } } });
    s.el.querySelector('[data-ok]').onclick = () => { done = true; s.close(); res(true); };
    s.el.querySelector('[data-no]').onclick = () => { s.close(); };
  });
}
function promptDlg(o = {}) {
  return new Promise(res => {
    let done = false;
    const s = openSheet(`<div class="field"><label>${esc(o.label || '')}</label>${o.multiline ? `<textarea rows="4" class="ltr" placeholder="${esc(o.placeholder || '')}">${esc(o.value || '')}</textarea>` : `<input type="text" class="ltr" placeholder="${esc(o.placeholder || '')}" value="${esc(o.value || '')}">`}</div>
      <div class="row"><button class="btn grow" data-ok>${esc(o.ok || 'حفظ')}</button><button class="btn sec grow" data-no>إلغاء</button></div>`,
      { title: o.title || '', onClose: () => { if (!done) { done = true; res(null); } } });
    const inp = s.el.querySelector('input,textarea');
    setTimeout(() => inp && inp.focus(), 80);
    s.el.querySelector('[data-ok]').onclick = () => { done = true; const v = inp.value; s.close(); res(v); };
    s.el.querySelector('[data-no]').onclick = () => s.close();
  });
}
function menuSheet(title, items) {
  const s = openSheet(`<div class="menu">${items.filter(Boolean).map((it, i) => `<button class="${it.cls || ''}" data-i="${i}"><span class="e">${it.icon || ''}</span><span>${esc(it.label)}</span></button>`).join('')}</div>`, { title });
  const list = items.filter(Boolean);
  s.el.querySelectorAll('button[data-i]').forEach(b => b.addEventListener('click', () => { s.close(); list[+b.dataset.i].fn(); }));
  return s;
}
function loadingHTML() { return '<div class="loading"><span class="spin"></span></div>'; }
async function withBusy(btn, fn) {
  if (btn && btn.disabled) return;
  const old = btn ? btn.innerHTML : '';
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spin"></span>'; }
  try { return await fn(); }
  finally { if (btn) { btn.disabled = false; btn.innerHTML = old; } }
}
function autoGrow(ta) { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight + 2, 220) + 'px'; }

/* ---------------- action registry (event delegation) ---------------- */
const actions = {};
function registerActions(map) { Object.assign(actions, map); }
document.addEventListener('click', e => {
  const t = e.target.closest('[data-act]');
  if (!t) return;
  const fn = actions[t.dataset.act];
  if (fn) { e.stopPropagation(); Promise.resolve(fn(t, e)).catch(err => toast(err && err.message ? err.message : String(err), 'bad')); }
});
document.addEventListener('focusin', e => { if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) document.body.classList.add('kb'); });
document.addEventListener('focusout', () => setTimeout(() => {
  const a = document.activeElement;
  if (!a || !/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) document.body.classList.remove('kb');
}, 60));

/* ---------------- avatars / names ---------------- */
const CDN = 'https://cdn.discordapp.com';
function defaultAvatar(id, disc) {
  let idx = 0;
  try { idx = (disc && disc !== '0') ? Number(disc) % 5 : Number((BigInt(id || 0) >> 22n) % 6n); } catch (e) { /* ignore */ }
  return `${CDN}/embed/avatars/${idx}.png`;
}
function userAvatar(u, size = 64) {
  if (!u) return defaultAvatar(0);
  if (u.avatar) return `${CDN}/avatars/${u.id}/${u.avatar}.${String(u.avatar).startsWith('a_') ? 'gif' : 'png'}?size=${size}`;
  return defaultAvatar(u.id, u.discriminator);
}
function memberAvatar(gid, m, size = 64) {
  if (m && m.avatar && gid && m.user) return `${CDN}/guilds/${gid}/users/${m.user.id}/avatars/${m.avatar}.${String(m.avatar).startsWith('a_') ? 'gif' : 'png'}?size=${size}`;
  return userAvatar(m && m.user, size);
}
function guildIcon(g, size = 64) { return g && g.icon ? `${CDN}/icons/${g.id}/${g.icon}.${String(g.icon).startsWith('a_') ? 'gif' : 'png'}?size=${size}` : ''; }
function displayName(u, m) { return (m && m.nick) || (u && (u.global_name || u.username)) || 'مستخدم'; }
async function fetchImageDataUri(url) {
  const r = await dapi('GET', url, { binary: true });
  return `data:${r.type};base64,${r.b64}`;
}

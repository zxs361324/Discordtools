'use strict';
/* ============================================================
   core.js — helpers, native bridge, Discord REST client, UI kit
   ============================================================ */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const uid = () => Math.random().toString(36).slice(2, 9);
const clip = (s, n) => { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
const isId = s => /^\d{15,25}$/.test(String(s || '').trim());
const safeUrl = u => /^https?:\/\//i.test(String(u || '').trim()) ? String(u).trim() : '';
const snowflakeMs = id => Number((BigInt(id) >> 22n) + 1420070400000n);

/* ---------------- native bridge ---------------- */
const NATIVE = window.Native || null;
const pending = new Map();
let reqCounter = 0;
window.__nativeResp = (id, resp) => {
  const cb = pending.get(id);
  if (!cb) return;
  pending.delete(id);
  try { cb(JSON.parse(resp)); } catch (e) { cb({ status: 0, error: String(e) }); }
};
function nativeReq(obj) {
  return new Promise(res => {
    if (!NATIVE) return res({ status: 0, error: 'التطبيق يعمل خارج أندرويد' });
    const id = 'r' + (++reqCounter);
    pending.set(id, res);
    try { NATIVE.request(id, JSON.stringify(obj)); }
    catch (e) { pending.delete(id); res({ status: 0, error: String(e) }); }
  });
}

/* ---------------- storage ---------------- */
const store = {
  get(k, d) {
    try {
      const v = NATIVE ? NATIVE.storeGet(k) : localStorage.getItem(k);
      return v == null ? d : JSON.parse(v);
    } catch (e) { return d; }
  },
  set(k, v) {
    try {
      const s = JSON.stringify(v);
      if (NATIVE) NATIVE.storeSet(k, s); else localStorage.setItem(k, s);
    } catch (e) { /* ignore */ }
  },
  del(k) { try { if (NATIVE) NATIVE.storeDel(k); else localStorage.removeItem(k); } catch (e) { /* ignore */ } },
  clear() { try { if (NATIVE) NATIVE.storeClear(); else localStorage.clear(); } catch (e) { /* ignore */ } }
};
const APP_VERSION = '2.6', APP_BUILD = 13;
const SETTING_DEFAULTS = { allowEveryone: false, remember: true, pollMs: 3500, emojiImages: true, accent: '#5865f2', zoom: 100, density: 'cozy', motion: true, timeFmt: 'auto', avatars: true, startTab: 'tools', confirmSend: false, pingDefault: true, swipe: true, autoScroll: true, autosave: true, autoCopy: false, live: true };
const settings = {
  get all() { return Object.assign({}, SETTING_DEFAULTS, store.get('settings', {})); },
  set(k, v) { const s = store.get('settings', {}); s[k] = v; store.set('settings', s); }
};
/* per-place overrides (session / bots / composer / tools); fall back to the general setting */
const Place = {
  raw(p) { return store.get('ps_' + p, {}); },
  pref(p, k) { const v = this.raw(p)[k]; return v === undefined ? settings.all[k] : v; },
  set(p, k, v) { const o = this.raw(p); o[k] = v; store.set('ps_' + p, o); },
  reset(p) { store.del('ps_' + p); }
};

function copyText(t, msg) {
  try { if (NATIVE) NATIVE.copy(String(t)); else navigator.clipboard && navigator.clipboard.writeText(String(t)); } catch (e) { /* ignore */ }
  toast(msg || 'تم النسخ', 'ok');
}
function openLink(u) {
  u = safeUrl(u);
  if (!u) return;
  try { if (NATIVE) NATIVE.openUrl(u); else window.open(u, '_blank'); } catch (e) { /* ignore */ }
}

/* ---------------- Discord REST ---------------- */
const API = 'https://discord.com/api/v10';
class DiscordError extends Error {
  constructor(status, message, data) { super(message); this.status = status; this.data = data; }
}
const ERR_AR = {
  10003: 'القناة غير موجودة', 10004: 'السيرفر غير موجود', 10008: 'الرسالة غير موجودة (ربما حُذفت)', 10013: 'المستخدم غير موجود',
  10015: 'الويبهوك غير موجود (ربما حُذف)', 10007: 'العضو ليس في السيرفر', 50001: 'البوت لا يملك وصولاً (Missing Access) — تأكد أنه في السيرفر ويرى القناة',
  50013: 'صلاحيات البوت غير كافية (Missing Permissions)', 50035: 'بيانات غير صالحة', 50027: 'توكن الويبهوك غير صالح',
  30007: 'وصلت للحد الأقصى من الويبهوكات في هذه القناة (15)', 40005: 'حجم الملفات كبير جداً', 50006: 'لا يمكن إرسال رسالة فارغة',
  50007: 'لا يمكن مراسلة هذا المستخدم', 50109: 'JSON غير صالح', 20024: 'لا يمكن تنفيذ هذا الإجراء على هذه القناة', 50024: 'لا يمكن تنفيذ الإجراء على هذا النوع من القنوات'
};
function flattenErrors(e, p = '') {
  let out = [];
  if (!e || typeof e !== 'object') return out;
  if (Array.isArray(e._errors)) e._errors.forEach(x => out.push((p ? p + ': ' : '') + x.message));
  Object.keys(e).forEach(k => { if (k !== '_errors') out = out.concat(flattenErrors(e[k], p ? p + '.' + k : k)); });
  return out;
}
function errText(status, data) {
  if (status === 0) return 'تعذر الاتصال: ' + (data && data.error ? data.error : 'تحقق من الإنترنت');
  if (status === 401) return 'التوكن غير صالح (401)';
  const code = data && data.code;
  let m = ERR_AR[code] || (data && data.message) || ('خطأ ' + status);
  if (code === 50035) {
    const f = flattenErrors(data.errors).slice(0, 3).join(' | ');
    if (f) m += ' — ' + f;
  }
  return m;
}
async function dapi(method, path, o = {}) {
  const url = /^https?:/.test(path) ? path : API + path + (o.query ? '?' + new URLSearchParams(o.query).toString() : '');
  const headers = {};
  if (o.token) headers['Authorization'] = 'Bot ' + o.token;
  if (o.reason) headers['X-Audit-Log-Reason'] = encodeURIComponent(o.reason);
  const req = { method, url, headers, binary: !!o.binary };
  if (o.json !== undefined) { req.body = JSON.stringify(o.json); req.contentType = 'application/json'; }
  if (o.files && o.files.length) req.multipart = { payload: JSON.stringify(o.json || {}), files: o.files };
  if (req.multipart) delete req.body;
  let r;
  for (let i = 0; i < 3; i++) {
    r = await nativeReq(req);
    if (r.status === 429) {
      let wait = Number(r.retryAfter) || 1;
      try { wait = Number(JSON.parse(r.body).retry_after) || wait; } catch (e) { /* ignore */ }
      await sleep(Math.min(8, wait) * 1000 + 150);
      continue;
    }
    break;
  }
  if (r.error || r.status === 0) throw new DiscordError(0, errText(0, r), r);
  let data = null;
  if (o.binary) data = { b64: r.body, type: (r.contentType || 'image/png').split(';')[0] };
  else if (r.body) { try { data = JSON.parse(r.body); } catch (e) { data = r.body; } }
  if (r.status >= 200 && r.status < 300) return data;
  throw new DiscordError(r.status, errText(r.status, data), data);
}
const fileToB64 = file => new Promise((res, rej) => {
  const fr = new FileReader();
  fr.onload = () => { const s = String(fr.result); res(s.slice(s.indexOf(',') + 1)); };
  fr.onerror = () => rej(fr.error);
  fr.readAsDataURL(file);
});
async function filesPayload(files) {
  const out = [];
  for (const f of files) out.push({ name: f.name, type: f.type || 'application/octet-stream', b64: await fileToB64(f) });
  return out;
}

/* ---------------- UI kit ---------------- */
function toast(msg, kind) {
  const box = $('#toasts');
  const t = document.createElement('div');
  t.className = 'toast ' + (kind || '');
  t.textContent = msg;
  box.appendChild(t);
  while (box.children.length > 3) box.firstChild.remove();
  setTimeout(() => t.remove(), kind === 'bad' ? 5200 : 2600);
}
const LOC = 'ar-u-nu-latn';
const sheets = [];
function openSheet(html, o = {}) {
  const wrap = document.createElement('div');
  wrap.className = 'sheet-wrap';
  wrap.innerHTML = `<div class="sheet-bg"></div><div class="sheet"><div class="grab"></div>${o.title ? `<div class="sheet-title">${esc(o.title)}</div>` : ''}<div class="sheet-body">${html}</div></div>`;
  document.body.appendChild(wrap);
  const api = {
    el: wrap.querySelector('.sheet-body'), wrap,
    close() {
      if (!wrap.isConnected) return;
      wrap.remove();
      const i = sheets.indexOf(api);
      if (i >= 0) sheets.splice(i, 1);
      if (o.onClose) o.onClose();
    }
  };
  wrap.querySelector('.sheet-bg').addEventListener('click', () => api.close());
  sheets.push(api);
  return api;
}
function closeTopSheet() {
  const s = sheets[sheets.length - 1];
  if (!s) return false;
  s.close();
  return true;
}
function confirmDlg(text, o = {}) {
  return new Promise(res => {
    let done = false;
    const s = openSheet(`<p style="margin:4px 0 16px;line-height:1.7">${esc(text)}</p>
      <div class="row"><button class="btn ${o.danger ? 'red' : ''} grow" data-ok>${esc(o.ok || 'تأكيد')}</button><button class="btn sec grow" data-no>إلغاء</button></div>`,
      { title: o.title || '', onClose: () => { if (!done) { done = true; res(false); } } });
    s.el.querySelector('[data-ok]').onclick = () => { done = true; s.close(); res(true); };
    s.el.querySelector('[data-no]').onclick = () => { s.close(); };
  });
}
function promptDlg(o = {}) {
  return new Promise(res => {
    let done = false;
    const s = openSheet(`<div class="field"><label>${esc(o.label || '')}</label>${o.multiline ? `<textarea rows="4" class="ltr" placeholder="${esc(o.placeholder || '')}">${esc(o.value || '')}</textarea>` : `<input type="text" class="ltr" placeholder="${esc(o.placeholder || '')}" value="${esc(o.value || '')}">`}</div>
      <div class="row"><button class="btn grow" data-ok>${esc(o.ok || 'حفظ')}</button><button class="btn sec grow" data-no>إلغاء</button></div>`,
      { title: o.title || '', onClose: () => { if (!done) { done = true; res(null); } } });
    const inp = s.el.querySelector('input,textarea');
    setTimeout(() => inp && inp.focus(), 80);
    s.el.querySelector('[data-ok]').onclick = () => { done = true; const v = inp.value; s.close(); res(v); };
    s.el.querySelector('[data-no]').onclick = () => s.close();
  });
}
function menuSheet(title, items) {
  const s = openSheet(`<div class="menu">${items.filter(Boolean).map((it, i) => `<button class="${it.cls || ''}" data-i="${i}"><span class="e">${it.icon || ''}</span><span>${esc(it.label)}</span></button>`).join('')}</div>`, { title });
  const list = items.filter(Boolean);
  s.el.querySelectorAll('button[data-i]').forEach(b => b.addEventListener('click', () => { s.close(); list[+b.dataset.i].fn(); }));
  return s;
}
function loadingHTML() { return '<div class="loading"><span class="spin"></span></div>'; }
async function withBusy(btn, fn) {
  if (btn && btn.disabled) return;
  const old = btn ? btn.innerHTML : '';
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spin"></span>'; }
  try { return await fn(); }
  finally { if (btn) { btn.disabled = false; btn.innerHTML = old; } }
}
function autoGrow(ta) { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight + 2, 220) + 'px'; }

/* ---------------- action registry (event delegation) ---------------- */
const actions = {};
function registerActions(map) { Object.assign(actions, map); }
document.addEventListener('click', e => {
  const t = e.target.closest('[data-act]');
  if (!t) return;
  const fn = actions[t.dataset.act];
  if (fn) { e.stopPropagation(); Promise.resolve(fn(t, e)).catch(err => toast(err && err.message ? err.message : String(err), 'bad')); }
});
document.addEventListener('focusin', e => { if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) document.body.classList.add('kb'); });
document.addEventListener('focusout', () => setTimeout(() => {
  const a = document.activeElement;
  if (!a || !/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) document.body.classList.remove('kb');
}, 60));

/* ---------------- avatars / names ---------------- */
const CDN = 'https://cdn.discordapp.com';
function defaultAvatar(id, disc) {
  let idx = 0;
  try { idx = (disc && disc !== '0') ? Number(disc) % 5 : Number((BigInt(id || 0) >> 22n) % 6n); } catch (e) { /* ignore */ }
  return `${CDN}/embed/avatars/${idx}.png`;
}
function userAvatar(u, size = 64) {
  if (!u) return defaultAvatar(0);
  if (u.avatar) return `${CDN}/avatars/${u.id}/${u.avatar}.${String(u.avatar).startsWith('a_') ? 'gif' : 'png'}?size=${size}`;
  return defaultAvatar(u.id, u.discriminator);
}
function memberAvatar(gid, m, size = 64) {
  if (m && m.avatar && gid && m.user) return `${CDN}/guilds/${gid}/users/${m.user.id}/avatars/${m.avatar}.${String(m.avatar).startsWith('a_') ? 'gif' : 'png'}?size=${size}`;
  return userAvatar(m && m.user, size);
}
function guildIcon(g, size = 64) { return g && g.icon ? `${CDN}/icons/${g.id}/${g.icon}.${String(g.icon).startsWith('a_') ? 'gif' : 'png'}?size=${size}` : ''; }
function displayName(u, m) { return (m && m.nick) || (u && (u.global_name || u.username)) || 'مستخدم'; }
async function fetchImageDataUri(url) {
  const r = await dapi('GET', url, { binary: true });
  return `data:${r.type};base64,${r.b64}`;
}

/* ---------------- colour picker (free HSL + hex) ---------------- */
function hslToHex(h, s, l) {
  s /= 100; l /= 100;
  const k = n => (n + h / 30) % 12, a = s * Math.min(l, 1 - l);
  const f = n => Math.round(255 * (l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)))));
  return '#' + [f(0), f(8), f(4)].map(x => x.toString(16).padStart(2, '0')).join('');
}
function hexToHsl(hex) {
  const n = parseInt(String(hex).replace('#', ''), 16) || 0;
  const r = (n >> 16) / 255, g = (n >> 8 & 255) / 255, b = (n & 255) / 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
  let h = 0, s = 0;
  if (d) {
    s = d / (1 - Math.abs(2 * l - 1));
    h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h = Math.round(h * 60); if (h < 0) h += 360;
  }
  return [h, Math.round(s * 100), Math.round(l * 100)];
}
function colorPicker(init) {
  return new Promise(res => {
    let done = false;
    let [h, s, l] = hexToHsl(/^#[0-9a-f]{6}$/i.test(init) ? init : '#5865f2');
    const s2 = openSheet(`<div id="cp-prev" class="cp-prev"></div>
      <div class="field"><label>الدرجة</label><input type="range" id="cp-h" min="0" max="360" class="cp-rng cp-hue"></div>
      <div class="field"><label>التشبّع</label><input type="range" id="cp-s" min="0" max="100" class="cp-rng"></div>
      <div class="field"><label>السطوع</label><input type="range" id="cp-l" min="0" max="100" class="cp-rng"></div>
      <div class="field"><label>كود اللون (HEX)</label><input type="text" id="cp-x" class="ltr" maxlength="7"></div>
      <div class="row"><button class="btn grow" id="cp-ok">اختيار</button><button class="btn sec grow" id="cp-no">إلغاء</button></div>`,
      { title: '🎨 اختر لوناً', onClose: () => { if (!done) { done = true; res(null); } } });
    const E = id => $('#' + id, s2.el);
    const paint = (fromHex) => {
      const hex = fromHex || hslToHex(h, s, l);
      E('cp-prev').style.background = hex; E('cp-prev').textContent = hex.toUpperCase();
      E('cp-s').style.background = `linear-gradient(90deg,${hslToHex(h, 0, l)},${hslToHex(h, 100, l)})`;
      E('cp-l').style.background = `linear-gradient(90deg,#000,${hslToHex(h, s, 50)},#fff)`;
      if (!fromHex) E('cp-x').value = hex;
      E('cp-h').value = h; E('cp-s').value = s; E('cp-l').value = l;
    };
    ['h', 's', 'l'].forEach(k => E('cp-' + k).addEventListener('input', e => { const v = +e.target.value; if (k === 'h') h = v; else if (k === 's') s = v; else l = v; paint(); }));
    E('cp-x').addEventListener('input', e => {
      let v = e.target.value.trim(); if (v[0] !== '#') v = '#' + v;
      if (/^#[0-9a-f]{6}$/i.test(v)) { [h, s, l] = hexToHsl(v); paint(v); E('cp-x').value = v; }
    });
    E('cp-ok').onclick = () => { done = true; const v = hslToHex(h, s, l); s2.close(); res(/^#[0-9a-f]{6}$/i.test(E('cp-x').value) ? E('cp-x').value.toLowerCase() : v); };
    E('cp-no').onclick = () => s2.close();
    paint();
  });
}

/* ---------- UI icon set: replaces decorative emoji in the interface with line icons ---------- */
const Icons = (() => {
  const P = {
    warn: '<path d="M12 4 3 20h18z"/><path d="M12 10v4M12 17h.01"/>', pencil: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
    bot: '<rect x="4" y="8" width="16" height="11" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9.5 16.5h5"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    palette: '<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2-.6-1.2 0-2.5 1.5-2.5H17a4 4 0 0 0 4-4c0-5-4-9.5-9-9.5z"/><circle cx="8" cy="11" r="1"/><circle cx="12" cy="7.5" r="1"/><circle cx="16" cy="11" r="1"/>',
    clip: '<path d="m20 11-8.5 8.5a5 5 0 0 1-7-7L13 4a3.5 3.5 0 0 1 5 5l-8.5 8.5a2 2 0 0 1-3-3L14 7"/>',
    shield: '<path d="M12 3 5 6v5c0 4.5 3 8 7 10 4-2 7-5.5 7-10V6z"/>', smile: '<circle cx="12" cy="12" r="9"/><path d="M8.5 14a4 4 0 0 0 7 0M9 9.5h.01M15 9.5h.01"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.5-4 3-6 6.5-6s6 2 6.5 6M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2 .6 3.3 2.5 3.5 6"/>',
    reply: '<path d="M9 8 4 13l5 5"/><path d="M4 13h9a7 7 0 0 1 7 7"/>', down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
    mega: '<path d="M3 11v3a1 1 0 0 0 1 1h3l8 4V6L7 10H4a1 1 0 0 0-1 1z"/><path d="M19 9a4 4 0 0 1 0 6"/>',
    eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>', check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3 1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8 1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    save: '<path d="M5 4h11l3 3v13H5z"/><path d="M8 4v5h7V4M8 20v-6h8v6"/>', file: '<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5"/>', bolt: '<path d="M13 3 5 14h6l-1 7 8-11h-6z"/>',
    chat: '<path d="M4 5h16v11H9l-5 4z"/>', door: '<path d="M10 4H5v16h5M15 8l4 4-4 4M19 12H9"/>', thread: '<path d="M5 6h14M5 12h10M5 18h6"/>',
    hammer: '<path d="m14 6 4 4-8 8-4-4zM13 7l3-3 4 4-3 3M5 19l2-2"/>', ban: '<circle cx="12" cy="12" r="9"/><path d="m6 6 12 12"/>',
    spk: '<path d="M4 10v4h4l5 4V6l-5 4z"/><path d="M16.5 9a4 4 0 0 1 0 6"/>', mute: '<path d="M4 10v4h4l5 4V6l-5 4z"/><path d="m16 9 5 6M21 9l-5 6"/>',
    pin: '<path d="M9 4h6l-1 6 3 3H7l3-3zM12 13v7"/>', clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', send: '<path d="M21 4 3 11l7 3 3 7zM10 14l11-10"/>',
    grid: '<rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><rect x="13" y="13" width="7" height="7" rx="1"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>', server: '<rect x="3" y="4" width="18" height="6" rx="2"/><rect x="3" y="14" width="18" height="6" rx="2"/><path d="M7 7h.01M7 17h.01"/>',
    crown: '<path d="m4 8 4 4 4-6 4 6 4-4-2 11H6z"/>', mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>', tag: '<path d="M3 12V4h8l10 10-8 8z"/><path d="M7.5 8h.01"/>',
    drop: '<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/><path d="M9.5 14.5a2.5 2.5 0 0 0 2.5 2.5"/>', heart: '<path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2 4 4 0 0 1 7 2c0 5.5-7 10-7 10z"/>', mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>', face: '<circle cx="12" cy="12" r="9"/><path d="M8.5 14a4 4 0 0 0 7 0M9 9.5h.01M15 9.5h.01"/>', hand: '<path d="M8 12V6a1.5 1.5 0 0 1 3 0v5M11 11V4.5a1.5 1.5 0 0 1 3 0V11M14 11V6a1.5 1.5 0 0 1 3 0v8a6 6 0 0 1-6 6c-3 0-4.5-1.5-6-4l-1.5-3a1.5 1.5 0 0 1 2.5-1.5L8 14"/>', leaf: '<path d="M5 19c0-9 5-14 15-14 0 10-5 15-14 15M5 19l7-7"/>', cup: '<path d="M5 8h11v6a5 5 0 0 1-5 5H10a5 5 0 0 1-5-5zM16 10h2a2 2 0 0 1 0 4h-2M8 3v2M12 3v2"/>', ball: '<circle cx="12" cy="12" r="9"/><path d="M12 3v18M3 12h18M5.5 5.5c4 3 9 3 13 0M5.5 18.5c4-3 9-3 13 0"/>', car: '<path d="M4 16V12l2-5h12l2 5v4zM4 16v2M20 16v2M7 13h.01M17 13h.01"/>', bulb: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10c1 1 1 2 1 3h6c0-1 0-2 1-3a6 6 0 0 0-4-10z"/>', sym: '<path d="M5 5h5v5H5zM14 5h5M16.5 5v5M5 14l5 5M10 14l-5 5M14 17h5M14 20h5"/>', flag: '<path d="M5 21V4M5 5h13l-2 4 2 4H5"/>', clip2: '<path d="M12 5v14M5 12h14"/>',
    folder: '<path d="M3 6h7l2 2h9v11H3z"/>', note: '<path d="M5 4h14v16H5z"/><path d="M8 9h8M8 13h8M8 17h5"/>', moon: '<path d="M20 14A8 8 0 0 1 10 4a8 8 0 1 0 10 10z"/>',
    quote: '<path d="M6 8h4v4c0 3-1 4-4 5M14 8h4v4c0 3-1 4-4 5"/>', image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.5"/><path d="m4 18 5-5 4 4 3-3 4 4"/>',
    dna: '<path d="M7 4c0 5 10 5 10 10s-10 5-10 10M17 4c0 5-10 5-10 10s10 5 10 10M8 8h8M8 16h8"/>', scale: '<path d="M12 4v16M6 20h12M5 7h14M5 7l-3 7a3 3 0 0 0 6 0zM19 7l-3 7a3 3 0 0 0 6 0z"/>', medal: '<circle cx="12" cy="15" r="5"/><path d="m9 3 3 6 3-6M12 12.5v5"/>', pin2: '<path d="M8 4h8v5l2 3H6l2-3zM12 12v8"/>', hourglass: '<path d="M7 3h10M7 21h10M8 3c0 5 4 6 4 9s-4 4-4 9M16 3c0 5-4 6-4 9s4 4 4 9"/>', radio: '<circle cx="12" cy="12" r="2"/><path d="M8 8a5.7 5.7 0 0 0 0 8M16 8a5.7 5.7 0 0 1 0 8M5 5a10 10 0 0 0 0 14M19 5a10 10 0 0 1 0 14"/>', eyeoff: '<path d="M3 3l18 18M10.6 6.2A9.8 9.8 0 0 1 12 6c6 0 10 6 10 6a17 17 0 0 1-3.2 3.8M6.5 7.6A17 17 0 0 0 2 12s4 6 10 6a9.8 9.8 0 0 0 4-.9M9.9 9.9a3 3 0 0 0 4.2 4.2"/>', caps: '<path d="M4 18 9 6l5 12M5.8 14h6.4M16 18l3-8 3 8M17 16h4"/>', num: '<path d="M9 4 7 20M17 4l-2 16M4 9h17M3 15h17"/>', receipt: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6"/>', square: '<rect x="5" y="5" width="14" height="14" rx="2" stroke-dasharray="3 3"/>', rocket: '<path d="M12 3c4 2 6 6 6 10l-3 3H9l-3-3c0-4 2-8 6-10zM9 16l-2 5 5-2M15 16l2 5-5-2"/><circle cx="12" cy="10" r="1.5"/>', braces: '<path d="M8 4c-3 0-3 2-3 4s0 3-2 4c2 1 2 2 2 4s0 4 3 4M16 4c3 0 3 2 3 4s0 3 2 4c-2 1-2 2-2 4s0 4-3 4"/>', inbox: '<path d="M3 13h5l1 3h6l1-3h5M5 5h14l2 8v6H3v-6z"/>', userq: '<circle cx="10" cy="8" r="3.5"/><path d="M3 20c.5-4 3-6 7-6M17 17a2 2 0 1 1 2 2v1M19 22h.01"/>', toolbox: '<rect x="3" y="8" width="18" height="12" rx="2"/><path d="M9 8V5h6v3M3 13h18"/>', target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>', swap: '<path d="M4 8h14l-3-3M20 16H6l3 3"/>', lines: '<path d="M5 6h14M5 10h14M5 14h10M5 18h7"/>', kbd: '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>', cool: '<circle cx="12" cy="12" r="9"/><path d="M6.5 10h4v2a2 2 0 0 1-4 0zM13.5 10h4v2a2 2 0 0 1-4 0zM10.5 10h3M9 16c1.5 1.2 4.5 1.2 6 0"/>', magnet: '<path d="M5 4v8a7 7 0 0 0 14 0V4h-4v8a3 3 0 0 1-6 0V4zM5 8h4M15 8h4"/>', calc: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01"/>', bricks: '<path d="M3 5h18v5H3zM3 14h18v5H3zM9 5v5M15 14v5"/>', prog: '<rect x="3" y="9" width="18" height="6" rx="3"/><path d="M6 12h8"/>', table: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 15h18M10 4v16"/>', trend: '<path d="m3 17 6-6 4 4 8-8M15 7h6v6"/>', flask: '<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 2 3h10a2 2 0 0 0 2-3l-5-9V3M8 15h8"/>', siren: '<path d="M7 18v-6a5 5 0 0 1 10 0v6M5 18h14v3H5zM12 3v2M4 6l1.5 1.5M20 6l-1.5 1.5"/>', map: '<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2zM9 4v14M15 6v14"/>', hashtag: '<path d="M5 9h14M5 15h14M9 4 7 20M17 4l-2 16"/>', triangle: '<path d="M3 20h18M5 20 19 6M5 20V6"/>',
    hash: '<path d="M5 9h14M5 15h14M9 4 7 20M17 4l-2 16"/>', key: '<circle cx="8" cy="14" r="4"/><path d="m11 11 9-9M16 6l3 3M14 8l3 3"/>', lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    ruler: '<rect x="2" y="8" width="20" height="8" rx="1.5"/><path d="M6 8v3M10 8v4M14 8v3M18 8v4"/>', book: '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h11"/>', txt: '<path d="M5 6h14M12 6v13M9 19h6"/>',
    gift: '<rect x="3" y="8" width="18" height="5" rx="1"/><path d="M5 13v7h14v-7M12 8v12M12 8c-2-4-6-3-5 0 .5 1.5 3 1 5 0zm0 0c2-4 6-3 5 0-.5 1.5-3 1-5 0z"/>', trophy: '<path d="M7 4h10v5a5 5 0 0 1-10 0zM7 6H4v1a3 3 0 0 0 3 3M17 6h3v1a3 3 0 0 1-3 3M12 14v4M8 20h8"/>',
    pad: '<rect x="2.5" y="7" width="19" height="11" rx="5"/><path d="M7 10v4M5 12h4M16 11h.01M18 13h.01"/>', dice: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8.5 8.5h.01M15.5 8.5h.01M12 12h.01M8.5 15.5h.01M15.5 15.5h.01"/>', chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    star: '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>', dots: '<path d="M5 12h.01M12 12h.01M19 12h.01"/>', plus: '<path d="M12 5v14M5 12h14"/>', cl: '<path d="m15 5-7 7 7 7"/>', cr: '<path d="m9 5 7 7-7 7"/>', cd: '<path d="m6 9 6 6 6-6"/>', play: '<path d="M8 5v14l11-7z"/>', stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>', code: '<path d="m8 8-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/>', globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>', ext: '<path d="M8 16 16 8M9 8h7v7"/>', x: '<path d="m6 6 12 12M18 6 6 18"/>', info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>', up: '<path d="M12 19V5M6 11l6-6 6 6"/>'
  };
  const M = { '⚠': 'warn', '✏': 'pencil', '🤖': 'bot', '📋': 'copy', '🗑': 'trash', '🧹': 'trash', '🪝': 'link', '🔗': 'link', '🎨': 'palette', '📎': 'clip', '🛡': 'shield', '😀': 'smile', '🎭': 'users', '👥': 'users', '👤': 'users', '↩': 'reply', '↪': 'reply', '⬇': 'down', '📢': 'mega', '👁': 'eye', '✔': 'check', '✅': 'check', '⚙': 'gear', '💾': 'save', '📄': 'file', '⚡': 'bolt', '💬': 'chat', '🚪': 'door', '👢': 'door', '🧵': 'thread', '🔨': 'hammer', '🛠': 'hammer', '⛔': 'ban', '🔊': 'spk', '🎙': 'spk', '🔇': 'mute', '📌': 'pin', '🕒': 'clock', '🕘': 'clock', '⏱': 'clock', '➤': 'send', '🧩': 'grid', '🔍': 'search', '🏰': 'server', '👑': 'crown', '✉': 'mail', '🏷': 'tag', '🗂': 'folder', '📁': 'folder', '📝': 'note', '📜': 'note', '🌙': 'moon', '❝': 'quote', '🖼': 'image', '🎞': 'image', '↗': 'ext', '❌': 'x', 'ℹ': 'info', '📥': 'down', '🆔': 'hash', '🔑': 'key', '🔒': 'lock', '🔞': 'ban', '📤': 'up', '🔐': 'lock', '📏': 'ruler', '📚': 'book', '📖': 'book', '🔤': 'txt', '🎁': 'gift', '🏆': 'trophy', '🎮': 'pad', '🎲': 'dice', '📊': 'chart', '⭐': 'star', '🌈': 'palette', '⋯': 'dots', '＋': 'plus', '✕': 'x', '✗': 'x', '✓': 'check', '‹': 'cl', '›': 'cr', '←': 'cl', '→': 'cr', '▾': 'cd', '▶': 'play', '⏹': 'stop', '↑': 'up', '↓': 'down', '💻': 'code', '🌐': 'globe', '📣': 'mega', '🔔': 'mega', '🧬': 'dna', '⚖': 'scale', '🏅': 'medal', '🧷': 'pin2', '⌛': 'hourglass', '⏳': 'hourglass', '📡': 'radio', '✍': 'pencil', '🇦': 'globe', '👏': 'smile', '🙈': 'eyeoff', '🔠': 'caps', '🔢': 'num', '🧾': 'receipt', '⬜': 'square', '👋': 'smile', '🖌': 'palette', '🚀': 'rocket', '🧑‍💻': 'code', '🚦': 'siren', '📨': 'inbox', '🔎': 'search', '🧰': 'toolbox', '🎯': 'target', '🔁': 'swap', '📑': 'lines', '⌨': 'kbd', '😎': 'cool', '🧲': 'magnet', '🧮': 'calc', '🧱': 'bricks', '▰': 'prog', '▤': 'table', '📈': 'trend', '🔬': 'flask', '🚨': 'siren', '🗺': 'map', '📐': 'triangle' };
  const D = { '🟢': 'g', '🟡': 'y', '⚫': 'k' };
  const RE = new RegExp('(' + Object.keys(M).concat(Object.keys(D)).join('|') + ')️?', 'g');
  const SKIP = '.uc,bdi,#i-name,.crumb .t,.mcontent,.embed,.rx,.reply,.chat-list .msg,textarea,input,select,script,style,.result,.em-grid,#em-tabs,.ep,[data-keep],.mcard textarea,.ed';
  const svg = k => `<svg class="ui-i" viewBox="0 0 24 24" aria-hidden="true">${P[k]}</svg>`;
  function apply(root) {
    if (!root || root.nodeType !== 1 && root.nodeType !== 3) return;
    const base = root.nodeType === 3 ? root.parentNode : root;
    if (!base || !base.closest || base.closest(SKIP)) return;
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: n => (n.nodeValue && RE.test(n.nodeValue) && !(RE.lastIndex = 0) && !n.parentNode.closest(SKIP)) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT });
    const nodes = []; while (w.nextNode()) nodes.push(w.currentNode);
    nodes.forEach(n => {
      const frag = document.createDocumentFragment(); let last = 0, m; const s = n.nodeValue; RE.lastIndex = 0;
      while ((m = RE.exec(s))) {
        if (m.index > last) frag.appendChild(document.createTextNode(s.slice(last, m.index)));
        const t = document.createElement('span'); const ch = m[1];
        if (D[ch]) { t.className = 'ui-dot ' + D[ch]; } else { t.className = 'ui-ic'; t.innerHTML = svg(M[ch]); }
        frag.appendChild(t); last = RE.lastIndex;
      }
      RE.lastIndex = 0;
      if (last < s.length) frag.appendChild(document.createTextNode(s.slice(last)));
      n.parentNode.replaceChild(frag, n);
    });
  }
  function install() {
    let busy = false;
    const mo = new MutationObserver(ms => {
      if (busy) return; busy = true;
      try { ms.forEach(r => { r.addedNodes.forEach(n => apply(n)); if (r.type === 'characterData') apply(r.target); }); mo.takeRecords(); } finally { busy = false; }
    });
    apply(document.body);
    mo.observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  const M2 = { '{ }': 'braces', '#⃣': 'hash', '#': 'hashtag' };
  const forEmoji = ch => { const c = String(ch || '').replace(/\uFE0F/g, ''), k = M[c] || M2[c]; return k ? svg(k) : null; };
  return { install, apply, svg, forEmoji };
})();

function lightbox(url) {
  if (!safeUrl(url)) return;
  const s = openSheet(`<div class="lb"><img src="${esc(url)}" alt=""><div class="row" style="margin-top:12px"><button class="btn sec grow" data-lb="open">فتح الرابط</button><button class="btn sec grow" data-lb="copy">نسخ الرابط</button></div></div>`, { title: 'معاينة الصورة' });
  s.el.querySelector('[data-lb=open]').onclick = () => openLink(url);
  s.el.querySelector('[data-lb=copy]').onclick = () => copyText(url);
}

/* ---------- Custom select: replaces the system dropdown with our own bottom-sheet list ---------- */
const Select = (() => {
  function label(sel) { const o = sel.options[sel.selectedIndex]; return o ? o.textContent : ''; }
  function sync(sel) { const b = sel._btn; if (b) { b.querySelector('.sv').textContent = label(sel); b.disabled = sel.disabled; } }
  function open(sel) {
    const ttl = (sel.closest('.field') && sel.closest('.field').querySelector('label')) ? sel.closest('.field').querySelector('label').textContent : 'اختر';
    const items = Array.from(sel.options).map((o, i) => {
      const parts = o.textContent.split(/\s[—–-]\s/); const main = parts[0], sub = parts.slice(1).join(' — ');
      return `<button class="sel-i ${i === sel.selectedIndex ? 'on' : ''}" data-i="${i}"><span class="sel-t"><b>${esc(main)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</span><span class="sel-c">${Icons.svg('check')}</span></button>`;
    }).join('');
    const s = openSheet(`<div class="sel-list">${items}</div>`, { title: ttl });
    s.el.addEventListener('click', e => {
      const b = e.target.closest('.sel-i'); if (!b) return;
      sel.selectedIndex = +b.dataset.i; sync(sel);
      sel.dispatchEvent(new Event('change', { bubbles: true })); sel.dispatchEvent(new Event('input', { bubbles: true }));
      s.close();
    });
    const on = s.el.querySelector('.sel-i.on'); if (on) setTimeout(() => on.scrollIntoView({ block: 'center' }), 30);
  }
  function upgrade(sel) {
    if (sel._btn || sel.multiple) return;
    const b = document.createElement('button'); b.type = 'button'; b.className = 'sel-btn';
    b.innerHTML = `<span class="sv"></span>${Icons.svg('cd')}`;
    b.addEventListener('click', () => open(sel));
    sel.style.display = 'none'; sel.after(b); sel._btn = b;
    const d = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value');
    Object.defineProperty(sel, 'value', { get() { return d.get.call(this); }, set(v) { d.set.call(this, v); sync(this); }, configurable: true });
    sync(sel);
  }
  function scan(root) { (root || document).querySelectorAll('select').forEach(upgrade); }
  function install() {
    scan(document);
    new MutationObserver(ms => { for (const m of ms) m.addedNodes.forEach(n => { if (n.nodeType === 1) { if (n.tagName === 'SELECT') upgrade(n); else if (n.querySelector) scan(n); } }); }).observe(document.body, { childList: true, subtree: true });
  }
  return { install, sync };
})();

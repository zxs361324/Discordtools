'use strict';
/* ============================================================
   tools.js — the tool catalogue (local utilities + API lookups)
   ============================================================ */
const Tools = (() => {
  let root = null, active = null, cat = 'الكل', query = '';
  const CATS = ['الكل', 'المعرفات', 'الوقت', 'الصلاحيات', 'النصوص', 'الألوان', 'السيرفر', 'البوتات', 'API', 'أدوات عامة'];
  const LIST = [];
  const LOCAL = ['المعرفات', 'الوقت', 'الصلاحيات', 'النصوص', 'الألوان', 'أدوات عامة'];
  const TOK = { id: 'token', l: 'توكن البوت', k: 'pass', d: () => Tokens.get() };
  const T = (id, ico, name, desc, c, fields, run, o) => LIST.push(Object.assign({ id, ico, name, desc, cat: c, fields: fields || [], run }, o || {}));
  const F = (id, l, p, k, d, o) => ({ id, l, p, k, d, o });
  const big = s => { try { return BigInt(String(s).trim()); } catch (e) { throw new Error('رقم غير صالح'); } };
  const dt = ms => new Date(ms).toLocaleString(LOC);
  const idCheck = (s, n) => { s = String(s || '').trim(); if (!isId(s)) throw new Error((n || 'ID') + ' غير صالح (15–25 رقماً)'); return s; };
  const bits = (n, table) => table.filter(([, b]) => (n & b) === b && b !== 0n).map(([name]) => name);

  const PERMS = [['Create Invite', 0], ['Kick Members', 1], ['Ban Members', 2], ['Administrator', 3], ['Manage Channels', 4], ['Manage Guild', 5], ['Add Reactions', 6], ['View Audit Log', 7], ['Priority Speaker', 8], ['Stream', 9], ['View Channel', 10], ['Send Messages', 11], ['Send TTS', 12], ['Manage Messages', 13], ['Embed Links', 14], ['Attach Files', 15], ['Read Message History', 16], ['Mention Everyone', 17], ['Use External Emojis', 18], ['View Guild Insights', 19], ['Connect', 20], ['Speak', 21], ['Mute Members', 22], ['Deafen Members', 23], ['Move Members', 24], ['Use VAD', 25], ['Change Nickname', 26], ['Manage Nicknames', 27], ['Manage Roles', 28], ['Manage Webhooks', 29], ['Manage Expressions', 30], ['Use Application Commands', 31], ['Request to Speak', 32], ['Manage Events', 33], ['Manage Threads', 34], ['Create Public Threads', 35], ['Create Private Threads', 36], ['Use External Stickers', 37], ['Send in Threads', 38], ['Use Activities', 39], ['Moderate Members', 40], ['Use Soundboard', 42], ['Create Expressions', 43], ['Create Events', 44], ['Use External Sounds', 45], ['Send Voice Messages', 46], ['Send Polls', 49], ['Use External Apps', 50]].map(([n, b]) => [n, 1n << BigInt(b)]);
  const INTENTS = [['GUILDS', 0], ['GUILD_MEMBERS 🔒', 1], ['GUILD_MODERATION', 2], ['GUILD_EXPRESSIONS', 3], ['GUILD_INTEGRATIONS', 4], ['GUILD_WEBHOOKS', 5], ['GUILD_INVITES', 6], ['GUILD_VOICE_STATES', 7], ['GUILD_PRESENCES 🔒', 8], ['GUILD_MESSAGES', 9], ['GUILD_MESSAGE_REACTIONS', 10], ['GUILD_MESSAGE_TYPING', 11], ['DIRECT_MESSAGES', 12], ['DIRECT_MESSAGE_REACTIONS', 13], ['DIRECT_MESSAGE_TYPING', 14], ['MESSAGE_CONTENT 🔒', 15], ['GUILD_SCHEDULED_EVENTS', 16], ['AUTO_MODERATION_CONFIGURATION', 20], ['AUTO_MODERATION_EXECUTION', 21], ['GUILD_MESSAGE_POLLS', 24], ['DIRECT_MESSAGE_POLLS', 25]].map(([n, b]) => [n, 1n << BigInt(b)]);
  const USER_FLAGS = [['Discord Staff', 0], ['Partnered Server Owner', 1], ['HypeSquad Events', 2], ['Bug Hunter Lv1', 3], ['HypeSquad Bravery', 6], ['HypeSquad Brilliance', 7], ['HypeSquad Balance', 8], ['Early Supporter', 9], ['Team User', 10], ['Bug Hunter Lv2', 14], ['Verified Bot', 16], ['Early Verified Bot Dev', 17], ['Moderator Programs Alumni', 18], ['Bot uses HTTP Interactions', 19], ['Active Developer', 22]].map(([n, b]) => [n, 1n << BigInt(b)]);

  /* ---- fancy text ---- */
  const A = 'abcdefghijklmnopqrstuvwxyz';
  function alpha(s, up, lo, dg, exc) {
    return Array.from(s).map(ch => {
      if (exc && exc[ch]) return exc[ch];
      const c = ch.codePointAt(0);
      if (c >= 65 && c <= 90 && up != null) return String.fromCodePoint(up + c - 65);
      if (c >= 97 && c <= 122 && lo != null) return String.fromCodePoint(lo + c - 97);
      if (c >= 48 && c <= 57 && dg != null) return String.fromCodePoint(dg + c - 48);
      return ch;
    }).join('');
  }
  const fromMap = (s, from, to) => Array.from(s).map(ch => { const i = from.indexOf(ch.toLowerCase()); return i >= 0 ? Array.from(to)[i] : ch; }).join('');
  const STYLES = {
    'عريض': s => alpha(s, 0x1D400, 0x1D41A, 0x1D7CE), 'مائل': s => alpha(s, 0x1D434, 0x1D44E, null, { h: 'ℎ' }), 'عريض مائل': s => alpha(s, 0x1D468, 0x1D482),
    'Sans عريض': s => alpha(s, 0x1D5D4, 0x1D5EE, 0x1D7EC), 'Monospace': s => alpha(s, 0x1D670, 0x1D68A, 0x1D7F6),
    'Script': s => alpha(s, 0x1D49C, 0x1D4B6, null, { B: 'ℬ', E: 'ℰ', F: 'ℱ', H: 'ℋ', I: 'ℐ', L: 'ℒ', M: 'ℳ', R: 'ℛ', e: 'ℯ', g: 'ℊ', o: 'ℴ' }),
    'Double-struck': s => alpha(s, 0x1D538, 0x1D552, 0x1D7D8, { C: 'ℂ', H: 'ℍ', N: 'ℕ', P: 'ℙ', Q: 'ℚ', R: 'ℝ', Z: 'ℤ' }),
    'Gothic': s => alpha(s, 0x1D504, 0x1D51E, null, { C: 'ℭ', H: 'ℌ', I: 'ℑ', R: 'ℜ', Z: 'ℨ' }),
    'دائري': s => alpha(s, 0x24B6, 0x24D0), 'عريض واسع': s => alpha(s, 0xFF21, 0xFF41, 0xFF10), 'Small Caps': s => fromMap(s, A, 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ'),
    'مقلوب': s => Array.from(fromMap(s, A + '?!.,', 'ɐqɔpǝɟɓɥᴉɾʞlɯuodbɹsʇnʌʍxʎz¿¡˙\'')).reverse().join(''),
    'مشطوب': s => Array.from(s).map(c => c + '̶').join(''), 'تحته خط': s => Array.from(s).map(c => c + '̲').join(''),
    'نقاط': s => Array.from(s).map(c => c + '̇').join(''), 'Zalgo': s => Array.from(s).map(c => c + '̀́̂̃̈̊'.split('').sort(() => Math.random() - .5).slice(0, 3).join('')).join('')
  };

  /* ================= المعرفات ================= */
  T('snow', '🆔', 'محلل Snowflake', 'تاريخ الإنشاء ومعرّف العامل من أي ID', 'المعرفات', [F('v', 'Discord ID', '80351110224678912')], v => {
    const id = big(idCheck(v.v)), ms = Number((id >> 22n) + 1420070400000n);
    return `التاريخ: ${dt(ms)}\nUTC: ${new Date(ms).toUTCString()}\nUnix: ${Math.floor(ms / 1000)}\n<t:${Math.floor(ms / 1000)}:F>\nWorker: ${(id >> 17n) & 31n}  Process: ${(id >> 12n) & 31n}  Increment: ${id & 4095n}`;
  });
  T('snowgen', '🧬', 'مولّد Snowflake من تاريخ', 'أصغر ID يوافق وقتاً معيناً (للبحث/الحذف الجماعي)', 'المعرفات', [F('d', 'التاريخ والوقت', '', 'date')], v => {
    if (!v.d) throw new Error('اختر التاريخ'); const ms = new Date(v.d).getTime();
    return String((BigInt(ms) - 1420070400000n) << 22n);
  });
  T('cmpid', '⚖️', 'مقارنة معرفين', 'أيهما أقدم وبفارق كم', 'المعرفات', [F('a', 'ID الأول', ''), F('b', 'ID الثاني', '')], v => {
    const a = snowflakeMs(idCheck(v.a)), b = snowflakeMs(idCheck(v.b)), d = Math.abs(a - b);
    const days = Math.floor(d / 864e5), h = Math.floor(d % 864e5 / 36e5), m = Math.floor(d % 36e5 / 6e4);
    return `${a < b ? 'الأول أقدم' : a > b ? 'الثاني أقدم' : 'متساويان'}\nالفارق: ${days} يوم و ${h} ساعة و ${m} دقيقة`;
  });
  T('token', '🔑', 'معرّف البوت من التوكن', 'استخراج ID وتاريخ إنشاء الحساب (محلياً)', 'المعرفات', [F('t', 'التوكن', '', 'pass', () => Tokens.get())], v => {
    const p = v.t.trim().split('.')[0]; let id;
    try { id = atob(p.replace(/-/g, '+').replace(/_/g, '/')); } catch (e) { throw new Error('توكن غير صالح'); }
    if (!isId(id)) throw new Error('الجزء الأول ليس ID صالحاً');
    return `Bot/User ID: ${id}\nأُنشئ: ${dt(snowflakeMs(id))}`;
  });
  T('flags', '🏅', 'شارات المستخدم', 'فك public_flags إلى شارات', 'المعرفات', [F('n', 'قيمة flags', '64')], v => { const l = bits(big(v.n || 0), USER_FLAGS); return l.length ? l.map(x => '• ' + x).join('\n') : 'لا شارات'; });
  T('msglink', '🔗', 'محلل رابط رسالة', 'استخراج Guild/Channel/Message من الرابط', 'المعرفات', [F('u', 'رابط الرسالة', 'https://discord.com/channels/…')], v => {
    const m = /channels\/(@me|\d+)\/(\d+)(?:\/(\d+))?/.exec(v.u); if (!m) throw new Error('رابط غير صالح');
    return `Guild: ${m[1]}\nChannel: ${m[2]}\nMessage: ${m[3] || '—'}${m[3] ? '\nأُرسلت: ' + dt(snowflakeMs(m[3])) : ''}`;
  });
  T('msgbuild', '🧷', 'منشئ رابط رسالة/قناة', 'تجميع الرابط من المعرفات', 'المعرفات', [F('g', 'Guild ID', ''), F('c', 'Channel ID', ''), F('m', 'Message ID (اختياري)', '')], v => `https://discord.com/channels/${idCheck(v.g)}/${idCheck(v.c)}${v.m ? '/' + idCheck(v.m) : ''}`);
  T('avatar', '🖼️', 'روابط الصور (CDN)', 'أفاتار، بانر، أيقونة سيرفر', 'المعرفات', [F('k', 'النوع', '', 'select', 'avatars', [['avatars', 'صورة مستخدم'], ['banners', 'بانر مستخدم'], ['icons', 'أيقونة سيرفر'], ['splashes', 'خلفية دعوة سيرفر']]), F('i', 'ID', ''), F('h', 'Hash', 'a_… أو hash'), F('s', 'الحجم', '', 'select', '1024', [[128, 128], [256, 256], [512, 512], [1024, 1024], [2048, 2048]])], v => {
    const ext = v.h.startsWith('a_') ? 'gif' : 'png'; idCheck(v.i); if (!/^\w{8,}$/.test(v.h.trim())) throw new Error('Hash غير صالح');
    return `${CDN}/${v.k}/${v.i}/${v.h.trim()}.${ext}?size=${v.s}\n${CDN}/${v.k}/${v.i}/${v.h.trim()}.webp?size=${v.s}`;
  });
  T('defav', '👤', 'الصورة الافتراضية', 'أي صورة افتراضية تخص ID', 'المعرفات', [F('i', 'User ID', '')], v => `${CDN}/embed/avatars/${(big(idCheck(v.i)) >> 22n) % 6n}.png`);
  T('emojiurl', '😀', 'رابط إيموجي مخصص', 'من <:name:id> إلى رابط الصورة', 'المعرفات', [F('e', 'الإيموجي', '<:name:123456789012345678>')], v => {
    const m = /<?(a?):?(\w+):(\d{15,25})>?/.exec(v.e) || /^(\d{15,25})$/.exec(v.e); if (!m) throw new Error('صيغة غير صالحة');
    const id = m[3] || m[1], an = m[1] === 'a';
    return `${CDN}/emojis/${id}.${an ? 'gif' : 'png'}?size=128&quality=lossless\n${CDN}/emojis/${id}.webp?size=128`;
  });

  /* ================= الوقت ================= */
  T('ts', '🕒', 'مولّد Timestamp', 'كل صيغ <t:…> مع معاينة', 'الوقت', [F('d', 'التاريخ والوقت', '', 'date')], v => {
    if (!v.d) throw new Error('اختر التاريخ'); const n = Math.floor(new Date(v.d).getTime() / 1000);
    return { text: ['t', 'T', 'd', 'D', 'f', 'F', 'R'].map(f => `<t:${n}:${f}>   ←  ${fmtTs(n, f)}`).join('\n') };
  });
  T('unix', '⌛', 'تحويل Unix', 'ثوانٍ أو مللي ثانية إلى تاريخ', 'الوقت', [F('n', 'Unix timestamp', '1730000000')], v => {
    let n = Number(v.n); if (!Number.isFinite(n)) throw new Error('رقم غير صالح'); if (n < 1e12) n *= 1000; const d = new Date(n);
    return `${d.toLocaleString(LOC)}\nUTC: ${d.toUTCString()}\nISO: ${d.toISOString()}\n<t:${Math.floor(n / 1000)}:F>`;
  });
  T('countdown', '⏳', 'عدّاد تنازلي', 'بعد مدة من الآن → Timestamp نسبي', 'الوقت', [F('d', 'أيام', '0', 'num', 0), F('h', 'ساعات', '', 'num', 1), F('m', 'دقائق', '', 'num', 0)], v => {
    const n = Math.floor(Date.now() / 1000 + (+v.d || 0) * 86400 + (+v.h || 0) * 3600 + (+v.m || 0) * 60);
    return `<t:${n}:R>\n<t:${n}:F>\nUnix: ${n}`;
  });
  T('timediff', '📏', 'الفرق بين وقتين', 'مدة بين تاريخين', 'الوقت', [F('a', 'من', '', 'date'), F('b', 'إلى', '', 'date')], v => {
    if (!v.a || !v.b) throw new Error('اختر التاريخين'); const d = Math.abs(new Date(v.b) - new Date(v.a));
    return `${Math.floor(d / 864e5)} يوم، ${Math.floor(d % 864e5 / 36e5)} ساعة، ${Math.floor(d % 36e5 / 6e4)} دقيقة\n= ${Math.floor(d / 1000)} ثانية`;
  });
  T('timeout', '🔇', 'مدة الكتم (Timeout)', 'احسب تاريخ انتهاء الكتم ISO', 'الوقت', [F('m', 'بالدقائق', '60', 'num', 60)], v => {
    const m = +v.m; if (!(m > 0 && m <= 40320)) throw new Error('الحد الأقصى 28 يوماً (40320 دقيقة)');
    return new Date(Date.now() + m * 60000).toISOString();
  });

  /* ================= الصلاحيات ================= */
  T('perms', '🛡️', 'حاسبة الصلاحيات', 'اختر الصلاحيات واحصل على الرقم ورابط الدعوة', 'الصلاحيات', [], null, {
    custom: {
      html: `<div class="field"><input id="pc-s" type="text" placeholder="فلترة…" oninput="document.querySelectorAll('#pc-l label').forEach(l=>l.style.display=l.textContent.toLowerCase().includes(this.value.toLowerCase())?'':'none')"></div>
      <div id="pc-l">${PERMS.map(([n, b]) => `<label class="switch"><span>${n}</span><input type="checkbox" data-v="${b}"></label>`).join('')}</div>
      <div class="field"><label>Client ID (اختياري لرابط الدعوة)</label><input id="pc-c" class="ltr" type="text"></div><button class="btn block" data-act="tool.permcalc">احسب</button><div id="t-out"></div>`
    }
  });
  T('permdec', '🔍', 'فك رقم الصلاحيات', 'من الرقم إلى قائمة الصلاحيات', 'الصلاحيات', [F('n', 'permissions integer', '8')], v => { const n = big(v.n); const l = bits(n, PERMS); return l.length ? `${l.length} صلاحية:\n` + l.map(x => '• ' + x).join('\n') : 'لا صلاحيات'; });
  T('intents', '📡', 'حاسبة Gateway Intents', 'اختر الـ intents واحصل على الرقم', 'الصلاحيات', [], null, {
    custom: { html: `${INTENTS.map(([n, b]) => `<label class="switch"><span>${n}</span><input type="checkbox" data-v="${b}"></label>`).join('')}<button class="btn block" data-act="tool.intcalc">احسب</button><div class="sub" style="margin-top:8px">🔒 = يحتاج تفعيلاً من Developer Portal</div><div id="t-out"></div>` }
  });
  T('invite', '🤖', 'رابط دعوة البوت', 'OAuth2 مع النطاقات والصلاحيات', 'الصلاحيات', [F('c', 'Client ID', ''), F('p', 'Permissions', '0', 'text', '0'), F('s', 'النطاق', '', 'select', 'bot applications.commands', [['bot applications.commands', 'bot + أوامر slash'], ['bot', 'bot فقط'], ['applications.commands', 'أوامر slash فقط']])], v => `https://discord.com/oauth2/authorize?client_id=${idCheck(v.c, 'Client ID')}&permissions=${/^\d+$/.test(v.p || '0') ? v.p || '0' : (() => { throw new Error('permissions غير صالح'); })()}&scope=${encodeURIComponent(v.s)}`);
  T('chtypes', '📚', 'أنواع القنوات والرسائل', 'مرجع سريع للأرقام', 'الصلاحيات', [], () => '0 = Text\n1 = DM\n2 = Voice\n3 = Group DM\n4 = Category\n5 = Announcement\n10/11/12 = Threads\n13 = Stage\n14 = Directory\n15 = Forum\n16 = Media\n\nButton styles: 1 Primary · 2 Secondary · 3 Success · 4 Danger · 5 Link', { auto: true });

  /* ================= النصوص ================= */
  T('md', '✍️', 'معاينة Markdown', 'اكتب وشاهد النتيجة كما في ديسكورد', 'النصوص', [], null, {
    custom: {
      html: `<div class="field"><textarea id="mdp-t" rows="6" class="ltr" placeholder="**عريض** _مائل_ ||سبويلر|| \`code\`&#10;# عنوان&#10;> اقتباس"></textarea></div><div class="msg first" style="padding:0"><div class="mb"><div class="mcontent" id="mdp-o" dir="auto"></div></div></div>`,
      init(el) { const t = $('#mdp-t', el), o = $('#mdp-o', el); t.addEventListener('input', () => { o.innerHTML = md(t.value); autoGrow(t); }); }
    }
  });
  T('fancy', '🔤', 'مزخرف النصوص', 'خطوط Unicode: عريض، مائل، Script…', 'النصوص', [F('t', 'النص (إنجليزي)', 'Hello World', 'area')], v => Object.keys(STYLES).map(k => `${k}:\n${STYLES[k](v.t)}`).join('\n\n'));
  T('ansi', '🌈', 'نص ملوّن (ANSI)', 'كتلة كود بألوان داخل ديسكورد', 'النصوص', [F('t', 'النص', 'Hello', 'area'), F('fg', 'لون النص', '', 'select', '31', [[30, 'رمادي'], [31, 'أحمر'], [32, 'أخضر'], [33, 'أصفر'], [34, 'أزرق'], [35, 'وردي'], [36, 'سماوي'], [37, 'أبيض']]), F('bg', 'الخلفية', '', 'select', '', [['', 'بدون'], [40, 'داكنة'], [41, 'برتقالي'], [42, 'رمادي'], [43, 'رمادي فاتح'], [44, 'رمادي أفتح'], [45, 'نيلي'], [46, 'رمادي مفتوح'], [47, 'أبيض']]), F('f', 'التنسيق', '', 'select', '0', [[0, 'عادي'], [1, 'عريض'], [4, 'تحته خط']])], v => `\`\`\`ansi\n\u001b[${v.f};${v.fg}${v.bg ? ';' + v.bg : ''}m${v.t}\u001b[0m\n\`\`\``);
  T('mention', '📣', 'منشئ المنشن', 'مستخدم، رتبة، قناة، أمر slash', 'النصوص', [F('k', 'النوع', '', 'select', 'u', [['u', 'مستخدم'], ['r', 'رتبة'], ['c', 'قناة'], ['s', 'أمر Slash']]), F('i', 'ID', ''), F('n', 'اسم الأمر (للـ Slash)', 'ping')], v => ({ u: `<@${idCheck(v.i)}>`, r: `<@&${idCheck(v.i)}>`, c: `<#${idCheck(v.i)}>`, s: `</${v.n || 'cmd'}:${idCheck(v.i)}>` })[v.k]);
  T('regional', '🇦', 'حروف إيموجي', 'تحويل النص الإنجليزي لحروف 🇦🇧', 'النصوص', [F('t', 'النص', 'hello')], v => Array.from(v.t.toLowerCase()).map(c => /[a-z]/.test(c) ? String.fromCodePoint(0x1F1E6 + c.charCodeAt(0) - 97) + '​' : /\d/.test(c) ? c + '️⃣' : c === ' ' ? '   ' : c).join(''));
  T('clap', '👏', 'تفصيل بالإيموجي', 'ضع إيموجي بين الكلمات', 'النصوص', [F('t', 'النص', 'كلمة كلمة'), F('e', 'الإيموجي', '', 'text', '👏')], v => v.t.trim().split(/\s+/).join(` ${v.e || '👏'} `) + ` ${v.e || '👏'}`);
  T('spoiler', '🙈', 'إخفاء النص (Spoiler)', 'كل النص أو كل حرف على حدة', 'النصوص', [F('t', 'النص', '', 'area'), F('m', 'الوضع', '', 'select', 'all', [['all', 'الكل ||…||'], ['chars', 'كل حرف'], ['words', 'كل كلمة']])], v => v.m === 'all' ? `||${v.t}||` : v.m === 'words' ? v.t.split(/(\s+)/).map(w => w.trim() ? `||${w}||` : w).join('') : Array.from(v.t).map(c => c.trim() ? `||${c}||` : c).join(''));
  T('case', '🔠', 'تحويل حالة الأحرف', 'UPPER, lower, Title, snake, kebab', 'النصوص', [F('t', 'النص', '', 'area')], v => `UPPER: ${v.t.toUpperCase()}\nlower: ${v.t.toLowerCase()}\nTitle: ${v.t.toLowerCase().replace(/\b\w/g, c => c.toUpperCase())}\nsnake_case: ${v.t.trim().toLowerCase().replace(/\s+/g, '_')}\nkebab-case: ${v.t.trim().toLowerCase().replace(/\s+/g, '-')}\ncamelCase: ${v.t.trim().toLowerCase().replace(/\s+(\w)/g, (m, c) => c.toUpperCase())}`);
  T('chars', '🔢', 'عدّاد الأحرف والحدود', 'مقارنة مع حدود Discord', 'النصوص', [F('t', 'النص', '', 'area')], v => {
    const n = Array.from(v.t).length; const l = (name, max) => `${n <= max ? '✅' : '❌'} ${name}: ${n}/${max}`;
    return [l('رسالة عادية', 2000), l('وصف Embed', 4096), l('عنوان Embed', 256), l('قيمة حقل', 1024), l('تذييل', 2048), l('اسم قناة', 100), l('لقب', 32), l('وصف السيرفر', 120)].join('\n') + `\nكلمات: ${v.t.trim() ? v.t.trim().split(/\s+/).length : 0}\nأسطر: ${v.t.split('\n').length}`;
  });
  T('codeblk', '🧾', 'كتلة كود', 'تغليف النص بـ ```lang', 'النصوص', [F('l', 'اللغة', 'js'), F('t', 'الكود', '', 'area')], v => '```' + (v.l || '') + '\n' + v.t + '\n```');
  T('chname', '🏷️', 'زخرفة أسماء القنوات', 'أنماط جاهزة لأسماء القنوات', 'النصوص', [F('n', 'الاسم', 'general')], v => {
    const n = v.n.trim().toLowerCase().replace(/\s+/g, '-'); return ['・', '┃', '│', '｜', '»', '⌈', '✦-', '🔹｜', '💬｜', '📌｜'].map(p => p + n).join('\n') + '\n\n' + STYLES['Small Caps'](n) + '\n' + n.toUpperCase();
  });
  T('zws', '⬜', 'حرف فارغ / مسافة خفية', 'نسخ حرف لا يُرى (لأسماء ورسائل فارغة)', 'النصوص', [], () => '​', { auto: true, copyNote: 'نُسخ حرف بعرض صفر' });
  T('rules', '📜', 'مولّد قوانين السيرفر', 'قوانين جاهزة بتنسيق ديسكورد', 'النصوص', [F('n', 'اسم السيرفر', 'My Server'), F('l', 'اللغة', '', 'select', 'ar', [['ar', 'عربي'], ['en', 'English']])], v => v.l === 'ar' ? `# 📜 قوانين ${v.n}\n**1.** احترم جميع الأعضاء ولا تسيء لأحد.\n**2.** ممنوع السبام والإعلانات بدون إذن.\n**3.** لا للمحتوى غير اللائق أو العنيف.\n**4.** استخدم القنوات في مواضعها.\n**5.** ممنوع مشاركة معلومات شخصية.\n**6.** اتبع تعليمات الإدارة وشروط Discord.\n-# مخالفة القوانين قد تؤدي إلى كتم أو طرد أو حظر.` : `# 📜 ${v.n} Rules\n**1.** Be respectful to everyone.\n**2.** No spam or unauthorized advertising.\n**3.** No NSFW or violent content.\n**4.** Keep topics in the right channels.\n**5.** Never share personal information.\n**6.** Follow staff instructions and Discord's Terms.\n-# Breaking rules may lead to mute, kick or ban.`);
  T('welcome', '👋', 'رسالة ترحيب (Embed JSON)', 'JSON جاهز للصق في المرسل', 'النصوص', [F('n', 'اسم السيرفر', 'My Server'), F('t', 'النص', 'أهلاً بك! اقرأ القوانين وتعرّف على الأعضاء.', 'area')], v => JSON.stringify({ embeds: [{ title: `👋 مرحباً بك في ${v.n}`, description: v.t, color: 5793266, footer: { text: v.n } }] }, null, 2), { sendToComposer: true });
  T('poll', '📊', 'منشئ تصويت', 'سؤال وخيارات برقم إيموجي', 'النصوص', [F('q', 'السؤال', ''), F('o', 'الخيارات (سطر لكل خيار)', '', 'area')], v => {
    const o = v.o.split('\n').map(x => x.trim()).filter(Boolean).slice(0, 10); if (o.length < 2) throw new Error('أضف خيارين على الأقل');
    return `📊 **${v.q}**\n\n` + o.map((x, i) => `${['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'][i]} ${x}`).join('\n');
  });
  T('giveaway', '🎁', 'منشئ مسابقة (Giveaway)', 'Embed JSON جاهز', 'النصوص', [F('p', 'الجائزة', 'Nitro'), F('w', 'عدد الفائزين', '1', 'num', 1), F('d', 'تنتهي في', '', 'date')], v => {
    if (!v.d) throw new Error('اختر وقت الانتهاء'); const n = Math.floor(new Date(v.d) / 1000);
    return JSON.stringify({ embeds: [{ title: `🎁 ${v.p}`, description: `تفاعل بـ 🎉 للدخول!\n\n⏰ تنتهي: <t:${n}:R> (<t:${n}:F>)\n🏆 الفائزون: **${v.w}**`, color: 16705372 }] }, null, 2);
  }, { sendToComposer: true });

  /* ================= الألوان ================= */
  T('color', '🎨', 'محول الألوان', 'HEX · RGB · HSL · رقم Embed', 'الألوان', [F('c', 'اللون', '#5865F2 أو rgb(88,101,242) أو رقم')], v => {
    let s = v.c.trim(), r, g, b, m;
    if ((m = /^#?([0-9a-f]{6})$/i.exec(s))) { const n = parseInt(m[1], 16); r = n >> 16; g = n >> 8 & 255; b = n & 255; }
    else if ((m = /^#?([0-9a-f]{3})$/i.exec(s))) { const x = m[1]; r = parseInt(x[0] + x[0], 16); g = parseInt(x[1] + x[1], 16); b = parseInt(x[2] + x[2], 16); }
    else if ((m = /^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/i.exec(s))) { r = +m[1]; g = +m[2]; b = +m[3]; }
    else if (/^\d+$/.test(s) && +s <= 16777215) { const n = +s; r = n >> 16; g = n >> 8 & 255; b = n & 255; }
    else throw new Error('صيغة لون غير مفهومة');
    const mx = Math.max(r, g, b) / 255, mn = Math.min(r, g, b) / 255, l = (mx + mn) / 2, d = mx - mn; let h = 0, sa = 0;
    if (d) { sa = d / (1 - Math.abs(2 * l - 1)); const R = r / 255, G = g / 255, B2 = b / 255; h = mx === R ? ((G - B2) / d) % 6 : mx === G ? (B2 - R) / d + 2 : (R - G) / d + 4; h = Math.round(h * 60); if (h < 0) h += 360; }
    const hex = '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('').toUpperCase();
    return { html: `<div style="height:54px;border-radius:10px;background:${hex};border:1px solid #555;margin-bottom:10px"></div><div class="result">HEX: ${hex}\nRGB: rgb(${r}, ${g}, ${b})\nHSL: hsl(${h}, ${Math.round(sa * 100)}%, ${Math.round(l * 100)}%)\nEmbed color (decimal): ${(r << 16) + (g << 8) + b}</div>`, text: `${hex}\n${(r << 16) + (g << 8) + b}` };
  });
  T('contrast', '👁️', 'فحص التباين (WCAG)', 'وضوح النص على الخلفية', 'الألوان', [F('a', 'لون النص', '#FFFFFF'), F('b', 'لون الخلفية', '#313338')], v => {
    const lum = h => { const n = parseInt(h.replace('#', ''), 16); return [n >> 16, n >> 8 & 255, n & 255].map(x => { x /= 255; return x <= .03928 ? x / 12.92 : Math.pow((x + .055) / 1.055, 2.4); }).reduce((a, x, i) => a + x * [.2126, .7152, .0722][i], 0); };
    if (!/^#?[0-9a-f]{6}$/i.test(v.a.trim()) || !/^#?[0-9a-f]{6}$/i.test(v.b.trim())) throw new Error('استخدم HEX من 6 خانات'); const A1 = lum(v.a.trim()), B1 = lum(v.b.trim()), r = (Math.max(A1, B1) + .05) / (Math.min(A1, B1) + .05);
    return `النسبة: ${r.toFixed(2)}:1\nAA نص عادي: ${r >= 4.5 ? '✅' : '❌'}\nAA نص كبير: ${r >= 3 ? '✅' : '❌'}\nAAA: ${r >= 7 ? '✅' : '❌'}`;
  });
  T('palette', '🖌️', 'ألوان ديسكورد', 'مرجع الألوان الرسمية الشائعة', 'الألوان', [], () => ({ html: [['Blurple', '#5865F2'], ['Green', '#57F287'], ['Yellow', '#FEE75C'], ['Fuchsia', '#EB459E'], ['Red', '#ED4245'], ['White', '#FFFFFF'], ['Black', '#000000'], ['Dark BG', '#313338'], ['Darker', '#2B2D31'], ['Darkest', '#1E1F22'], ['Online', '#23A55A'], ['Idle', '#F0B232'], ['DND', '#F23F43']].map(([n, c]) => `<div class="list-item" data-act="tool.copy" data-t="${c}"><span class="ph" style="background:${c};border:1px solid #555"></span><div><div class="n">${n}</div><div class="s">${c} · ${parseInt(c.slice(1), 16)}</div></div></div>`).join('') }), { auto: true });
  T('img2uri', '🖼️', 'صورة ← Data URI', 'تجهيز صورة لاستخدامها كأفاتار عبر API', 'الألوان', [F('f', 'اختر صورة', '', 'file')], async v => {
    if (!v.f) throw new Error('اختر صورة'); if (v.f.size > 256 * 1024) throw new Error('الصورة أكبر من 256KB — صغّرها أولاً'); return `data:${v.f.type};base64,${await fileToB64(v.f)}`;
  });

  /* ================= السيرفر ================= */
  T('layout', '🏰', 'مخطط السيرفر', 'هيكل قنوات جاهز حسب النوع', 'السيرفر', [F('n', 'الاسم', 'My Server'), F('t', 'النوع', '', 'select', 'Gaming', [['Gaming', 'ألعاب'], ['Community', 'مجتمع'], ['Support', 'دعم'], ['Creator', 'صانع محتوى'], ['Study', 'دراسة']])], v => {
    const base = '📌 START HERE\n  # welcome\n  # rules\n  # announcements\n  # roles\n💬 COMMUNITY\n  # general\n  # media\n  # off-topic\n';
    const ext = { Gaming: '🎮 GAMING\n  # gaming-chat\n  # clips\n  # lfg\n🔊 VOICE\n  🔊 Lobby\n  🔊 Squad 1\n  🔊 Squad 2', Community: '🎉 EVENTS\n  # events\n  # giveaways\n  # polls\n🔊 VOICE\n  🔊 General\n  🎙 Stage', Support: '🛠 SUPPORT\n  # help\n  # faq\n  # tickets\n  # suggestions\n🔊 VOICE\n  🔊 Support Call', Creator: '📺 CONTENT\n  # new-videos\n  # stream-alerts\n  # fan-art\n🔊 VOICE\n  🔊 Hangout', Study: '📚 STUDY\n  # resources\n  # homework-help\n  # study-log\n🔊 STUDY ROOMS\n  🔊 Focus 1\n  🔊 Focus 2' }[v.t];
    return `${v.n} — ${v.t}\n${base}${ext}`;
  });
  T('boost', '🚀', 'مستويات البوست', 'مستوى السيرفر حسب عدد البوستات', 'السيرفر', [F('n', 'عدد البوستات', '', 'num', 0)], v => {
    const n = +v.n || 0, lv = n >= 14 ? 3 : n >= 7 ? 2 : n >= 2 ? 1 : 0;
    return `المستوى: ${lv}\nأماكن الإيموجي: ${[50, 100, 150, 250][lv]} لكل نوع\nالستيكرز: ${[5, 15, 30, 60][lv]}\nأقصى جودة صوت: ${[96, 128, 256, 384][lv]} kbps\nللمستوى التالي: ${lv < 3 ? [2, 7, 14][lv] - n + ' بوست' : 'وصلت للأقصى'}`;
  });
  T('rolecolors', '🌈', 'ألوان رتب جاهزة', 'ألوان متناسقة للرتب', 'السيرفر', [], () => ({ html: ['#e74c3c', '#e67e22', '#f1c40f', '#2ecc71', '#1abc9c', '#3498db', '#9b59b6', '#e91e63', '#95a5a6', '#34495e', '#ff6b81', '#7bed9f'].map(c => `<div class="list-item" data-act="tool.copy" data-t="${c}"><span class="ph" style="background:${c}"></span><div><div class="n" style="color:${c}">Role Name</div><div class="s">${c}</div></div></div>`).join('') }), { auto: true });

  /* ================= البوتات ================= */
  T('slash', '⚡', 'منشئ Slash Command', 'JSON لتسجيل أمر، وتسجيله مباشرة', 'البوتات', [TOK, F('n', 'اسم الأمر', 'ping'), F('d', 'الوصف', 'Replies with pong'), F('o', 'الخيارات (name:type:required — سطر لكل خيار)', 'user:user:true\ntext:string:false', 'area'), F('g', 'Guild ID (فارغ = عام)', ''), F('r', 'تسجيل الأمر فعلياً؟', '', 'select', 'no', [['no', 'لا — عرض JSON فقط'], ['yes', 'نعم — سجّله الآن']])], async v => {
    const T2 = { sub: 1, group: 2, string: 3, int: 4, bool: 5, user: 6, channel: 7, role: 8, mention: 9, number: 10, file: 11 };
    const opts = v.o.split('\n').map(x => x.trim()).filter(Boolean).map(l => { const [n, t, r] = l.split(':'); if (!T2[t]) throw new Error('نوع غير معروف: ' + t); return { name: n.toLowerCase(), description: n, type: T2[t], required: r === 'true' }; }).sort((a, b) => b.required - a.required);
    if (!/^[\w-]{1,32}$/.test(v.n)) throw new Error('اسم الأمر: أحرف إنجليزية/أرقام/_/- حتى 32');
    const cmd = { name: v.n.toLowerCase(), description: v.d || '-', type: 1 }; if (opts.length) cmd.options = opts;
    let out = JSON.stringify(cmd, null, 2);
    if (v.r === 'yes') {
      const tok = v.token.trim(), app = atob(tok.split('.')[0].replace(/-/g, '+').replace(/_/g, '/'));
      const r = await dapi('POST', v.g ? `/applications/${app}/guilds/${idCheck(v.g)}/commands` : `/applications/${app}/commands`, { token: tok, json: cmd }); out += `\n\n✅ سُجّل الأمر: ${r.id}`;
    }
    return out;
  });
  T('botcode', '💻', 'قوالب كود بوت', 'بوت جاهز بـ discord.js أو discord.py', 'البوتات', [F('l', 'اللغة', '', 'select', 'js', [['js', 'discord.js (Node)'], ['py', 'discord.py']]), F('p', 'البريفكس', '!', 'text', '!')], v => v.l === 'js' ?
    `const { Client, GatewayIntentBits } = require('discord.js');\nconst client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });\n\nclient.once('ready', () => console.log('Ready as', client.user.tag));\nclient.on('messageCreate', msg => {\n  if (msg.author.bot) return;\n  if (msg.content === '${v.p}ping') msg.reply('Pong!');\n});\nclient.login(process.env.TOKEN);` :
    `import os, discord\nfrom discord.ext import commands\n\nintents = discord.Intents.default()\nintents.message_content = True\nbot = commands.Bot(command_prefix='${v.p}', intents=intents)\n\n@bot.event\nasync def on_ready():\n    print('Ready as', bot.user)\n\n@bot.command()\nasync def ping(ctx):\n    await ctx.reply('Pong!')\n\nbot.run(os.environ['TOKEN'])`);
  T('hookcode', '🧑‍💻', 'مولّد أكواد الويبهوك', 'cURL / Python / JS / Node من نفس الرسالة', 'البوتات', [F('u', 'رابط الويبهوك', 'https://discord.com/api/webhooks/…'), F('c', 'نص الرسالة', 'Hello', 'area')], v => {
    const body = JSON.stringify({ content: v.c });
    return `# cURL\ncurl -X POST -H "Content-Type: application/json" -d '${body.replace(/'/g, "'\\''")}' "${v.u}"\n\n# Python\nimport requests\nrequests.post("${v.u}", json=${body})\n\n# JavaScript (fetch)\nfetch("${v.u}", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(${body})});`;
  });
  T('dhook', '🔗', 'محوّل Discohook و JSON', 'الصق رابط Discohook لتحويله إلى JSON رسالة، أو الصق JSON لتحصل على رابط', 'API', [F('t', 'رابط Discohook أو JSON', '', 'area')], v => {
    const u8 = s => btoa(String.fromCharCode(...new TextEncoder().encode(s))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    const d8 = b => { b = b.replace(/-/g, '+').replace(/_/g, '/'); b += '='.repeat((4 - b.length % 4) % 4); return new TextDecoder().decode(Uint8Array.from(atob(b), c => c.charCodeAt(0))); };
    const m = /[?&]data=([A-Za-z0-9_\-%=+/]+)/.exec(v.t);
    if (m) { let j; try { j = JSON.parse(d8(decodeURIComponent(m[1]))); } catch (e) { throw new Error('رابط غير مفهوم'); } return { text: JSON.stringify(j, null, 2) }; }
    let j; try { j = JSON.parse(v.t); } catch (e) { throw new Error('الصق رابط Discohook أو JSON صالحاً'); }
    if (!j.messages) j = { messages: [{ data: j }] };
    return 'https://discohook.org/?data=' + u8(JSON.stringify(j));
  });
  T('embedcheck', '✅', 'فاحص JSON الرسالة', 'تحقق من حدود Discord قبل الإرسال', 'البوتات', [F('j', 'JSON', '{"content":"hi"}', 'area')], v => {
    let j; try { j = JSON.parse(v.j); } catch (e) { throw new Error('JSON غير صالح: ' + e.message); } if (j.messages && j.messages[0]) j = j.messages[0].data || j;
    const er = [], em = j.embeds || []; let tot = 0;
    if ((j.content || '').length > 2000) er.push('content أطول من 2000');
    if (em.length > 10) er.push('أكثر من 10 embeds');
    em.forEach((e, i) => { const n = (e.title || '').length + (e.description || '').length + (e.footer && e.footer.text || '').length + (e.author && e.author.name || '').length + (e.fields || []).reduce((a, f) => a + (f.name || '').length + (f.value || '').length, 0); tot += n; if ((e.title || '').length > 256) er.push(`embed ${i + 1}: title > 256`); if ((e.description || '').length > 4096) er.push(`embed ${i + 1}: description > 4096`); if ((e.fields || []).length > 25) er.push(`embed ${i + 1}: fields > 25`); (e.fields || []).forEach((f, k) => { if (!f.name || !f.value) er.push(`embed ${i + 1} field ${k + 1}: name/value فارغ`); if ((f.name || '').length > 256) er.push(`embed ${i + 1} field ${k + 1}: name > 256`); if ((f.value || '').length > 1024) er.push(`embed ${i + 1} field ${k + 1}: value > 1024`); }); });
    if (tot > 6000) er.push('مجموع embeds > 6000');
    if (!j.content && !em.length && !j.components && !j.attachments) er.push('لا يوجد content ولا embeds');
    return er.length ? '❌ مشاكل:\n' + er.map(x => '• ' + x).join('\n') : `✅ صالح\ncontent: ${(j.content || '').length} · embeds: ${em.length} · مجموع الأحرف: ${tot}`;
  });
  T('gateway', '🚦', 'حدود جلسات البوت', 'عدد الـ shards والجلسات المتبقية', 'البوتات', [TOK], async v => { const g = await dapi('GET', '/gateway/bot', { token: v.token.trim() }); return `Shards الموصى به: ${g.shards}\nالجلسات المتبقية: ${g.session_start_limit.remaining}/${g.session_start_limit.total}\nإعادة الضبط بعد: ${Math.round(g.session_start_limit.reset_after / 60000)} دقيقة\nmax_concurrency: ${g.session_start_limit.max_concurrency}`; });

  /* ================= API ================= */
  T('invinfo', '✉️', 'فحص رابط دعوة', 'معلومات السيرفر خلف الدعوة', 'API', [F('c', 'الرابط أو الكود', 'discord.gg/abc')], async v => {
    const c = v.c.trim().replace(/^(?:https?:\/\/)?(?:www\.)?(?:discord\.gg|discord(?:app)?\.com\/invite)\//, '').replace(/[/?#].*$/, ''); if (!/^[\w-]{2,}$/.test(c)) throw new Error('كود غير صالح');
    const i = await dapi('GET', `/invites/${c}`, { query: { with_counts: 'true', with_expiration: 'true' } }); const g = i.guild || {};
    return { html: `<div class="card"><div class="botcard">${g.icon ? `<img src="${esc(guildIcon(g, 128))}" alt="">` : ''}<div><div class="n">${esc(g.name || '؟')}</div><div class="sub">${esc(g.description || '')}</div></div></div></div><div class="result">Guild ID: ${esc(g.id)}\nالأعضاء: ${i.approximate_member_count} · المتصلون: ${i.approximate_presence_count}\nالقناة: #${esc(i.channel && i.channel.name)}\nالداعي: ${esc(i.inviter ? i.inviter.username : '—')}\nتنتهي: ${i.expires_at ? dt(i.expires_at) : 'لا تنتهي'}\nالمميزات: ${esc((g.features || []).join(', ') || '—')}</div>`, text: g.id };
  });
  T('hookinfo', '🪝', 'فحص ويبهوك', 'اسمه وقناته وسيرفره', 'API', [F('u', 'رابط الويبهوك', '')], async v => {
    const m = /webhooks\/(\d{15,25})\/([\w-]+)/.exec(v.u); if (!m) throw new Error('رابط غير صالح'); const w = await dapi('GET', `/webhooks/${m[1]}/${m[2]}`);
    return `الاسم: ${w.name}\nID: ${w.id}\nChannel: ${w.channel_id}\nGuild: ${w.guild_id}\nالنوع: ${w.type === 1 ? 'Incoming' : w.type}\nأُنشئ: ${dt(snowflakeMs(w.id))}\nApplication: ${w.application_id || '—'}`;
  });
  T('hookdel', '🗑️', 'حذف ويبهوك', 'حذف ويبهوك برابطه', 'API', [F('u', 'رابط الويبهوك', '')], async v => { const m = /webhooks\/(\d{15,25})\/([\w-]+)/.exec(v.u); if (!m) throw new Error('رابط غير صالح'); if (!await confirmDlg('حذف هذا الويبهوك نهائياً؟', { danger: true, ok: 'حذف' })) return 'أُلغي'; await dapi('DELETE', `/webhooks/${m[1]}/${m[2]}`); return '✅ تم حذف الويبهوك'; });
  T('hookmsg', '📨', 'إرسال سريع عبر ويبهوك', 'رسالة نصية بسيطة بدون فتح المرسل', 'API', [F('u', 'رابط الويبهوك', ''), F('n', 'الاسم (اختياري)', ''), F('c', 'النص', '', 'area')], async v => { const m = /webhooks\/(\d{15,25})\/([\w-]+)/.exec(v.u); if (!m) throw new Error('رابط غير صالح'); const j = { content: v.c, allowed_mentions: { parse: [] } }; if (v.n) j.username = v.n; const r = await dapi('POST', `/webhooks/${m[1]}/${m[2]}`, { json: j, query: { wait: 'true' } }); return '✅ أُرسلت — Message ID: ' + r.id; });
  T('userlook', '🔎', 'بحث مستخدم بالـ ID', 'الاسم والصورة والبانر والشارات', 'API', [TOK, F('i', 'User ID', '')], async v => {
    const u = await dapi('GET', `/users/${idCheck(v.i)}`, { token: v.token.trim() });
    return { html: `<div class="card"><div class="botcard"><img src="${esc(userAvatar(u, 128))}" alt=""><div><div class="n">${esc(u.global_name || u.username)}</div><div class="sub" style="direction:ltr">@${esc(u.username)} · ${esc(u.id)}</div></div></div></div><div class="result">${u.bot ? '🤖 بوت\n' : ''}أُنشئ: ${dt(snowflakeMs(u.id))}\nالشارات: ${esc(bits(BigInt(u.public_flags || 0), USER_FLAGS).join(', ') || '—')}\nالبانر: ${u.banner ? `${CDN}/banners/${u.id}/${u.banner}.png?size=1024` : '—'}\nلون البانر: ${u.accent_color != null ? '#' + u.accent_color.toString(16).padStart(6, '0') : '—'}</div>`, text: u.id };
  });
  T('guildprev', '🏰', 'معاينة سيرفر', 'سيرفر عام أو البوت فيه (Guild Preview)', 'API', [TOK, F('i', 'Guild ID', '')], async v => {
    const g = await dapi('GET', `/guilds/${idCheck(v.i)}/preview`, { token: v.token.trim() });
    return { html: `<div class="card"><div class="botcard">${g.icon ? `<img src="${esc(guildIcon(g, 128))}" alt="">` : ''}<div><div class="n">${esc(g.name)}</div><div class="sub">${esc(g.description || '')}</div></div></div></div><div class="result">الأعضاء ≈ ${g.approximate_member_count}\nالمتصلون ≈ ${g.approximate_presence_count}\nإيموجي: ${(g.emojis || []).length} · ستيكر: ${(g.stickers || []).length}\nالمميزات: ${esc((g.features || []).join(', ') || '—')}</div>`, text: g.id };
  });
  T('widget', '🧩', 'ودجت السيرفر', 'المتصلون الآن إن كان الودجت مفعّلاً', 'API', [F('i', 'Guild ID', '')], async v => { const w = await dapi('GET', `/guilds/${idCheck(v.i)}/widget.json`); return `${w.name}\nالمتصلون: ${w.presence_count}\n` + (w.members || []).slice(0, 30).map(m => '• ' + m.username).join('\n') + (w.instant_invite ? '\n\nدعوة: ' + w.instant_invite : ''); });
  T('template', '📄', 'فحص قالب سيرفر', 'معلومات رابط discord.new', 'API', [F('c', 'الكود أو الرابط', '')], async v => { const c = v.c.trim().replace(/^(?:https?:\/\/)?discord\.(?:new|com\/template)\//, '').replace(/[/?#].*$/, ''); const t = await dapi('GET', `/guilds/templates/${c}`); return `${t.name}\n${t.description || ''}\nالاستخدامات: ${t.usage_count}\nالقنوات: ${(t.serialized_source_guild.channels || []).length}\nالرتب: ${(t.serialized_source_guild.roles || []).length}`; });
  T('appinfo', '🧰', 'معلومات تطبيق/بوت', 'الوصف والمميزات عبر Application ID', 'API', [F('i', 'Application ID', '')], async v => { const a = await dapi('GET', `/applications/${idCheck(v.i)}/rpc`); return `${a.name}\n${a.description || ''}\nبوت عام: ${a.bot_public ? 'نعم' : 'لا'}\nيتطلب code grant: ${a.bot_require_code_grant ? 'نعم' : 'لا'}\nFlags: ${a.flags}\n${a.terms_of_service_url ? 'ToS: ' + a.terms_of_service_url : ''}`; });

  /* ================= أدوات عامة ================= */
  T('pick', '🎲', 'اختيار عشوائي / سحب فائزين', 'للمسابقات والقرعة', 'أدوات عامة', [F('l', 'القائمة (سطر لكل اسم)', '', 'area'), F('n', 'عدد الفائزين', '1', 'num', 1)], v => {
    const l = v.l.split('\n').map(x => x.trim()).filter(Boolean); const n = Math.max(1, Math.min(+v.n || 1, l.length)); if (!l.length) throw new Error('القائمة فارغة');
    const a = new Uint32Array(l.length); crypto.getRandomValues(a); const w = l.map((x, i) => [a[i], x]).sort((p, q) => p[0] - q[0]).slice(0, n).map(x => x[1]);
    return '🏆 الفائزون:\n' + w.map((x, i) => `${i + 1}. ${x}`).join('\n');
  });
  T('dice', '🎯', 'نرد وعملة', 'رمي نرد أو عملة', 'أدوات عامة', [F('s', 'عدد أوجه النرد', '6', 'num', 6), F('c', 'عدد الرميات', '1', 'num', 1)], v => { const s = Math.max(2, +v.s || 6), c = Math.min(100, Math.max(1, +v.c || 1)); const r = Array.from({ length: c }, () => 1 + Math.floor(Math.random() * s)); return `🎲 ${r.join(', ')}${c > 1 ? '\nالمجموع: ' + r.reduce((a, b) => a + b, 0) : ''}\n🪙 ${Math.random() < .5 ? 'صورة' : 'كتابة'}`; });
  T('pass', '🔐', 'مولّد كلمات مرور', 'كلمات مرور عشوائية قوية', 'أدوات عامة', [F('n', 'الطول', '20', 'num', 20)], v => { const n = Math.max(8, Math.min(64, +v.n || 20)), cs = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%^&*-_'; return Array.from({ length: 4 }, () => { const a = new Uint32Array(n); crypto.getRandomValues(a); return Array.from(a, x => cs[x % cs.length]).join(''); }).join('\n'); });
  T('json', '{ }', 'منسّق JSON', 'تنسيق وضغط والتحقق', 'أدوات عامة', [F('j', 'JSON', '', 'area'), F('m', 'الوضع', '', 'select', 'pretty', [['pretty', 'تنسيق'], ['min', 'ضغط']])], v => { let j; try { j = JSON.parse(v.j); } catch (e) { throw new Error('JSON غير صالح: ' + e.message); } return v.m === 'min' ? JSON.stringify(j) : JSON.stringify(j, null, 2); });
  T('b64', '🔁', 'Base64 / URL', 'ترميز وفك ترميز', 'أدوات عامة', [F('t', 'النص', '', 'area'), F('m', 'العملية', '', 'select', 'enc', [['enc', 'Base64 ترميز'], ['dec', 'Base64 فك'], ['uenc', 'URL ترميز'], ['udec', 'URL فك']])], v => {
    const u8 = s => btoa(String.fromCharCode(...new TextEncoder().encode(s))), d8 = s => new TextDecoder().decode(Uint8Array.from(atob(s.trim()), c => c.charCodeAt(0)));
    try { return { enc: () => u8(v.t), dec: () => d8(v.t), uenc: () => encodeURIComponent(v.t), udec: () => decodeURIComponent(v.t) }[v.m](); } catch (e) { throw new Error('تعذر التحويل'); }
  });
  T('hash', '🔑', 'تجزئة SHA', 'SHA-1 / 256 / 512', 'أدوات عامة', [F('t', 'النص', '', 'area')], async v => { if (!(window.crypto && crypto.subtle)) throw new Error('غير متاح في هذا الجهاز'); const h = async a => Array.from(new Uint8Array(await crypto.subtle.digest(a, new TextEncoder().encode(v.t))), b => b.toString(16).padStart(2, '0')).join(''); return `SHA-1:\n${await h('SHA-1')}\n\nSHA-256:\n${await h('SHA-256')}\n\nSHA-512:\n${await h('SHA-512')}`; });
  T('lines', '📑', 'ترتيب الأسطر', 'فرز، إزالة المكرر، عكس', 'أدوات عامة', [F('t', 'النص', '', 'area'), F('m', 'العملية', '', 'select', 'sort', [['sort', 'فرز أبجدي'], ['uniq', 'إزالة المكرر'], ['rev', 'عكس الترتيب'], ['num', 'ترقيم'], ['shuf', 'خلط عشوائي']])], v => { let l = v.t.split('\n'); if (v.m === 'sort') l.sort((a, b) => a.localeCompare(b)); else if (v.m === 'uniq') l = [...new Set(l)]; else if (v.m === 'rev') l.reverse(); else if (v.m === 'num') l = l.map((x, i) => `${i + 1}. ${x}`); else l.sort(() => Math.random() - .5); return l.join('\n'); });
  T('cheat', '📖', 'ورقة Markdown', 'كل تنسيقات ديسكورد', 'أدوات عامة', [], () => '**عريض** → bold\n*مائل* أو _مائل_ → italic\n__تحته خط__ → underline\n~~مشطوب~~ → strike\n||سبويلر|| → spoiler\n`كود` → inline code\n```lang\nكتلة كود\n```\n> اقتباس\n>>> اقتباس متعدد الأسطر\n# عنوان 1  ## عنوان 2  ### عنوان 3\n-# نص صغير (subtext)\n- قائمة نقطية\n1. قائمة مرقمة\n[نص](https://رابط) → رابط\n<@id> منشن · <#id> قناة · <@&id> رتبة\n<t:UNIX:R> → وقت\n</command:id> → أمر slash\n<:name:id> → إيموجي مخصص', { auto: true });
  T('keys', '⌨️', 'اختصارات ديسكورد', 'أهم الاختصارات (سطح المكتب)', 'أدوات عامة', [], () => 'Ctrl+K — التنقل السريع\nCtrl+Alt+↑/↓ — تغيير القناة\nAlt+↑/↓ — الانتقال بين القنوات\nShift+Esc — تعليم الكل كمقروء\nCtrl+Shift+M — كتم الميكروفون\nCtrl+Shift+D — إصمات الصوت\nCtrl+/ — قائمة الاختصارات\nCtrl+E — إيموجي', { auto: true });
  T('limits', '📏', 'حدود Discord', 'الحدود الشائعة في مكان واحد', 'أدوات عامة', [], () => 'رسالة: 2000 حرف\nEmbeds: 10 / رسالة · 6000 حرف مجموعاً\nحقول Embed: 25\nأزرار: 5 × 5 صفوف\nويبهوكات: 15 / قناة\nاسم ويبهوك: 80 حرفاً\nلقب: 32 · اسم مستخدم: 32\nقنوات: 500 / سيرفر\nرتب: 250 / سيرفر\nأعضاء Timeout: حتى 28 يوماً\nحذف جماعي: 2–100 رسالة (أحدث من 14 يوماً)', { auto: true });
  T('emoji', '😎', 'لوحة إيموجي', 'ادخل واضغط للنسخ', 'أدوات عامة', [], () => ({ html: '<div class="row wrap" style="gap:6px">' + Array.from('😀😂🥹😍🤔😎🥳😭😡👍👎👏🙏💪🔥✨⭐💯✅❌⚠️❤️💔🎉🎁🏆🎮🎧📌📢🔔🔒🔑⚙️🛠️🔨🤖👾🪄🌈☀️🌙⚡💬📎📷🎵').map(e => `<button class="btn sec" style="font-size:22px;min-width:46px;padding:6px" data-act="tool.copy" data-t="${e}">${e}</button>`).join('') + '</div>' }), { auto: true });

  /* ================= v2.1 — أدوات إضافية ================= */
  const pn = (s, name) => { const n = Number(String(s).trim()); if (!isFinite(n)) throw new Error((name || 'قيمة') + ' غير صالحة'); return n; };
  T('multiid', '🆔', 'محلل عدة معرفات', 'الصق أي عدد من الـ IDs أو المنشنات: تاريخ كل واحد مرتباً', 'المعرفات', [F('t', 'المعرفات (أي نص)', '', 'area')], v => {
    const ids = [...new Set(v.t.match(/\d{15,21}/g) || [])]; if (!ids.length) throw new Error('لا توجد معرفات في النص');
    return ids.map(i => [i, snowflakeMs(i)]).sort((a, b) => a[1] - b[1]).map(([i, ms]) => `${i}\n   ${dt(ms)}  ·  <t:${Math.floor(ms / 1000)}:R>`).join('\n\n') + `\n\nالعدد: ${ids.length}`;
  });
  T('idx', '🧲', 'استخراج المعرفات', 'يستخرج كل الأرقام الطويلة والمنشنات من نص مكرر أو سجل', 'المعرفات', [F('t', 'النص', '', 'area'), F('m', 'الشكل', '', 'select', 'lines', [['lines', 'سطر لكل ID'], ['comma', 'مفصولة بفواصل'], ['json', 'مصفوفة JSON']])], v => {
    const ids = [...new Set(v.t.match(/\d{15,21}/g) || [])];
    return v.m === 'comma' ? ids.join(', ') : v.m === 'json' ? JSON.stringify(ids) : ids.join('\n');
  });
  T('permdiff', '🧮', 'فرق صلاحيتين', 'قارن رقمين: ما أُضيف وما أُزيل', 'الصلاحيات', [F('a', 'الرقم القديم', '0'), F('b', 'الرقم الجديد', '0')], v => {
    const a = big(v.a), b = big(v.b), add = PERMS.filter(([, x]) => (b & x) && !(a & x)).map(p => p[0]), rem = PERMS.filter(([, x]) => (a & x) && !(b & x)).map(p => p[0]);
    return `أُضيفت (${add.length}):\n${add.join('\n') || '—'}\n\nأُزيلت (${rem.length}):\n${rem.join('\n') || '—'}`;
  });
  T('permnames', '🔤', 'أسماء ← رقم صلاحيات', 'اكتب أسماء الصلاحيات (واحد في كل سطر) واحصل على الرقم', 'الصلاحيات', [F('t', 'الأسماء', 'Send Messages\nView Channel', 'area')], v => {
    const want = v.t.split(/[\n,]+/).map(x => x.trim().toLowerCase().replace(/[_\s]+/g, '')).filter(Boolean); let n = 0n; const bad = [];
    want.forEach(w => { const p = PERMS.find(([nm]) => nm.toLowerCase().replace(/\s+/g, '') === w); if (p) n |= p[1]; else bad.push(w); });
    return `${n}` + (bad.length ? `\n\nغير معروف: ${bad.join(', ')}` : '');
  });
  T('overwrite', '🧱', 'حاسبة Overwrites القناة', 'صلاحيات الرتبة + السماح/المنع = الناتج', 'الصلاحيات', [F('base', 'صلاحيات الرتبة', '0'), F('allow', 'Allow', '0'), F('deny', 'Deny', '0')], v => {
    const r = (big(v.base) & ~big(v.deny)) | big(v.allow); return `النتيجة = ${r}\n\n${PERMS.filter(([, b]) => (r & b) === b).map(p => p[0]).join('\n') || '—'}`;
  });
  T('progress', '▰', 'شريط تقدّم نصي', 'شريط من الرموز للـ Embed والرسائل', 'النصوص', [F('p', 'النسبة %', '65', 'num'), F('n', 'الطول', '12', 'num'), F('s', 'النمط', '', 'select', '0', [['0', '█░'], ['1', '▰▱'], ['2', '●○'], ['3', '■□'], ['4', '▓░']])], v => {
    const sets = [['█', '░'], ['▰', '▱'], ['●', '○'], ['■', '□'], ['▓', '░']], [f, e] = sets[+v.s], n = Math.min(40, Math.max(3, pn(v.n))), p = Math.min(100, Math.max(0, pn(v.p))), k = Math.round(n * p / 100);
    return f.repeat(k) + e.repeat(n - k) + ` ${Math.round(p)}%`;
  });
  T('table', '▤', 'جدول في كتلة كود', 'حوّل أسطر (أعمدة بفاصل | أو Tab) إلى جدول منسّق', 'النصوص', [F('t', 'الصفوف', 'الاسم | المستوى\nسارة | 12\nأحمد | 9', 'area')], v => {
    const rows = v.t.split('\n').filter(l => l.trim()).map(l => l.split(/\t|\|/).map(c => c.trim())), w = [];
    rows.forEach(r => r.forEach((c, i) => { w[i] = Math.max(w[i] || 0, c.length); }));
    const line = r => r.map((c, i) => c.padEnd(w[i])).join(' │ ');
    const out = rows.map(line); if (out.length > 1) out.splice(1, 0, w.map(x => '─'.repeat(x)).join('─┼─'));
    return '```\n' + out.join('\n') + '\n```';
  });
  T('mlist', '📣', 'قائمة منشن جاهزة', 'IDs → منشنات أعضاء/رتب/قنوات', 'النصوص', [F('t', 'المعرفات', '', 'area'), F('k', 'النوع', '', 'select', '@', [['@', 'عضو'], ['@&', 'رتبة'], ['#', 'قناة']]), F('s', 'الفاصل', '', 'select', ' ', [[' ', 'مسافة'], ['\n', 'سطر'], [', ', 'فاصلة']])], v => {
    const ids = [...new Set(v.t.match(/\d{15,21}/g) || [])]; if (!ids.length) throw new Error('لا معرفات'); return ids.map(i => `<${v.k}${i}>`).join(v.s);
  });
  T('xp', '📈', 'حاسبة المستويات (XP)', 'معادلة MEE6 الشائعة: من XP إلى مستوى والعكس', 'أدوات عامة', [F('m', 'العملية', '', 'select', 'lvl', [['lvl', 'XP ← المستوى'], ['xp', 'المستوى ← XP المطلوب']]), F('v', 'القيمة', '1500', 'num')], v => {
    const need = l => Math.round(5 / 6 * l * (2 * l * l + 27 * l + 91)), x = pn(v.v);
    if (v.m === 'xp') return `للوصول إلى المستوى ${x}: ${need(x)} XP\nللمستوى التالي: ${need(x + 1) - need(x)} XP إضافية`;
    let l = 0; while (need(l + 1) <= x) l++; return `المستوى ${l}\nالتقدم: ${x - need(l)} / ${need(l + 1) - need(l)} XP`;
  });
  T('djs', '💻', 'مولّد EmbedBuilder', 'JSON الـ Embed → كود discord.js و discord.py', 'البوتات', [F('t', 'JSON الـ Embed', '{"title":"عنوان","description":"وصف","color":5793266}', 'area'), F('l', 'اللغة', '', 'select', 'js', [['js', 'discord.js'], ['py', 'discord.py']])], v => {
    let e; try { e = JSON.parse(v.t); } catch (x) { throw new Error('JSON غير صالح'); } if (e.embeds) e = e.embeds[0] || {};
    const q = s => JSON.stringify(String(s)), col = e.color != null ? '0x' + Number(e.color).toString(16).padStart(6, '0') : null;
    if (v.l === 'py') {
      let c = `embed = discord.Embed(${[e.title && 'title=' + q(e.title), e.description && 'description=' + q(e.description), col && 'color=' + col, e.url && 'url=' + q(e.url)].filter(Boolean).join(', ')})\n`;
      (e.fields || []).forEach(f => { c += `embed.add_field(name=${q(f.name)}, value=${q(f.value)}, inline=${f.inline ? 'True' : 'False'})\n`; });
      if (e.footer) c += `embed.set_footer(text=${q(e.footer.text || '')})\n`; if (e.image) c += `embed.set_image(url=${q(e.image.url)})\n`; if (e.thumbnail) c += `embed.set_thumbnail(url=${q(e.thumbnail.url)})\n`;
      if (e.author) c += `embed.set_author(name=${q(e.author.name || '')})\n`; return c + 'await channel.send(embed=embed)';
    }
    let c = 'const embed = new EmbedBuilder()'; if (e.title) c += `\n  .setTitle(${q(e.title)})`; if (e.url) c += `\n  .setURL(${q(e.url)})`; if (e.description) c += `\n  .setDescription(${q(e.description)})`; if (col) c += `\n  .setColor(${col})`;
    if (e.author) c += `\n  .setAuthor({ name: ${q(e.author.name || '')} })`; if (e.thumbnail) c += `\n  .setThumbnail(${q(e.thumbnail.url)})`; if (e.image) c += `\n  .setImage(${q(e.image.url)})`;
    if ((e.fields || []).length) c += `\n  .addFields(\n${e.fields.map(f => `    { name: ${q(f.name)}, value: ${q(f.value)}, inline: ${!!f.inline} }`).join(',\n')}\n  )`;
    if (e.footer) c += `\n  .setFooter({ text: ${q(e.footer.text || '')} })`; if (e.timestamp) c += '\n  .setTimestamp()'; return c + ';\nawait channel.send({ embeds: [embed] });';
  });
  T('dur', '⏱️', 'محلل المدة', '1d2h30m أو "ساعتين" → ثوانٍ ووقت الانتهاء', 'الوقت', [F('t', 'المدة', '1d 2h 30m')], v => {
    const u = { w: 604800, d: 86400, h: 3600, m: 60, s: 1 }; let sec = 0, hit = false; String(v.t).replace(/(\d+(?:\.\d+)?)\s*([wdhms])/gi, (_, n, k) => { sec += n * u[k.toLowerCase()]; hit = true; });
    if (!hit) throw new Error('اكتب مثل 1d 2h 30m (w d h m s)'); const end = Date.now() + sec * 1e3;
    return `${sec} ثانية\n${sec * 1000} ms\nتنتهي: ${dt(end)}\n<t:${Math.floor(end / 1000)}:R>\n${sec > 2419200 ? '⚠️ أكثر من 28 يوماً — لا يصلح لـ Timeout' : 'يصلح لـ Timeout'}`;
  });
  T('regex', '🔬', 'مختبر Regex', 'جرّب تعبيراً نمطياً على نص مع عرض المجموعات', 'أدوات عامة', [F('r', 'النمط', '(\\d+)'), F('f', 'الأعلام', 'g'), F('t', 'النص', '', 'area')], v => {
    let re; try { re = new RegExp(v.r, v.f.includes('g') ? v.f : v.f + 'g'); } catch (e) { throw new Error('نمط غير صالح: ' + e.message); }
    const ms = [...v.t.matchAll(re)].slice(0, 100); if (!ms.length) return 'لا توجد نتائج'; return `${ms.length} نتيجة\n\n` + ms.map((m, i) => `#${i + 1} @${m.index}: ${m[0]}` + (m.length > 1 ? '\n   ' + m.slice(1).map((g, j) => `[${j + 1}] ${g}`).join(' · ') : '')).join('\n');
  });
  const ERRS = { 10003: 'Unknown Channel', 10004: 'Unknown Guild', 10006: 'Unknown Invite', 10007: 'Unknown Member', 10008: 'Unknown Message', 10011: 'Unknown Role', 10013: 'Unknown User', 10015: 'Unknown Webhook', 10062: 'Unknown Interaction', 20001: 'Bots cannot use this endpoint', 20002: 'Only bots can use this endpoint', 30001: 'Max guilds reached (100)', 30005: 'Max roles reached (250)', 30007: 'Max webhooks reached (15)', 30010: 'Max reactions reached (20)', 30013: 'Max channels reached (500)', 40001: 'Unauthorized', 40002: 'Verify your account', 40005: 'Request entity too large', 40060: 'Interaction already acknowledged', 50001: 'Missing Access', 50004: 'Guild widget disabled', 50005: 'Cannot edit a message authored by another user', 50006: 'Cannot send an empty message', 50007: 'Cannot send messages to this user (DMs closed)', 50013: 'Missing Permissions', 50014: 'Invalid authentication token', 50015: 'Note is too long', 50016: 'Provided too few or too many messages to delete (2–100)', 50019: 'A message can only be pinned to the channel it was sent in', 50027: 'Invalid Webhook Token', 50034: 'Cannot delete messages older than 14 days with bulk delete', 50035: 'Invalid Form Body', 50045: 'File uploaded exceeds the maximum size', 50068: 'Invalid message type', 50109: 'The request body contains invalid JSON', 90001: 'Reaction blocked', 130000: 'API resource overloaded', 160002: 'Cannot reply without READ_MESSAGE_HISTORY' };
  T('errs', '🚨', 'مرجع أكواد الأخطاء', 'ابحث بالرقم أو بالكلمة في أخطاء REST', 'API', [F('q', 'رقم أو كلمة', '50013')], v => {
    const q = v.q.trim().toLowerCase(); const r = Object.entries(ERRS).filter(([k, m]) => !q || k.includes(q) || m.toLowerCase().includes(q)); if (!r.length) return 'لا نتائج';
    return r.map(([k, m]) => `${k}  —  ${m}`).join('\n');
  }, { auto: true, live: true });
  T('gwcodes', '🚦', 'أكواد إغلاق Gateway', 'سبب كل رمز وهل يمكن إعادة الاتصال', 'API', [], () => '4000 Unknown error — إعادة اتصال ✓\n4001 Unknown opcode ✓\n4002 Decode error ✓\n4003 Not authenticated ✓\n4004 Authentication failed ✗ (توكن خاطئ)\n4005 Already authenticated ✓\n4007 Invalid seq ✓ (ابدأ جلسة جديدة)\n4008 Rate limited ✓\n4009 Session timed out ✓\n4010 Invalid shard ✗\n4011 Sharding required ✗\n4012 Invalid API version ✗\n4013 Invalid intent(s) ✗\n4014 Disallowed intent(s) ✗ (فعّلها من Developer Portal)', { auto: true });
  const EPS = [['GET', '/users/@me', 'معلومات الحساب'], ['GET', '/users/{id}', 'مستخدم'], ['GET', '/users/@me/guilds', 'سيرفرات البوت'], ['GET', '/guilds/{id}', 'سيرفر'], ['PATCH', '/guilds/{id}', 'تعديل السيرفر'], ['GET', '/guilds/{id}/channels', 'القنوات'], ['POST', '/guilds/{id}/channels', 'إنشاء قناة'], ['GET', '/guilds/{id}/members/{uid}', 'عضو'], ['PATCH', '/guilds/{id}/members/{uid}', 'تعديل عضو / Timeout'], ['PUT', '/guilds/{id}/members/{uid}/roles/{rid}', 'إعطاء رتبة'], ['PUT', '/guilds/{id}/bans/{uid}', 'حظر'], ['DELETE', '/guilds/{id}/members/{uid}', 'طرد'], ['GET', '/guilds/{id}/roles', 'الرتب'], ['GET', '/guilds/{id}/audit-logs', 'سجل التدقيق'], ['GET', '/guilds/{id}/auto-moderation/rules', 'AutoMod'], ['GET', '/channels/{id}/messages', 'رسائل القناة'], ['POST', '/channels/{id}/messages', 'إرسال رسالة'], ['PATCH', '/channels/{id}/messages/{mid}', 'تعديل رسالة'], ['POST', '/channels/{id}/messages/bulk-delete', 'حذف جماعي'], ['PUT', '/channels/{id}/pins/{mid}', 'تثبيت'], ['PUT', '/channels/{id}/messages/{mid}/reactions/{emoji}/@me', 'تفاعل'], ['POST', '/channels/{id}/webhooks', 'إنشاء ويبهوك'], ['POST', '/webhooks/{id}/{token}', 'تنفيذ ويبهوك'], ['PATCH', '/webhooks/{id}/{token}/messages/{mid}', 'تعديل رسالة ويبهوك'], ['GET', '/applications/{id}/commands', 'أوامر Slash'], ['PUT', '/applications/{id}/commands', 'استبدال الأوامر'], ['GET', '/invites/{code}', 'دعوة']];
  T('eps', '🗺️', 'مرجع Endpoints', 'أشهر مسارات REST v10 للبحث السريع', 'API', [F('q', 'بحث', 'messages')], v => {
    const q = v.q.trim().toLowerCase(); const r = EPS.filter(e => !q || (e[0] + e[1] + e[2]).toLowerCase().includes(q)); return r.length ? r.map(e => `${e[0].padEnd(6)} ${e[1]}\n       ${e[2]}`).join('\n') : 'لا نتائج';
  }, { auto: true, live: true });
  T('raid', '🛡️', 'قائمة حماية السيرفر', 'خطوات عملية ضد الريد والسبام', 'السيرفر', [], () => '1. مستوى التحقق: Medium أو أعلى\n2. فلتر المحتوى الصريح: لكل الأعضاء\n3. فعّل AutoMod: منع الروابط المشبوهة والسبام والمنشن الجماعي\n4. اسحب «Mention Everyone» و«Manage Webhooks» من رتبة @everyone\n5. رتبة الأدمن للبوتات الموثوقة فقط، ورتبة البوت أسفل رتب الإدارة\n6. فعّل 2FA للإشراف\n7. قناة قواعد + شاشة ترحيب (Membership Screening)\n8. حدّد قناة سجلات (Logs) وراجع Audit Log دورياً\n9. وضع Slowmode في القنوات العامة\n10. أوقف الدعوات مؤقتاً عند الهجوم (Pause Invites)', { auto: true });
  T('uname', '✔️', 'فاحص اسم المستخدم', 'هل يطابق قواعد الأسماء الجديدة؟', 'المعرفات', [F('t', 'الاسم', 'my.name_01')], v => {
    const n = v.t, p = [[n.length >= 2 && n.length <= 32, 'الطول 2–32'], [/^[a-z0-9_.]+$/.test(n), 'أحرف إنجليزية صغيرة وأرقام و _ و . فقط'], [!/\.\./.test(n), 'بدون نقطتين متتاليتين'], [!/^(everyone|here)$/.test(n), 'ليس اسماً محجوزاً']];
    return p.map(([ok, l]) => (ok ? '✓ ' : '✗ ') + l).join('\n');
  }, { live: true });
  T('slug', '#', 'اسم قناة صالح', 'يحوّل أي نص إلى صيغة اسم قناة نصية', 'النصوص', [F('t', 'النص', 'Game Night 🎮 2025')], v => v.t.toLowerCase().trim().replace(/\s+/g, '-').replace(/[^\p{L}\p{N}_-]/gu, '').replace(/-+/g, '-').slice(0, 100), { live: true });
  /* ---- v2.6 additions ---- */
  T('mdescape', '🔤', 'تهريب رموز ماركداون', 'يمنع تحويل * _ ~ ` | > # إلى تنسيق، أو يزيل التنسيق من النص', 'النصوص', [F('t', 'النص', '**bold** _it_ ||spoiler|| `code`', 'area'), F('m', 'العملية', '', 'select', 'esc', [['esc', 'تهريب الرموز (Escape)'], ['strip', 'إزالة التنسيق (Strip)']])], v => {
    if (v.m === 'strip') return v.t.replace(/```[\w]*\n?([\s\S]*?)```/g, '$1').replace(/(\*\*|__|~~|\|\||\*|_|`)/g, '').replace(/^(#{1,3} |> |-# )/gm, '');
    return v.t.replace(/([\\*_~`|>#\[\]()-])/g, '\\$1');
  });
  T('urlparse', '🔗', 'محلّل الروابط', 'يفكّك الرابط إلى بروتوكول ومضيف ومسار ومعاملات', 'النصوص', [F('u', 'الرابط', 'https://discord.com/channels/1/2/3?x=1&y=2#top')], v => {
    let u; try { u = new URL(v.u.trim()); } catch (e) { throw new Error('رابط غير صالح'); }
    const q = Array.from(u.searchParams.entries()).map(([k, x]) => `  ${k} = ${x}`).join('\n') || '  —';
    return `البروتوكول: ${u.protocol}\nالمضيف: ${u.hostname}\nالمنفذ: ${u.port || '—'}\nالمسار: ${u.pathname}\nالمعاملات:\n${q}\nالمرساة: ${u.hash || '—'}\nالأصل: ${u.origin}`;
  });
  T('tokeninfo', '🔑', 'فحص هيكل التوكن', 'يستخرج الـ ID وتاريخ إنشاء الحساب من التوكن دون إرساله لأي جهة', 'المعرفات', [F('t', 'التوكن (يُعالَج محلياً فقط)', '')], v => {
    const p = v.t.trim().split('.'); if (p.length < 3) throw new Error('الصيغة غير مفهومة (3 أجزاء مفصولة بنقطة)');
    let id; try { id = atob(p[0].replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - p[0].length % 4) % 4)); } catch (e) { throw new Error('الجزء الأول ليس Base64'); }
    if (!/^\d{15,25}$/.test(id)) throw new Error('لا يحتوي ID صالحاً');
    const ms = Number((BigInt(id) >> 22n) + 1420070400000n);
    return `User/Bot ID: ${id}\nأُنشئ في: ${dt(ms)}\nالجزء الثاني: ${p[1].length} حرف\nالجزء الثالث: ${p[2].length} حرف\nلا تشارك التوكن مع أحد.`;
  });
  T('textsplit', '📑', 'تقسيم النص الطويل', 'يقسّم نصاً أطول من 2000 حرف إلى رسائل مناسبة دون كسر الأسطر', 'النصوص', [F('t', 'النص الطويل', '', 'area'), F('n', 'الحد الأقصى للقطعة', '2000', 'num', 2000)], v => {
    const max = Math.max(100, Math.min(4000, +v.n || 2000)); const out = []; let cur = '';
    const push = () => { if (cur) { out.push(cur.replace(/\s+$/, '')); cur = ''; } };
    for (let line of v.t.split('\n')) {
      while (line.length > max) { push(); out.push(line.slice(0, max)); line = line.slice(max); }
      if ((cur + line).length + 1 > max) push();
      cur += line + '\n';
    }
    push();
    return out.map((x, i) => `── ${i + 1}/${out.length} (${x.length}) ──\n${x}`).join('\n\n');
  });
  T('bitfield', '🔢', 'محوّل الأرقام (عشري/ثنائي/Hex)', 'مفيد للصلاحيات والـ Flags', 'الصلاحيات', [F('n', 'القيمة', '8'), F('m', 'من', '', 'select', 'dec', [['dec', 'عشري'], ['hex', 'Hex'], ['bin', 'ثنائي']])], v => {
    const t = v.n.trim(); let n;
    try { n = v.m === 'hex' ? BigInt('0x' + t.replace(/^0x/i, '')) : v.m === 'bin' ? BigInt('0b' + t.replace(/^0b/i, '')) : BigInt(t); } catch (e) { throw new Error('قيمة غير صالحة'); }
    const on = []; for (let i = 0n; i < 64n; i++) if ((n >> i) & 1n) on.push(String(i));
    return `عشري: ${n}\nHex: 0x${n.toString(16).toUpperCase()}\nثنائي: ${n.toString(2)}\nالبتات المفعّلة: ${on.join(', ') || '—'}`;
  });
  T('tzconv', '🕒', 'محوّل المناطق الزمنية', 'يعرض وقتاً معيناً في عدة مدن مع صيغة Discord', 'الوقت', [F('d', 'التاريخ والوقت (بتوقيت جهازك)', '', 'date')], v => {
    const d = new Date(v.d); if (isNaN(d)) throw new Error('اختر تاريخاً ووقتاً');
    const zs = [['UTC', 'UTC'], ['القاهرة', 'Africa/Cairo'], ['الرياض', 'Asia/Riyadh'], ['دبي', 'Asia/Dubai'], ['إسطنبول', 'Europe/Istanbul'], ['لندن', 'Europe/London'], ['نيويورك', 'America/New_York'], ['لوس أنجلوس', 'America/Los_Angeles'], ['طوكيو', 'Asia/Tokyo']];
    const u = Math.floor(d.getTime() / 1000);
    return zs.map(([n, z]) => `${n}: ${d.toLocaleString(LOC, { timeZone: z, dateStyle: 'medium', timeStyle: 'short' })}`).join('\n') + `\n\n<t:${u}:F>\n<t:${u}:R>`;
  });
  T('emojicode', '😎', 'ترميز الإيموجي', 'النقاط الرمزية و\\u و HTML ورابط صورة ديسكورد', 'أدوات عامة', [F('t', 'إيموجي', '🔥')], v => {
    const cps = Array.from(v.t.trim()).map(c => c.codePointAt(0)); if (!cps.length) throw new Error('أدخل إيموجي');
    const hex = cps.map(c => c.toString(16)); const f = cps.includes(0x200d) ? hex : hex.filter(h => h !== 'fe0f');
    return `Unicode: ${cps.map(c => 'U+' + c.toString(16).toUpperCase()).join(' ')}\nJS: ${cps.map(c => '\\u{' + c.toString(16) + '}').join('')}\nHTML: ${cps.map(c => '&#x' + c.toString(16).toUpperCase() + ';').join('')}\nصورة: https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/72x72/${f.join('-')}.png`;
  });
  T('teams', '👥', 'تقسيم فرق عشوائي', 'وزّع الأسماء على فرق متوازنة', 'أدوات عامة', [F('l', 'الأسماء (سطر لكل اسم)', '', 'area'), F('n', 'عدد الفرق', '2', 'num', 2)], v => {
    const names = v.l.split('\n').map(x => x.trim()).filter(Boolean); const n = Math.max(2, Math.min(20, +v.n || 2));
    if (names.length < n) throw new Error('عدد الأسماء أقل من عدد الفرق');
    const a = new Uint32Array(names.length); crypto.getRandomValues(a);
    const sh = names.map((x, i) => [a[i], x]).sort((p, q) => p[0] - q[0]).map(x => x[1]); const teams = Array.from({ length: n }, () => []);
    sh.forEach((x, i) => teams[i % n].push(x));
    return teams.map((t, i) => `الفريق ${i + 1} (${t.length}):\n${t.map(x => '• ' + x).join('\n')}`).join('\n\n');
  });
  T('numfmt', '📊', 'تنسيق الأرقام', 'اختصار 1.2K و1,234,567 والنسب لأسماء قنوات الإحصاء', 'أدوات عامة', [F('n', 'الرقم', '1234567', 'num')], v => {
    const n = Number(v.n); if (!isFinite(n)) throw new Error('رقم غير صالح');
    const ab = x => { const a = Math.abs(x); return a >= 1e9 ? (x / 1e9).toFixed(1) + 'B' : a >= 1e6 ? (x / 1e6).toFixed(1) + 'M' : a >= 1e3 ? (x / 1e3).toFixed(1) + 'K' : String(x); };
    return `مفصول: ${n.toLocaleString('en-US')}\nمختصر: ${ab(n).replace('.0', '')}\nعلمي: ${n.toExponential(2)}\nعربي: ${n.toLocaleString('ar-EG')}`;
  });
  T('mdprev', '👁', 'معاينة ماركداون ديسكورد', 'اكتب نصاً وشاهد كيف سيظهر في ديسكورد', 'النصوص', [F('t', 'النص', '# عنوان\n**عريض** و *مائل* و ~~مشطوب~~\n> اقتباس\n`code` و ||سبويلر||', 'area')], v => ({ html: `<div class="card"><div class="mcontent" dir="auto">${md(v.t, {})}</div></div>`, text: v.t }));
  T('hookparse', '🪝', 'تفكيك رابط الويبهوك', 'يستخرج ID والتوكن ويتحقق من الصيغة محلياً', 'API', [F('u', 'رابط الويبهوك', 'https://discord.com/api/webhooks/123456789012345678/abcDEF_-xyz')], v => {
    const m = /webhooks\/(\d{15,25})\/([\w-]+)/.exec(v.u); if (!m) throw new Error('ليس رابط ويبهوك');
    const ms = Number((BigInt(m[1]) >> 22n) + 1420070400000n);
    return `Webhook ID: ${m[1]}\nأُنشئ في: ${dt(ms)}\nالتوكن: …${m[2].slice(-6)} (${m[2].length} حرف)\nرابط الرسائل: https://discord.com/api/webhooks/${m[1]}/…?wait=true\nتحذير: لا تنشر الرابط كاملاً.`;
  });
  T('coin', '🎲', 'عملة / 8 بول / نرد خيارات', 'قرارات سريعة بعشوائية آمنة', 'أدوات عامة', [F('m', 'النوع', '', 'select', 'coin', [['coin', 'عملة (صورة/كتابة)'], ['ball', 'كرة 8 السحرية'], ['d20', 'نرد 20 وجه']]), F('q', 'السؤال (اختياري)', '')], v => {
    const r = new Uint32Array(1); crypto.getRandomValues(r); const x = r[0];
    if (v.m === 'coin') return x % 2 ? 'صورة' : 'كتابة';
    if (v.m === 'd20') return String(x % 20 + 1);
    return ['نعم بالتأكيد', 'على الأرجح نعم', 'العلامات تقول نعم', 'غير واضح، حاول مجدداً', 'اسأل لاحقاً', 'لا أعتقد', 'مصادري تقول لا', 'مستحيل'][x % 8];
  });
  T('invparse', '✉', 'استخراج كود الدعوة', 'من أي رابط دعوة أو نص طويل', 'السيرفر', [F('t', 'النص', 'https://discord.gg/abc123 أو discord.com/invite/xyz')], v => {
    const m = Array.from(v.t.matchAll(/(?:discord(?:app)?\.com\/invite|discord\.gg|discord\.com\/invite)\/([\w-]+)/gi)).map(x => x[1]); if (!m.length) throw new Error('لم أجد دعوة');
    return m.map(c => `${c}  →  https://discord.gg/${c}`).join('\n');
  });

  T('limitchk', '📐', 'فاحص حدود Embed', 'يعدّ الحروف والحقول ويحذّر قبل الإرسال', 'API', [F('t', 'JSON الرسالة', '', 'area')], v => {
    let j; try { j = JSON.parse(v.t); } catch (e) { throw new Error('JSON غير صالح'); } const es = j.embeds || (j.title || j.description || j.fields ? [j] : []); let tot = 0; const out = [];
    es.forEach((e, i) => { const n = (e.title || '').length + (e.description || '').length + ((e.footer || {}).text || '').length + ((e.author || {}).name || '').length + (e.fields || []).reduce((a, f) => a + (f.name || '').length + (f.value || '').length, 0); tot += n; out.push(`Embed ${i + 1}: ${n} حرف · ${(e.fields || []).length}/25 حقل` + ((e.title || '').length > 256 ? ' ⚠️ العنوان >256' : '') + ((e.description || '').length > 4096 ? ' ⚠️ الوصف >4096' : '')); });
    return `المحتوى: ${(j.content || '').length}/2000${(j.content || '').length > 2000 ? ' ⚠️' : ''}\nEmbeds: ${es.length}/10\n${out.join('\n')}\nالمجموع: ${tot}/6000${tot > 6000 ? ' ⚠️ تجاوز' : ' ✓'}`;
  }, { live: true });
  T('gradient', '🌈', 'تدرج بين لونين', 'درجات وسيطة لاختيار ألوان الـ Embed والرتب', 'الألوان', [F('a', 'من', '#5865f2'), F('b', 'إلى', '#eb459e'), F('n', 'العدد', '7', 'num')], v => {
    const h = s => { const m = /^#?([0-9a-f]{6})$/i.exec(s.trim()); if (!m) throw new Error('لون HEX غير صالح'); return [0, 2, 4].map(i => parseInt(m[1].slice(i, i + 2), 16)); }, A2 = h(v.a), B2 = h(v.b), n = Math.min(20, Math.max(2, pn(v.n)));
    return Array.from({ length: n }, (_, i) => { const c = A2.map((x, k) => Math.round(x + (B2[k] - x) * i / (n - 1))); const hx = '#' + c.map(x => x.toString(16).padStart(2, '0')).join(''); return `${hx}   ${parseInt(hx.slice(1), 16)}`; }).join('\n');
  }, { live: true });

  /* ---------- engine ---------- */
  function fieldHTML(f) {
    const id = 'tf-' + f.id, d = typeof f.d === 'function' ? f.d() : (f.d == null ? '' : f.d);
    if (f.k === 'area') return `<div class="field"><label>${esc(f.l)}</label><textarea id="${id}" rows="4" dir="auto" placeholder="${esc(f.p || '')}">${esc(d)}</textarea></div>`;
    if (f.k === 'select') return `<div class="field"><label>${esc(f.l)}</label><select id="${id}">${f.o.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(d) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></div>`;
    if (f.k === 'date') return `<div class="field"><label>${esc(f.l)}</label><input id="${id}" type="datetime-local" value="${new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 16)}"></div>`;
    if (f.k === 'file') return `<div class="field"><label>${esc(f.l)}</label><input id="${id}" type="file" accept="image/*"></div>`;
    const type = f.k === 'pass' ? 'password' : f.k === 'num' ? 'number' : 'text';
    return `<div class="field"><label>${esc(f.l)}</label><input id="${id}" class="ltr" type="${type}" ${type === 'number' ? 'inputmode="decimal"' : ''} placeholder="${esc(f.p || '')}" value="${esc(d)}" autocomplete="off"></div>`;
  }
  function readValues(t) {
    const v = {};
    t.fields.forEach(f => { const el = $('#tf-' + f.id); v[f.id] = f.k === 'file' ? (el.files && el.files[0]) : el.value; });
    return v;
  }
  function showOut(res, t) {
    const box = $('#t-out'); if (!box) return;
    if (res == null) { box.innerHTML = ''; return; }
    const text = typeof res === 'string' ? res : (res.text != null ? res.text : '');
    if (Place.pref('tools', 'autoCopy') && text) { try { if (NATIVE) NATIVE.copy(String(text)); else navigator.clipboard && navigator.clipboard.writeText(String(text)); } catch (e) { /* ignore */ } }
    let h = typeof res === 'string' ? `<div class="result">${esc(res)}</div>` : res.html ? res.html : `<div class="result">${esc(text)}</div>`;
    if (text) h += `<div class="row" style="margin-top:8px"><button class="btn sec grow" data-act="tool.copyout">📋 نسخ النتيجة</button>${t.sendToComposer ? '<button class="btn grow" data-act="tool.tocomposer">✉️ فتح في المرسل</button>' : ''}</div>`;
    box.innerHTML = h; box._text = text;
  }
  async function runActive(btn) {
    const t = active; if (!t || !t.run) return;
    await withBusy(btn, async () => {
      try { showOut(await t.run(readValues(t)), t); }
      catch (e) { showOut(null); toast(e.message || String(e), 'bad'); }
    });
  }

  /* ---------- views ---------- */
  const IC = {
    base: d => `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`,
    'المعرفات': '<path d="M5 9h14M5 15h14M9 4 7 20M17 4l-2 16"/>', 'الوقت': '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    'الصلاحيات': '<path d="M12 3 5 6v5c0 4.5 3 8 7 10 4-2 7-5.5 7-10V6z"/>', 'النصوص': '<path d="M5 6h14M12 6v13M9 19h6"/>',
    'الألوان': '<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2-.6-1.2 0-2.5 1.5-2.5H17a4 4 0 0 0 4-4c0-5-4-9.5-9-9.5z"/><circle cx="8" cy="11" r="1"/><circle cx="12" cy="7.5" r="1"/><circle cx="16" cy="11" r="1"/>',
    'السيرفر': '<rect x="3" y="4" width="18" height="6" rx="2"/><rect x="3" y="14" width="18" height="6" rx="2"/><path d="M7 7h.01M7 17h.01"/>', 'البوتات': '<rect x="4" y="8" width="16" height="11" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9.5 16.5h5"/>',
    'API': '<path d="m8 8-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/>', 'أدوات عامة': '<path d="M14.5 5.5a4 4 0 0 0-5 5L4 16l4 4 5.5-5.5a4 4 0 0 0 5-5l-3 3-3-1-1-3z"/>'
  };
  const icon = (c, e) => (e && Icons.forEmoji(e)) || IC.base(IC[c] || IC['أدوات عامة']);
  const favs = () => store.get('tool_favs', []), recents = () => store.get('tool_recent', []);
  const toolRow = t => `<div class="set-row" data-act="tool.open" data-id="${t.id}" role="button"><span class="ico">${icon(t.cat, t.ico)}</span><span class="tx"><b>${esc(t.name)}</b><small>${esc(t.desc)}</small></span><button class="fav ${favs().includes(t.id) ? 'on' : ''}" data-act="tool.fav" data-id="${t.id}" aria-label="مفضلة">${Icons.svg('star')}</button></div>`;
  const group = (title, ts) => ts.length ? `<div class="set-grp">${esc(title)}</div><div class="set-list">${ts.map(toolRow).join('')}</div>` : '';
  const hidden = () => store.get('tool_hidden', []);
  const vis = t => !hidden().includes(t.id);
  function viewHome() {
    active = null;
    const q = query.trim().toLowerCase(), by = id => LIST.find(t => t.id === id);
    let body;
    if (q || cat !== 'الكل') {
      const found = LIST.filter(t => vis(t) && (cat === 'الكل' || t.cat === cat) && (t.name + ' ' + t.desc + ' ' + t.id).toLowerCase().includes(q));
      body = found.length ? `<div class="set-list" style="margin-top:12px">${found.map(toolRow).join('')}</div>` : '<div class="empty">لا توجد أدوات مطابقة</div>';
    } else {
      body = group('المفضلة', favs().map(by).filter(t => t && vis(t))) + group('استخدمت مؤخراً', recents().map(by).filter(Boolean).slice(0, 4)) + CATS.slice(1).map(c => group(c, LIST.filter(t => vis(t) && t.cat === c))).join('');
    }
    root.innerHTML = `<div class="pad"><div class="set-hero"><label class="set-search"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="var(--muted)" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg><input id="t-search" type="text" placeholder="بحث في ${LIST.length} أداة" value="${esc(query)}" autocomplete="off"></label></div>
      <nav class="chips">${CATS.map(c => `<button class="chip ${c === cat ? 'on' : ''}" data-act="tool.cat" data-c="${c}">${c}</button>`).join('')}<button class="chip" data-act="tool.custom">تخصيص</button></nav>${body}</div>`;
    const s = $('#t-search');
    s.addEventListener('input', () => { query = s.value; const pos = s.selectionStart; viewHome(); const n = $('#t-search'); n.focus(); n.setSelectionRange(pos, pos); });
  }
  function customize() {
    const draw = () => {
      const f = favs().map(id => LIST.find(t => t.id === id)).filter(Boolean), h = hidden();
      return `<p class="sub" style="margin:0 0 8px">رتّب المفضلة بالأسهم، وأخفِ الأدوات التي لا تستخدمها (تبقى متاحة من البحث السريع).</p>
        <div class="pf-sec" style="margin-top:4px">المفضلة</div>${f.length ? f.map((t, i) => `<div class="cz"><span class="uc">${esc(t.name)}</span><button data-mv="${i}" data-d="-1" ${i === 0 ? 'disabled' : ''} aria-label="أعلى">${Icons.svg('cd')}</button><button data-mv="${i}" data-d="1" ${i === f.length - 1 ? 'disabled' : ''} aria-label="أسفل">${Icons.svg('cd')}</button></div>`).join('') : '<div class="empty" style="padding:8px">لا توجد مفضلة — اضغط النجمة بجانب أي أداة</div>'}
        <div class="pf-sec">كل الأدوات (${LIST.length - h.length} ظاهرة)</div>${LIST.map(t => `<label class="switch cz2"><span><span class="uc">${esc(t.name)}</span></span><input type="checkbox" data-hid="${esc(t.id)}" ${h.includes(t.id) ? '' : 'checked'}></label>`).join('')}
        <button class="btn sec block" id="cz-reset" style="margin-top:10px">إظهار الكل</button>`;
    };
    const s = openSheet(`<div id="cz-body">${draw()}</div>`, { title: 'تخصيص الأدوات', onClose: () => { if (!active) viewHome(); } });
    const redraw = () => { const y = s.el.scrollTop; $('#cz-body', s.el).innerHTML = draw(); s.el.scrollTop = y; };
    s.el.addEventListener('click', e => {
      const mv = e.target.closest('[data-mv]'); if (mv) { const l = favs(), i = +mv.dataset.mv, j = i + +mv.dataset.d; if (j >= 0 && j < l.length) { [l[i], l[j]] = [l[j], l[i]]; store.set('tool_favs', l); redraw(); } return; }
      if (e.target.id === 'cz-reset') { store.set('tool_hidden', []); redraw(); }
    });
    s.el.addEventListener('change', e => { const c = e.target.closest('[data-hid]'); if (!c) return; const h = hidden().filter(x => x !== c.dataset.hid); if (!c.checked) h.push(c.dataset.hid); store.set('tool_hidden', h); redraw(); });
  }
  function open(id) {
    const t = LIST.find(x => x.id === id); if (!t) return;
    active = t; store.set('tool_recent', [id].concat(recents().filter(x => x !== id)).slice(0, 8));
    root.innerHTML = `<div class="pad"><button class="back" data-act="tool.home">→ الأدوات</button><div class="tool-head"><span class="ico">${icon(t.cat, t.ico)}</span><div><div class="h1">${esc(t.name)}</div><p class="sub">${esc(t.desc)}</p></div></div>
      ${t.custom ? t.custom.html : t.fields.map(fieldHTML).join('') + (t.auto ? '' : `<button class="btn block" data-act="tool.run">تنفيذ</button>`)}<div id="t-out"></div></div>`;
    if (t.custom && t.custom.init) t.custom.init(root);
    if (t.auto) runActive(null);
    const live = Place.pref('tools', 'live') !== false && (t.live || (!t.custom && !t.auto && LOCAL.includes(t.cat) && t.fields.length && !t.fields.some(f => f.k === 'file' || f.k === 'pass')));
    if (live && !t.custom) {
      let tm = null;
      const go = async () => { try { showOut(await t.run(readValues(t)), t); } catch (e) { const b = $('#t-out'); if (b) b.innerHTML = `<div class="result err">${esc(e.message || String(e))}</div>`; } };
      $$('input,textarea,select', root).forEach(el => { el.addEventListener('input', () => { clearTimeout(tm); tm = setTimeout(go, 250); }); el.addEventListener('change', () => { clearTimeout(tm); tm = setTimeout(go, 50); }); });
      if (!t.auto && t.fields.every(f => f.p || f.d != null || f.k === 'select' || f.k === 'num')) { /* preview with defaults */ }
    }
    root.scrollTop = 0;
  }
  function calcChecked(table) {
    const n = $$('[data-v]:checked', root).reduce((a, i) => a + BigInt(i.dataset.v), 0n);
    return n;
  }
  registerActions({
    'tool.fav': t => { const id = t.dataset.id, f = favs(); store.set('tool_favs', f.includes(id) ? f.filter(x => x !== id) : f.concat(id)); const y = root.scrollTop; viewHome(); root.scrollTop = y; },
    'tool.open': t => open(t.dataset.id), 'tool.home': viewHome, 'tool.custom': customize, 'tool.cat': t => { cat = t.dataset.c; viewHome(); },
    'tool.run': t => runActive(t),
    'tool.copyout': () => copyText($('#t-out')._text),
    'tool.copy': t => copyText(t.dataset.t),
    'tool.tocomposer': () => { try { Composer.load(JSON.parse($('#t-out')._text)); Composer.render(); App.goTab('composer'); toast('تم التحميل في المرسل', 'ok'); } catch (e) { toast('تعذر الفتح: ' + e.message, 'bad'); } },
    'tool.permcalc': () => {
      const n = calcChecked(), c = ($('#pc-c') || {}).value || '';
      showOut(`permissions = ${n}\n${bits(n, PERMS).length} صلاحية${isId(c) ? `\n\nhttps://discord.com/oauth2/authorize?client_id=${c.trim()}&permissions=${n}&scope=bot%20applications.commands` : ''}`, {});
    },
    'tool.intcalc': () => { const n = calcChecked(); showOut(`intents = ${n}\n${bits(n, INTENTS).join(', ')}`, {}); }
  });
  function mount(el) { root = el; viewHome(); }
  function back() { if (active) { viewHome(); return true; } return false; }
  return { mount, back, list: LIST, open, get active() { return !!active; } };
})();

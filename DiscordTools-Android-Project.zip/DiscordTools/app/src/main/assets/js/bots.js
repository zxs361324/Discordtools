'use strict';
/* ============================================================
   bots.js — bot control panel: profile, servers, channels (live
   chat), members & moderation, webhooks, roles, bans, invites…
   ============================================================ */
class Gateway {
  constructor(token, getPresence, onState, opts) { opts = opts || {}; this.intents = opts.intents || 0; this.onEvent = opts.onEvent || null; this.token = token; this.getPresence = getPresence; this.onState = onState; this.ws = null; this.seq = null; this.hb = null; this.closed = false; this.sessionId = null; this.resumeUrl = null; }
  connect() {
    this.closed = false; this.onState('connecting');
    let ws;
    try { ws = new WebSocket((this.resumeUrl || 'wss://gateway.discord.gg') + '/?v=10&encoding=json'); }
    catch (e) { this.onState('error: ' + e.message); return; }
    this.ws = ws;
    ws.onmessage = ev => {
      let p; try { p = JSON.parse(ev.data); } catch (e) { return; }
      if (p.s != null) this.seq = p.s;
      if (p.op === 10) {
        const iv = p.d.heartbeat_interval; clearInterval(this.hb);
        setTimeout(() => this.beat(), iv * Math.random()); this.hb = setInterval(() => this.beat(), iv);
        if (this.sessionId && this.seq != null) ws.send(JSON.stringify({ op: 6, d: { token: this.token, session_id: this.sessionId, seq: this.seq } }));
        else this.identify();
      } else if (p.op === 1) this.beat();
      else if (p.op === 7) ws.close(4000);
      else if (p.op === 9) { if (!p.d) { this.sessionId = null; this.seq = null; this.resumeUrl = null; } setTimeout(() => this.identify(), 1500 + Math.random() * 3000); }
      else if (p.op === 0 && p.t === 'READY') { this.sessionId = p.d.session_id; this.resumeUrl = p.d.resume_gateway_url; this.onState('online'); }
      else if (p.op === 0 && p.t === 'RESUMED') this.onState('online');
      else if (p.op === 0 && this.onEvent) { try { this.onEvent(p.t, p.d); } catch (e) { /* ignore */ } }
    };
    ws.onclose = ev => {
      clearInterval(this.hb);
      if (this.closed) { this.onState('offline'); return; }
      if ([4004, 4010, 4011, 4012, 4013, 4014].includes(ev.code)) { this.onState('error: ' + ({ 4004: 'التوكن غير صالح', 4014: 'Intents غير مسموحة' }[ev.code] || 'رمز ' + ev.code)); return; }
      this.onState('reconnecting'); setTimeout(() => { if (!this.closed) this.connect(); }, 4000);
    };
    ws.onerror = () => { /* handled by onclose */ };
  }
  beat() { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify({ op: 1, d: this.seq })); }
  identify() { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify({ op: 2, d: { token: this.token, intents: this.intents, properties: { os: 'android', browser: 'discord-tools', device: 'discord-tools' }, ...(this.getPresence ? { presence: this.getPresence() } : {}) } })); }
  close() { this.closed = true; clearInterval(this.hb); if (this.ws) { try { this.ws.close(1000); } catch (e) { /* ignore */ } } }
}

const Bots = (() => {
  let root = null;
  const B = { token: '', bot: null, app: null, guilds: [], guild: null, stack: [], cv: null };
  const T = () => ({ token: B.token });
  const PERMS = [['Administrator', 8n], ['View Channels', 1024n], ['Manage Channels', 16n], ['Manage Roles', 268435456n], ['Manage Guild', 32n], ['Manage Webhooks', 536870912n],
    ['Kick Members', 2n], ['Ban Members', 4n], ['Moderate Members', 1099511627776n], ['Send Messages', 2048n], ['Manage Messages', 8192n], ['Embed Links', 16384n], ['Attach Files', 32768n],
    ['Read History', 65536n], ['Mention Everyone', 131072n], ['Add Reactions', 64n], ['Use Slash Commands', 2147483648n], ['Connect', 1048576n], ['Speak', 2097152n], ['Create Invite', 1n]];

  /* ---------- nav ---------- */
  function go(fn) { B.stack.push(fn); fn(); }
  function back() {
    if (B.stack.length > 1) { B.stack.pop(); if (B.cv) { B.cv.stop(); B.cv = null; } B.stack[B.stack.length - 1](); return true; }
    return false;
  }
  function setBase(fn) { B.stack = [fn]; fn(); }
  function crumb(title, extra) {
    return `<div class="crumb"><button class="ibtn" data-act="bot.back" style="width:32px;height:32px">→</button><b class="grow uc" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${title}</b>${extra || ''}</div>`;
  }
  function page(html, flex) { root.classList.toggle('flex', !!flex); root.innerHTML = html; root.scrollTop = 0; }
  function mount(el) {
    root = el;
    const t = Tokens.get();
    if (t) { B.token = t; autoLogin(); } else setBase(viewLogin);
  }
  async function autoLogin() {
    page(loadingHTML());
    try { await login(B.token); setBase(viewHome); } catch (e) { setBase(viewLogin); }
  }
  async function login(token) {
    B.bot = await dapi('GET', '/users/@me', { token });
    B.token = token;
    try { B.app = await dapi('GET', '/oauth2/applications/@me', { token }); } catch (e) { B.app = null; }
    B.guilds = await dapi('GET', '/users/@me/guilds', { token, query: { limit: 200, with_counts: 'true' } });
  }

  /* ---------- login ---------- */
  function viewLogin() {
    page(`<div class="pad"><div class="h1">🤖 لوحة تحكم البوتات</div>
      <p class="sub">سجّل دخول ببوتك لإدارة السيرفرات والقنوات والأعضاء والويبهوكات من الجوال.</p>
      <div class="card" style="margin-top:14px"><div class="field"><label>توكن البوت</label><div class="row"><input id="b-tok" class="ltr" type="password" placeholder="Bot token" value="${esc(B.token)}"><button class="ibtn" data-act="bot.eye">👁</button></div></div>
      <label class="switch"><span>تذكّر التوكن على هذا الجهاز</span><input type="checkbox" id="b-rem" ${settings.all.remember ? 'checked' : ''}></label>
      <button class="btn block" data-act="bot.login">تسجيل الدخول</button></div>
      <div class="note info">التوكن يُرسل إلى Discord فقط ولا يغادر جهازك لأي جهة أخرى. من يملك التوكن يملك البوت — لا تشاركه أبداً.</div></div>`);
  }
  async function doLogin(btn) {
    const t = $('#b-tok').value.trim();
    if (!t) throw new Error('أدخل التوكن');
    settings.set('remember', $('#b-rem').checked);
    await withBusy(btn, async () => {
      await login(t);
      if ($('#b-rem').checked) Tokens.set(t); else Tokens.clear();
      setBase(viewHome);
    });
  }

  /* ---------- home ---------- */
  function intents(app) {
    if (!app) return '';
    const f = app.flags || 0;
    const chip = (n, on) => `<span class="pill"><span class="dot ${on ? '' : 'off'}"></span>${n}</span>`;
    return `<div class="row wrap" style="margin-top:10px">${chip('Message Content', f & (1 << 18) || f & (1 << 19))}${chip('Server Members', f & (1 << 14) || f & (1 << 15))}${chip('Presence', f & (1 << 12) || f & (1 << 13))}</div>`;
  }
  function viewHome() {
    const b = B.bot;
    const row = (ic, t, s, act) => `<button class="list-item" data-act="${act}"><span class="ph" style="font-size:20px;background:var(--bg3)">${ic}</span><div class="grow"><div class="n">${t}</div><div class="s" style="direction:rtl">${s}</div></div><span style="color:var(--muted)">‹</span></button>`;
    page(`<div class="pad"><div class="card"><div class="botcard"><img src="${esc(userAvatar(b, 128))}" alt=""><div class="grow"><div class="n"><span class="uc">${esc(b.global_name || b.username)}</span></div><div class="sub" style="direction:ltr;text-align:start">@<span class="uc">${esc(b.username)}</span> · <span class="uc">${esc(b.id)}</span></div><div class="sub">أُنشئ ${new Date(snowflakeMs(b.id)).toLocaleDateString()}</div></div></div>${intents(B.app)}</div>
      <div class="sect">إدارة</div><div class="card" style="padding:4px">
      ${row('🏰', 'السيرفرات', B.guilds.length + ' سيرفر', 'bot.guilds')}
      ${row(gwDot(), 'الحالة والنشاط', 'أونلاين / مشغول / يلعب… (يعمل أثناء فتح التطبيق)', 'bot.presence')}
      ${row('⚡', 'أوامر Slash', 'عرض وإنشاء وحذف الأوامر', 'bot.cmds')}
      ${row('🎨', 'تعديل ملف البوت', 'الاسم والصورة', 'bot.edit')}
      ${row('🔗', 'رابط دعوة البوت', 'مع اختيار الصلاحيات', 'bot.invite')}
      ${row('💬', 'مراسلة مستخدم (DM)', 'إرسال رسالة خاصة بالبوت', 'bot.dm')}
      ${row('🚪', 'تسجيل الخروج', 'إزالة التوكن من الجهاز', 'bot.logout')}</div></div>`);
  }

  /* ---------- guilds ---------- */
  function viewGuilds() {
    page(crumb('السيرفرات') + `<div class="pad">${B.guilds.length ? B.guilds.map(g => `<button class="list-item" data-act="bot.guild" data-g="${esc(g.id)}">${g.icon ? `<img src="${esc(guildIcon(g))}" alt="">` : `<span class="ph"><span class="uc">${esc((g.name || '?')[0])}</span></span>`}<div class="grow"><div class="n"><span class="uc">${esc(g.name)}</span></div><div class="s" style="direction:rtl">${g.approximate_member_count ? g.approximate_member_count + ' عضو' : g.id}${g.owner ? ' · 👑 مالك' : ''}</div></div></button>`).join('') : '<div class="empty">البوت ليس في أي سيرفر</div>'}</div>`);
  }
  async function openGuild(id) {
    B.guild = B.guilds.find(g => g.id === id);
    go(viewGuild);
  }
  function viewGuild() {
    const g = B.guild;
    const row = (ic, t, act) => `<button class="list-item" data-act="${act}"><span class="ph" style="font-size:20px;background:var(--bg3)">${ic}</span><div class="grow"><div class="n">${t}</div></div><span style="color:var(--muted)">‹</span></button>`;
    page(crumb(esc(g.name)) + `<div class="pad"><div class="card" style="padding:4px">
      ${row('🗂️', 'القنوات والمحادثات', 'bot.channels')}${row('🧵', 'الثريدات النشطة', 'bot.threads')}${row('👥', 'البحث عن عضو', 'bot.members')}${row('📋', 'قائمة الأعضاء', 'bot.memlist')}${row('🪝', 'الويبهوكات', 'bot.hooks')}${row('🛡️', 'الرتب', 'bot.roles')}</div>
      <div class="sect">الإشراف</div><div class="card" style="padding:4px">
      ${row('🔨', 'المحظورون', 'bot.bans')}${row('⛔', 'حظر بالـ ID', 'bot.banid')}${row('📜', 'سجل التدقيق', 'bot.audit')}${row('🤖', 'قواعد AutoMod', 'bot.automod')}${row('✉️', 'الدعوات', 'bot.invites')}</div>
      <div class="sect">السيرفر</div><div class="card" style="padding:4px">
      ${row('😀', 'الإيموجي', 'bot.emojis')}${row('🏷️', 'الستيكرز', 'bot.stickers')}${row('✏️', 'تغيير اسم السيرفر', 'bot.grename')}${row('🚪', 'مغادرة السيرفر', 'bot.leave')}</div></div>`);
  }
  function listPage(title, items, empty) {
    page(crumb(title) + `<div class="pad" id="lp">${loadingHTML()}</div>`);
    return html => { const el = $('#lp'); if (el) el.innerHTML = html || `<div class="empty">${empty || 'لا يوجد'}</div>`; };
  }

  /* ---------- channels ---------- */
  async function viewChannels() {
    const set = listPage('القنوات');
    try {
      const chs = await dapi('GET', `/guilds/${B.guild.id}/channels`, T());
      B.chans = chs;
      const cats = chs.filter(c => c.type === 4).sort((a, b) => a.position - b.position);
      const ic = { 0: '#', 2: '🔊', 5: '📢', 13: '🎙', 15: '🗂' };
      const item = c => `<button class="chan" data-act="bot.chan" data-c="${esc(c.id)}"><span class="h">${ic[c.type] || '#'}</span><span class="uc">${esc(c.name)}</span></button>`;
      const loose = chs.filter(c => c.type !== 4 && !(c.parent_id && cats.find(k => k.id === c.parent_id))).sort((a, b) => a.position - b.position);
      let h = `<button class="btn sm block" data-act="bot.newchan" style="margin-bottom:8px">＋ إنشاء قناة</button>` + loose.map(item).join('');
      cats.forEach(k => { h += `<div class="cat"><span class="uc">${esc(k.name)}</span></div>` + chs.filter(c => c.parent_id === k.id).sort((a, b) => a.position - b.position).map(item).join(''); });
      set(h);
    } catch (e) { set(`<div class="empty">⚠️ ${esc(e.message)}</div>`); }
  }
  function openChat(cid) {
    const c = (B.chans || []).find(x => x.id === cid);
    if (!c) return;
    if (![0, 5, 10, 11, 12].includes(c.type)) return toast('هذا النوع من القنوات لا يدعم المحادثة هنا', 'bad');
    go(() => viewChat(c));
  }
  function viewChat(c) {
    const token = B.token, gid = B.guild.id, me = B.bot.id;
    page(crumb('<bdi>#' + esc(c.name) + '</bdi>', `<button class="ibtn" data-act="bot.chmenu" data-c="${esc(c.id)}" style="width:32px;height:32px">⋯</button>`) + '<div style="flex:1;min-height:0" id="b-chat"></div>', true);
    const names = {}; (B.chans || []).forEach(x => { names[x.id] = x.name; });
    B.cv = new ChatView($('#b-chat'), {
      channelId: c.id, guildId: gid, replyMode: 'native', channelNames: names, intervalMs: Place.pref('bots', 'pollMs'), place: 'bots', token, live: Place.pref('bots', 'live') !== false ? liveFactory(token) : null,
      placeholder: `رسالة إلى #${c.name} كبوت`,
      profile: { onManage: (u, mem) => memberMenu(mem && mem.user ? mem : { user: u, roles: [], nick: null }) },
      getMessages: before => dapi('GET', `/channels/${c.id}/messages`, { token, query: before ? { limit: 50, before } : { limit: 50 } }),
      isMine: m => m.author && m.author.id === me,
      send: async ({ text, files, replyTo, ping }) => {
        const json = { content: text, allowed_mentions: settings.all.allowEveryone ? { parse: ['users', 'roles', 'everyone'], replied_user: !!ping } : { parse: ['users'], replied_user: !!ping } };
        if (replyTo) json.message_reference = { message_id: replyTo.id, fail_if_not_exists: false };
        return dapi('POST', `/channels/${c.id}/messages`, { token, json, files: files.length ? await filesPayload(files) : undefined });
      },
      sendVoice: async ({ voice, replyTo }) => {
        const extra = {}; if (replyTo) extra.message_reference = { message_id: replyTo.id, fail_if_not_exists: false };
        const vj = await Media.voiceJson(voice, extra);
        return dapi('POST', `/channels/${c.id}/messages`, { token, json: vj.json, files: vj.files });
      },
      edit: (m, text) => dapi('PATCH', `/channels/${c.id}/messages/${m.id}`, { token, json: { content: text } }),
      del: m => dapi('DELETE', `/channels/${c.id}/messages/${m.id}`, { token }),
      botDel: m => dapi('DELETE', `/channels/${c.id}/messages/${m.id}`, { token }),
      react: (m, e) => dapi('PUT', `/channels/${c.id}/messages/${m.id}/reactions/${encodeURIComponent(e)}/@me`, { token }),
      unreact: (m, e) => dapi('DELETE', `/channels/${c.id}/messages/${m.id}/reactions/${encodeURIComponent(e)}/@me`, { token }),
      onFatal: e => toast('توقفت المزامنة: ' + e.message, 'bad')
    });
    B.cv.start();
  }
  async function chMenu(cid) {
    const c = B.chans.find(x => x.id === cid);
    menuSheet('# ' + c.name, [
      { icon: '🧹', label: 'حذف آخر رسائل (جماعي)', fn: async () => {
        const n = await promptDlg({ title: 'كم رسالة؟', label: 'من 2 إلى 100 (أحدث من 14 يوماً)', value: '10' });
        const k = Math.max(2, Math.min(100, parseInt(n, 10) || 0));
        if (!n || k < 2) return;
        const ms = await dapi('GET', `/channels/${c.id}/messages`, { token: B.token, query: { limit: k } });
        const ok = ms.filter(m => Date.now() - new Date(m.timestamp) < 13.5 * 86400000).map(m => m.id);
        if (ok.length < 2) return toast('لا توجد رسائل صالحة للحذف الجماعي', 'bad');
        if (!await confirmDlg(`حذف ${ok.length} رسالة؟`, { danger: true, ok: 'حذف' })) return;
        await dapi('POST', `/channels/${c.id}/messages/bulk-delete`, { token: B.token, json: { messages: ok } });
        toast('تم الحذف', 'ok'); if (B.cv) B.cv.load();
      } },
      { icon: '✏️', label: 'تغيير الاسم', fn: async () => { const v = await promptDlg({ title: 'اسم القناة', label: 'الاسم', value: c.name }); if (v && v.trim()) { await dapi('PATCH', `/channels/${c.id}`, { token: B.token, json: { name: v.trim() } }); c.name = v.trim(); toast('تم', 'ok'); } } },
      { icon: '📝', label: 'تغيير الوصف (Topic)', fn: async () => { const v = await promptDlg({ title: 'وصف القناة', label: 'Topic', value: c.topic || '', multiline: true }); if (v != null) { await dapi('PATCH', `/channels/${c.id}`, { token: B.token, json: { topic: v } }); toast('تم', 'ok'); } } },
      { icon: '🐢', label: 'الوضع البطيء (Slowmode)', fn: async () => { const v = await promptDlg({ title: 'ثوانٍ بين الرسائل', label: '0 للإيقاف', value: String(c.rate_limit_per_user || 0) }); if (v != null) { await dapi('PATCH', `/channels/${c.id}`, { token: B.token, json: { rate_limit_per_user: Math.max(0, Math.min(21600, parseInt(v, 10) || 0)) } }); toast('تم', 'ok'); } } },
      { icon: '🔗', label: 'إنشاء رابط دعوة', fn: async () => { const i = await dapi('POST', `/channels/${c.id}/invites`, { token: B.token, json: { max_age: 86400, max_uses: 0 } }); copyText('https://discord.gg/' + i.code, 'تم نسخ رابط الدعوة (24 ساعة)'); } },
      { icon: '📌', label: 'الرسائل المثبّتة', fn: async () => { const p = await dapi('GET', `/channels/${c.id}/pins`, { token: B.token }); const list = Array.isArray(p) ? p : (p.items || []).map(x => x.message || x); openSheet(list.length ? list.map(m => renderMessage(m, {})).join('') : '<div class="empty">لا توجد رسائل مثبّتة</div>', { title: 'المثبّتة' }); } },
      ...(Place.pref('bots', 'analytics') ? [{ icon: '📊', label: 'تحليلات القناة', fn: () => analyzeChannel(c) }] : []),
      { icon: '📄', label: 'تصدير سجل القناة (نص)', fn: () => exportChannel(c) },
      { icon: '🔒', label: 'قفل / فتح القناة (منع @everyone من الكتابة)', fn: async () => {
        try {
          const ch = await dapi('GET', `/channels/${c.id}`, { token: B.token });
          const ow = (ch.permission_overwrites || []).find(x => x.id === (ch.guild_id || B.guild.id) && x.type === 0) || { allow: '0', deny: '0' };
          const SEND = 1n << 11n; let deny = BigInt(ow.deny || 0), allow = BigInt(ow.allow || 0); const locked = (deny & SEND) !== 0n;
          if (locked) deny &= ~SEND; else { deny |= SEND; allow &= ~SEND; }
          await dapi('PUT', `/channels/${c.id}/permissions/${ch.guild_id || B.guild.id}`, { token: B.token, json: { type: 0, allow: String(allow), deny: String(deny) } });
          toast(locked ? 'تم فتح القناة' : 'تم قفل القناة', 'ok');
        } catch (e) { toast(e.message, 'bad'); }
      } },
      { icon: '🔞', label: 'تبديل NSFW', fn: async () => { try { const ch = await dapi('GET', `/channels/${c.id}`, { token: B.token }); await dapi('PATCH', `/channels/${c.id}`, { token: B.token, json: { nsfw: !ch.nsfw } }); toast(ch.nsfw ? 'أُلغي NSFW' : 'فُعّل NSFW', 'ok'); } catch (e) { toast(e.message, 'bad'); } } },
      { icon: '🗑️', label: 'حذف القناة', cls: 'red', fn: async () => { if (await confirmDlg(`حذف القناة #${c.name} نهائياً؟`, { danger: true, ok: 'حذف القناة' })) { await dapi('DELETE', `/channels/${c.id}`, { token: B.token }); toast('تم حذف القناة', 'ok'); back(); } } }
    ]);
  }
  /* ---------- channel analytics + export (optional, local only) ---------- */
  async function fetchHistory(cid, want, onProg) {
    let all = [], before = '';
    while (all.length < want) {
      const q = { limit: 100 }; if (before) q.before = before;
      const r = await dapi('GET', `/channels/${cid}/messages`, { token: B.token, query: q });
      if (!Array.isArray(r) || !r.length) break;
      all = all.concat(r); before = r[r.length - 1].id; if (onProg) onProg(all.length); if (r.length < 100) break;
    }
    return all.slice(0, want);
  }
  function statBars(vals, labels, hi) {
    const mx = Math.max(1, ...vals);
    return `<div class="an-bars">${vals.map((v, i) => `<div class="an-b" title="${esc(labels[i])}: ${v}"><i style="height:${Math.round(v / mx * 100)}%;${i === hi ? 'background:var(--brand)' : ''}"></i><span>${esc(labels[i])}</span></div>`).join('')}</div>`;
  }
  async function analyzeChannel(c) {
    const n = await new Promise(res => menuSheet('عدد الرسائل للتحليل', [100, 300, 500, 1000].map(k => ({ icon: '📊', label: 'آخر ' + k + ' رسالة', fn: () => res(k) })), () => res(0)));
    if (!n) return;
    toast('جارِ جلب الرسائل…');
    let msgs; try { msgs = await fetchHistory(c.id, n); } catch (e) { return toast(e.message, 'bad'); }
    if (!msgs.length) return toast('لا توجد رسائل', 'bad');
    const hrs = Array(24).fill(0), days = Array(7).fill(0), au = {}; let att = 0, bots = 0;
    msgs.forEach(m => { const d = new Date(m.timestamp); hrs[d.getHours()]++; days[d.getDay()]++; att += (m.attachments || []).length; if (m.author.bot) bots++; const k = m.author.id; au[k] = au[k] || { n: m.author.global_name || m.author.username, c: 0 }; au[k].c++; });
    const top = Object.values(au).sort((a, b) => b.c - a.c).slice(0, 8);
    const span = Math.max(1, Math.abs(new Date(msgs[0].timestamp) - new Date(msgs[msgs.length - 1].timestamp)) / 864e5);
    const dn = ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
    const bh = hrs.indexOf(Math.max(...hrs)), bd = days.indexOf(Math.max(...days));
    const mx = top[0].c;
    openSheet(`<div class="an"><div class="an-k"><div><b>${msgs.length}</b><small>رسالة</small></div><div><b>${Object.keys(au).length}</b><small>مشارك</small></div><div><b>${(msgs.length / span).toFixed(1)}</b><small>رسالة/يوم</small></div><div><b>${att}</b><small>مرفق</small></div></div>
      <h4>النشاط حسب الساعة (توقيتك)</h4>${statBars(hrs, hrs.map((_, i) => String(i)), bh)}<p class="sub">ذروة النشاط: الساعة ${bh}:00</p>
      <h4>النشاط حسب اليوم</h4>${statBars(days, dn, bd)}<p class="sub">أنشط يوم: ${dn[bd]}</p>
      <h4>الأكثر مشاركة</h4>${top.map(t => `<div class="an-r"><span class="uc">${esc(t.n)}</span><i style="width:${Math.round(t.c / mx * 100)}%"></i><b>${t.c}</b></div>`).join('')}
      <p class="sub">رسائل البوتات: ${bots} · المدة المغطاة: ${span.toFixed(1)} يوم</p></div>`, { title: 'تحليلات #' + c.name });
  }
  async function exportChannel(c) {
    const n = await new Promise(res => menuSheet('تصدير سجل القناة', [100, 300, 500, 1000].map(k => ({ icon: '📄', label: 'آخر ' + k + ' رسالة', fn: () => res(k) })), () => res(0)));
    if (!n) return;
    toast('جارِ جلب الرسائل…');
    let msgs; try { msgs = await fetchHistory(c.id, n); } catch (e) { return toast(e.message, 'bad'); }
    const txt = msgs.slice().reverse().map(m => `[${new Date(m.timestamp).toLocaleString('en-GB')}] ${m.author.global_name || m.author.username}: ${m.content || ''}${(m.attachments || []).map(a => ' ' + a.url).join('')}`).join('\n');
    if (window.Native && Native.share) { try { Native.share(txt); return; } catch (e) { /* fall through */ } }
    copyText(txt, 'تم نسخ السجل (' + msgs.length + ' رسالة)');
  }
  async function newChan() {
    const n = await promptDlg({ title: 'قناة جديدة', label: 'الاسم', placeholder: 'general' });
    if (!n || !n.trim()) return;
    const type = await new Promise(res => menuSheet('نوع القناة', [{ icon: '#', label: 'نصية', fn: () => res(0) }, { icon: '🔊', label: 'صوتية', fn: () => res(2) }, { icon: '📢', label: 'إعلانات', fn: () => res(5) }, { icon: '📁', label: 'فئة (Category)', fn: () => res(4) }]));
    await dapi('POST', `/guilds/${B.guild.id}/channels`, { token: B.token, json: { name: n.trim(), type } });
    toast('تم إنشاء القناة', 'ok'); viewChannels();
  }

  /* ---------- members ---------- */
  function viewMembers() {
    page(crumb('الأعضاء') + `<div class="pad"><div class="field"><input id="m-q" type="text" class="ltr" placeholder="ابحث بالاسم أو الـ ID"></div><div id="m-out"><div class="empty">اكتب للبحث عن عضو</div></div></div>`);
    let tm = null, seq = 0;
    $('#m-q').addEventListener('input', e => {
      clearTimeout(tm);
      tm = setTimeout(async () => {
        const v = e.target.value.trim(), my = ++seq, out = $('#m-out');
        if (!out) return;
        if (!v) { out.innerHTML = '<div class="empty">اكتب للبحث عن عضو</div>'; return; }
        out.innerHTML = loadingHTML();
        try {
          const list = isId(v) ? [await lookupMember(B.token, B.guild.id, v)] : await dapi('GET', `/guilds/${B.guild.id}/members/search`, { token: B.token, query: { query: v, limit: 20 } });
          if (my !== seq) return;
          B.found = list;
          out.innerHTML = list.length ? list.map((m, i) => `<button class="list-item" data-act="bot.member" data-i="${i}"><img src="${esc(memberAvatar(B.guild.id, m, 64))}" alt=""><div class="grow"><div class="n"><span class="uc">${esc(displayName(m.user, m))}</span></div><div class="s">@<span class="uc">${esc(m.user.username)}</span> · <span class="uc">${esc(m.user.id)}</span></div></div></button>`).join('') : '<div class="empty">لا نتائج</div>';
        } catch (er) { if (my === seq) out.innerHTML = `<div class="empty">⚠️ ${esc(er.message)}</div>`; }
      }, 350);
    });
  }
  function memberMenu(m) {
    const g = B.guild.id, u = m.user.id, base = `/guilds/${g}/members/${u}`;
    const act = (fn, ok) => async () => { try { await fn(); toast(ok || 'تم', 'ok'); } catch (e) { toast(e.message, 'bad'); } };
    menuSheet(displayName(m.user, m), [
      { icon: '🆔', label: 'نسخ المعرّف', fn: () => copyText(u) },
      { icon: '💬', label: 'إرسال رسالة خاصة', fn: () => dmTo(u) },
      { icon: '✏️', label: 'تغيير اللقب (Nickname)', fn: async () => { const v = await promptDlg({ title: 'اللقب', label: 'اتركه فارغاً للإزالة', value: m.nick || '' }); if (v != null) act(() => dapi('PATCH', base, { token: B.token, json: { nick: v || null } }))(); } },
      { icon: '🛡️', label: 'إضافة / إزالة رتبة', fn: () => rolePicker(m) },
      { icon: '🔇', label: 'كتم مؤقت (Timeout)', fn: () => menuSheet('المدة', [['60 ثانية', 60], ['10 دقائق', 600], ['ساعة', 3600], ['يوم', 86400], ['أسبوع', 604800], ['إلغاء الكتم', 0]].map(([l, s]) => ({ icon: '⏱', label: l, fn: act(() => dapi('PATCH', base, { token: B.token, json: { communication_disabled_until: s ? new Date(Date.now() + s * 1000).toISOString() : null } })) }))) },
      { icon: '👢', label: 'طرد (Kick)', cls: 'red', fn: async () => { if (await confirmDlg('طرد هذا العضو؟', { danger: true, ok: 'طرد' })) act(() => dapi('DELETE', base, { token: B.token }), 'تم الطرد')(); } },
      { icon: '🔨', label: 'حظر (Ban)', cls: 'red', fn: async () => { if (await confirmDlg('حظر هذا العضو؟', { danger: true, ok: 'حظر' })) act(() => dapi('PUT', `/guilds/${g}/bans/${u}`, { token: B.token, json: { delete_message_seconds: 0 } }), 'تم الحظر')(); } }
    ]);
  }
  async function rolePicker(m) {
    const roles = (await dapi('GET', `/guilds/${B.guild.id}/roles`, T())).filter(r => r.name !== '@everyone' && !r.managed).sort((a, b) => b.position - a.position);
    const has = new Set(m.roles || []);
    const s = openSheet(roles.map(r => `<label class="switch"><span style="color:${r.color ? embedColor(r.color) : 'inherit'}"><span class="uc">${esc(r.name)}</span></span><input type="checkbox" data-r="${esc(r.id)}" ${has.has(r.id) ? 'checked' : ''}></label>`).join('') || '<div class="empty">لا توجد رتب</div>', { title: 'الرتب' });
    s.el.querySelectorAll('[data-r]').forEach(i => i.onchange = async () => {
      try { await dapi(i.checked ? 'PUT' : 'DELETE', `/guilds/${B.guild.id}/members/${m.user.id}/roles/${i.dataset.r}`, T()); toast('تم', 'ok'); } catch (e) { i.checked = !i.checked; toast(e.message, 'bad'); }
    });
  }
  async function dmTo(uid2) {
    const v = await promptDlg({ title: 'رسالة خاصة', label: 'النص', multiline: true });
    if (!v || !v.trim()) return;
    const ch = await dapi('POST', '/users/@me/channels', { token: B.token, json: { recipient_id: uid2 } });
    await dapi('POST', `/channels/${ch.id}/messages`, { token: B.token, json: { content: v.trim() } });
    toast('أُرسلت الرسالة', 'ok');
  }

  /* ---------- webhooks / roles / bans / invites / emojis ---------- */
  async function viewHooks() {
    const set = listPage('الويبهوكات');
    try {
      const hs = await dapi('GET', `/guilds/${B.guild.id}/webhooks`, T());
      B.hooks = hs;
      set(hs.map((h, i) => `<div class="card" style="padding:10px"><div class="botcard"><img style="width:44px;height:44px" src="${esc(h.avatar ? `${CDN}/avatars/${h.id}/${h.avatar}.png?size=64` : defaultAvatar(h.id))}" alt=""><div class="grow"><div class="n" style="font-size:14px"><span class="uc">${esc(h.name || '')}</span></div><div class="sub">${h.type === 1 ? 'Incoming' : 'Follower'} · قناة ${esc(h.channel_id)}</div></div></div>
        <div class="row" style="margin-top:8px">${h.token ? `<button class="btn sm sec grow" data-act="bot.hcopy" data-i="${i}">📋 نسخ الرابط</button>` : ''}<button class="btn sm red grow" data-act="bot.hdel" data-i="${i}">🗑 حذف</button></div></div>`).join(''), 'لا توجد ويبهوكات');
    } catch (e) { set(`<div class="empty">⚠️ ${esc(e.message)}</div>`); }
  }
  async function viewRoles() {
    const set = listPage('الرتب');
    try {
      const rs = (await dapi('GET', `/guilds/${B.guild.id}/roles`, T())).sort((a, b) => b.position - a.position);
      B.rolesList = rs; roleCache[B.guild.id] = Promise.resolve(rs);
      set(`<button class="btn sm block" data-act="bot.rolenew" style="margin-bottom:8px">＋ رتبة جديدة</button>` + rs.map((r, i) => `<button class="list-item" data-act="bot.role" data-i="${i}"><span class="ph" style="background:${r.color ? embedColor(r.color) : '#4e5058'}"></span><div class="grow"><div class="n"><span class="uc">${esc(r.name)}</span></div><div class="s"><span class="uc">${esc(r.id)}</span>${r.managed ? ' · بوت' : ''}${r.hoist ? ' · معروضة' : ''}${r.mentionable ? ' · قابلة للمنشن' : ''}</div></div></button>`).join(''));
    } catch (e) { set(`<div class="empty">⚠️ ${esc(e.message)}</div>`); }
  }
  async function viewBans() {
    const set = listPage('المحظورون');
    try {
      const bs = await dapi('GET', `/guilds/${B.guild.id}/bans`, { token: B.token, query: { limit: 100 } });
      B.bansList = bs;
      set(bs.map((b, i) => `<div class="list-item" style="cursor:default"><img src="${esc(userAvatar(b.user))}" alt=""><div class="grow"><div class="n"><span class="uc">${esc(displayName(b.user))}</span></div><div class="s" style="direction:rtl"><span class="uc">${esc(b.reason || 'بدون سبب')}</span></div></div><button class="btn sm sec" data-act="bot.unban" data-i="${i}">فك الحظر</button></div>`).join(''), 'لا يوجد محظورون');
    } catch (e) { set(`<div class="empty">⚠️ ${esc(e.message)}</div>`); }
  }
  async function viewInvites() {
    const set = listPage('الدعوات');
    try {
      const is = await dapi('GET', `/guilds/${B.guild.id}/invites`, T());
      B.invs = is;
      set(is.map((v, i) => `<div class="card" style="padding:10px"><div class="n" style="direction:ltr;text-align:start">discord.gg/${esc(v.code)}</div><div class="sub">#<span class="uc">${esc((v.channel && v.channel.name) || '')}</span> · استخدامات ${v.uses}${v.max_uses ? '/' + v.max_uses : ''}${v.inviter ? ' · ' + esc(v.inviter.username) : ''}</div>
        <div class="row" style="margin-top:8px"><button class="btn sm sec grow" data-act="bot.icopy" data-i="${i}">📋 نسخ</button><button class="btn sm red grow" data-act="bot.idel" data-i="${i}">🗑 حذف</button></div></div>`).join(''), 'لا توجد دعوات');
    } catch (e) { set(`<div class="empty">⚠️ ${esc(e.message)}</div>`); }
  }
  async function viewEmojis() {
    const set = listPage('الإيموجي');
    const draw = async () => {
      try {
        const es = B.emojis = await dapi('GET', `/guilds/${B.guild.id}/emojis`, T());
        set(`<button class="btn block" data-act="bot.eadd" style="margin-bottom:12px">${Icons.svg('plus')} إضافة إيموجي</button>` + (es.length ? '<div class="row wrap">' + es.map(e => `<button class="list-item" style="width:auto;flex-direction:column;gap:4px" data-act="bot.emenu" data-id="${esc(e.id)}"><img style="border-radius:8px;width:48px;height:48px;object-fit:contain" src="${CDN}/emojis/${e.id}.${e.animated ? 'gif' : 'webp'}?size=64" alt=""><div class="s">:<span class="uc">${esc(e.name)}</span>:</div></button>`).join('') + '</div>' : '<div class="empty">لا توجد إيموجيات</div>'));
      } catch (e) { set(`<div class="empty">⚠️ ${esc(e.message)}</div>`); }
    };
    B.redrawEmojis = draw; draw();
  }
  async function addEmoji() {
    try {
      const fs = await Media.pick({ max: 1 }); const f = fs[0]; if (!f) return;
      if (!/^image\/(png|jpe?g|gif|webp)$/.test(f.type)) return toast('اختر صورة PNG/JPG/GIF', 'bad');
      if (f.size > 256 * 1024) return toast('الحد الأقصى 256KB — صغّر الصورة', 'bad');
      const base = (f.name || 'emoji').replace(/\.[^.]+$/, '').replace(/[^\w]/g, '_').slice(0, 30);
      const name = await promptDlg({ title: 'اسم الإيموجي', label: 'حروف وأرقام و _ (2–32)', value: base.length >= 2 ? base : 'emoji' });
      if (!name) return;
      const image = `data:${f.type};base64,${await fileToB64(f)}`;
      await dapi('POST', `/guilds/${B.guild.id}/emojis`, { ...T(), json: { name: name.replace(/[^\w]/g, '_').slice(0, 32), image } });
      delete guildEmojiCache[B.guild.id]; toast('تمت الإضافة', 'ok'); B.redrawEmojis && B.redrawEmojis();
    } catch (e) { toast(e.message || String(e), 'bad'); }
  }
  function emojiMenu(id) {
    const e = (B.emojis || []).find(x => x.id === id); if (!e) return;
    menuSheet(':' + e.name + ':', [
      { icon: '📋', label: 'نسخ الكود', fn: () => copyText(`<${e.animated ? 'a' : ''}:${e.name}:${e.id}>`) },
      { icon: '✏️', label: 'تغيير الاسم', fn: async () => { const n = await promptDlg({ title: 'الاسم الجديد', value: e.name }); if (!n) return; try { await dapi('PATCH', `/guilds/${B.guild.id}/emojis/${e.id}`, { ...T(), json: { name: n.replace(/[^\w]/g, '_').slice(0, 32) } }); delete guildEmojiCache[B.guild.id]; toast('تم', 'ok'); B.redrawEmojis(); } catch (er) { toast(er.message, 'bad'); } } },
      { icon: '🗑️', label: 'حذف', cls: 'red', fn: async () => { if (!await confirmDlg('حذف هذا الإيموجي؟', { danger: true, ok: 'حذف' })) return; try { await dapi('DELETE', `/guilds/${B.guild.id}/emojis/${e.id}`, T()); delete guildEmojiCache[B.guild.id]; toast('تم الحذف', 'ok'); B.redrawEmojis(); } catch (er) { toast(er.message, 'bad'); } } }
    ]);
  }

  /* ---------- profile / invite builder ---------- */
  function editProfile() {
    const b = B.bot;
    const s = openSheet(`<div class="field"><label>اسم البوت</label><input id="p-n" type="text" value="${esc(b.username)}"></div>
      <div class="field"><label>رابط صورة جديدة (اختياري)</label><input id="p-a" class="ltr" type="text" placeholder="https://… (png/jpg/gif)"></div>
      <button class="btn block" id="p-ok">حفظ</button><p class="sub" style="margin-top:10px">يمكن تغيير الاسم مرتين فقط كل ساعة حسب قيود Discord.</p>`, { title: 'تعديل البوت' });
    $('#p-ok', s.el).onclick = e => withBusy(e.currentTarget, async () => {
      const json = { username: $('#p-n', s.el).value.trim() };
      const a = $('#p-a', s.el).value.trim();
      if (a) { if (!safeUrl(a)) throw new Error('رابط الصورة غير صالح'); json.avatar = await fetchImageDataUri(a); }
      B.bot = await dapi('PATCH', '/users/@me', { token: B.token, json });
      s.close(); viewHome(); toast('تم تحديث البوت', 'ok');
    }).catch(er => toast(er.message, 'bad'));
  }
  function inviteBuilder() {
    const s = openSheet(`<div class="note info">Client ID: <b><span class="uc">${esc(B.bot.id)}</span></b></div>${PERMS.map(([n, v]) => `<label class="switch"><span>${n}</span><input type="checkbox" data-v="${v}"></label>`).join('')}
      <button class="btn block" id="iv-ok" style="margin-top:8px">إنشاء الرابط ونسخه</button>`, { title: 'رابط دعوة البوت' });
    $('#iv-ok', s.el).onclick = () => {
      const n = $$('[data-v]:checked', s.el).reduce((a, i) => a + BigInt(i.dataset.v), 0n);
      copyText(`https://discord.com/oauth2/authorize?client_id=${B.bot.id}&permissions=${n}&scope=bot%20applications.commands`, 'تم نسخ رابط الدعوة'); s.close();
    };
  }


  /* ---------- presence (Gateway) ---------- */
  const PRES = () => Object.assign({ status: 'online', type: 0, text: '', url: '' }, store.get('presence', {}));
  function presencePayload() {
    const p = PRES(), act = [];
    if (p.text) act.push(p.type === 4 ? { name: 'Custom Status', type: 4, state: p.text } : Object.assign({ name: p.text, type: p.type }, p.type === 1 && safeUrl(p.url) ? { url: p.url } : {}));
    return { since: null, activities: act, status: p.status, afk: false };
  }
  let gwState = 'offline';
  const gwDot = () => ({ online: '🟢', connecting: '🟡', reconnecting: '🟡' }[gwState] || '⚫');
  function viewPresence() {
    const p = PRES();
    const types = [[0, 'يلعب'], [1, 'يبث'], [2, 'يستمع إلى'], [3, 'يشاهد'], [5, 'يتنافس في'], [4, 'حالة مخصصة']];
    page(crumb('الحالة والنشاط') + `<div class="pad"><div class="note info">الحالة تبقى «متصلة» طالما التطبيق مفتوح ومتصل بالإنترنت. عند الإغلاق يعود البوت أوفلاين.</div>
      <div class="card"><div class="lbl">الحالة</div><div class="seg" id="pr-st" style="margin-bottom:12px">${[['online', '🟢 متصل'], ['idle', '🌙 خامل'], ['dnd', '⛔ مشغول'], ['invisible', '⚫ مخفي']].map(([k, l]) => `<button data-s="${k}" class="${p.status === k ? 'on' : ''}">${l}</button>`).join('')}</div>
      <div class="field"><label>نوع النشاط</label><select id="pr-t">${types.map(([k, l]) => `<option value="${k}" ${p.type === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
      <div class="field"><label>النص</label><input id="pr-x" type="text" dir="auto" value="${esc(p.text)}" placeholder="مثال: Discord Tools"></div>
      <div class="field" id="pr-u-w" style="${p.type === 1 ? '' : 'display:none'}"><label>رابط البث (Twitch/YouTube)</label><input id="pr-u" class="ltr" type="text" value="${esc(p.url)}" placeholder="https://twitch.tv/…"></div>
      <div class="row"><button class="btn green grow" data-act="bot.gwon">⚡ اتصال وتطبيق</button><button class="btn sec grow" data-act="bot.gwoff">قطع الاتصال</button></div>
      <div class="sub" style="margin-top:10px">الحالة الآن: <b id="pr-state"><span class="uc">${esc(gwState)}</span></b></div></div></div>`);
    let st = p.status;
    $$('#pr-st button').forEach(b => b.onclick = () => { st = b.dataset.s; $$('#pr-st button').forEach(x => x.classList.toggle('on', x === b)); });
    $('#pr-t').onchange = e => { $('#pr-u-w').style.display = e.target.value === '1' ? '' : 'none'; };
    viewPresence.read = () => ({ status: st, type: +$('#pr-t').value, text: $('#pr-x').value.trim(), url: $('#pr-u').value.trim() });
  }
  function gwSet(st) { gwState = st; const e = $('#pr-state'); if (e) e.textContent = st; }
  function gwOn() {
    const v = viewPresence.read(); if (v.type === 1 && !safeUrl(v.url)) throw new Error('البث يحتاج رابطاً صالحاً');
    store.set('presence', v);
    if (B.gw) B.gw.close();
    B.gw = new Gateway(B.token, presencePayload, gwSet); B.gw.connect();
    toast('جارٍ الاتصال…', 'ok');
  }
  function gwOff() { if (B.gw) { B.gw.close(); B.gw = null; } toast('تم قطع الاتصال'); }

  /* ---------- slash commands ---------- */
  async function viewCmds() {
    const set = listPage('أوامر Slash');
    try {
      const cs = await dapi('GET', `/applications/${B.bot.id}/commands`, T()); B.cmds = cs;
      set(`<button class="btn sm block" data-act="bot.cmdnew" style="margin-bottom:8px">＋ أمر جديد</button>` + cs.map((c, i) => `<div class="list-item" style="cursor:default"><span class="ph">/</span><div class="grow"><div class="n" style="direction:ltr;text-align:start">/${esc(c.name)}</div><div class="s" style="direction:rtl"><span class="uc">${esc(c.description || '')}</span></div></div><button class="btn sm sec" data-act="bot.cmdedit" data-i="${i}">تعديل</button><button class="btn sm red" data-act="bot.cmddel" data-i="${i}">حذف</button></div>`).join(''), 'لا توجد أوامر عامة');
    } catch (e) { set(`<div class="empty">⚠️ ${esc(e.message)}</div>`); }
  }
  function cmdNew() {
    const s = openSheet(`<div class="field"><label>اسم الأمر</label><input id="c-n" class="ltr" type="text" placeholder="ping" maxlength="32"></div><div class="field"><label>الوصف</label><input id="c-d" type="text" maxlength="100" placeholder="Replies with pong"></div><button class="btn block" id="c-ok">تسجيل الأمر</button><p class="sub" style="margin-top:8px">لتفعيل ردود الأمر يلزم برنامج بوت يستقبل التفاعلات. للأوامر المعقدة استخدم أداة «منشئ Slash Command».</p>`, { title: 'أمر جديد' });
    $('#c-ok', s.el).onclick = e => withBusy(e.currentTarget, async () => {
      const n = $('#c-n', s.el).value.trim().toLowerCase(); if (!/^[\w-]{1,32}$/.test(n)) throw new Error('اسم غير صالح');
      await dapi('POST', `/applications/${B.bot.id}/commands`, { token: B.token, json: { name: n, description: $('#c-d', s.el).value.trim() || '-', type: 1 } });
      s.close(); toast('تم تسجيل الأمر', 'ok'); viewCmds();
    }).catch(er => toast(er.message, 'bad'));
  }

  /* ---------- audit / threads / automod / stickers / members ---------- */
  const AUDIT = { 1: 'تعديل السيرفر', 10: 'إنشاء قناة', 11: 'تعديل قناة', 12: 'حذف قناة', 20: 'طرد عضو', 21: 'تنظيف أعضاء', 22: 'حظر عضو', 23: 'فك حظر', 24: 'تعديل عضو', 25: 'تعديل رتب عضو', 28: 'إضافة بوت', 30: 'إنشاء رتبة', 31: 'تعديل رتبة', 32: 'حذف رتبة', 40: 'إنشاء دعوة', 42: 'حذف دعوة', 50: 'إنشاء ويبهوك', 51: 'تعديل ويبهوك', 52: 'حذف ويبهوك', 60: 'إنشاء إيموجي', 62: 'حذف إيموجي', 72: 'حذف رسالة', 73: 'حذف جماعي', 74: 'تثبيت رسالة', 75: 'إلغاء تثبيت', 140: 'AutoMod', 143: 'AutoMod منع' };
  const AUDIT_GROUPS = [['all', 'الكل', () => true], ['mem', 'الأعضاء', t => t >= 20 && t <= 28], ['chan', 'القنوات', t => t >= 10 && t <= 15], ['role', 'الرتب', t => t >= 30 && t <= 32], ['msg', 'الرسائل', t => t >= 72 && t <= 75], ['inv', 'الدعوات', t => t >= 40 && t <= 42], ['hook', 'الويبهوكات', t => t >= 50 && t <= 52]];
  async function viewAudit() {
    const set = listPage('سجل التدقيق');
    try {
      const a = await dapi('GET', `/guilds/${B.guild.id}/audit-logs`, { token: B.token, query: { limit: 100 } });
      const us = {}; (a.users || []).forEach(u => { us[u.id] = u; });
      const ents = a.audit_log_entries || []; let grp = 'all', who = '';
      const draw = () => {
        const g = AUDIT_GROUPS.find(x => x[0] === grp), list = ents.filter(e => g[2](e.action_type) && (!who || e.user_id === who));
        const authors = Array.from(new Set(ents.map(e => e.user_id))).slice(0, 8);
        set(`<nav class="chips" style="margin-bottom:6px">${AUDIT_GROUPS.map(x => `<button class="chip ${x[0] === grp ? 'on' : ''}" data-ag="${x[0]}">${x[1]}</button>`).join('')}</nav>
          <nav class="chips" style="margin-bottom:10px"><button class="chip ${!who ? 'on' : ''}" data-au="">كل المنفّذين</button>${authors.map(id => `<button class="chip ${who === id ? 'on' : ''}" data-au="${esc(id)}"><span class="uc">${esc(us[id] ? displayName(us[id]) : id)}</span></button>`).join('')}</nav>
          <div class="sub" style="margin:0 2px 8px">${list.length} إجراء</div>` + (list.length ? list.map(e => { const u = us[e.user_id]; return `<div class="list-item" style="cursor:default"><img src="${esc(userAvatar(u, 64))}" alt=""><div class="grow"><div class="n"><span>${esc(AUDIT[e.action_type] || 'إجراء ' + e.action_type)}</span></div><div class="s" style="direction:rtl"><span class="uc">${esc(u ? displayName(u) : e.user_id)}</span> · ${new Date(snowflakeMs(e.id)).toLocaleString(LOC)}${e.target_id ? ' · الهدف ' + esc(e.target_id) : ''}${e.reason ? '<br>السبب: ' + esc(e.reason) : ''}</div></div></div>`; }).join('') : '<div class="empty">لا توجد إجراءات مطابقة</div>'));
      };
      draw();
      const lp = $('#lp'); lp.onclick = ev => { const g = ev.target.closest('[data-ag]'), w = ev.target.closest('[data-au]'); if (g) { grp = g.dataset.ag; draw(); } else if (w) { who = w.dataset.au; draw(); } };
    } catch (e) { set(`<div class="empty">⚠️ ${esc(e.message)}<br>يحتاج البوت صلاحية View Audit Log</div>`); }
  }
  async function viewThreads() {
    const set = listPage('الثريدات النشطة');
    try {
      const r = await dapi('GET', `/guilds/${B.guild.id}/threads/active`, T());
      B.chans = (B.chans || []).filter(c => ![10, 11, 12].includes(c.type)).concat(r.threads || []);
      set((r.threads || []).map(t => `<button class="chan" data-act="bot.chan" data-c="${esc(t.id)}"><span class="h">🧵</span><span class="uc">${esc(t.name)}</span></button>`).join(''), 'لا توجد ثريدات نشطة');
    } catch (e) { set(`<div class="empty">⚠️ ${esc(e.message)}</div>`); }
  }
  async function viewAutomod() {
    const set = listPage('قواعد AutoMod');
    try {
      const rs = await dapi('GET', `/guilds/${B.guild.id}/auto-moderation/rules`, T()); B.rules = rs;
      set(rs.map((r, i) => `<div class="list-item" style="cursor:default"><span class="ph">🤖</span><div class="grow"><div class="n"><span class="uc">${esc(r.name)}</span></div><div class="s" style="direction:rtl">${r.enabled ? '🟢 مفعّلة' : '⚫ متوقفة'}</div></div><button class="btn sm sec" data-act="bot.rtog" data-i="${i}">${r.enabled ? 'إيقاف' : 'تفعيل'}</button><button class="btn sm red" data-act="bot.rdel" data-i="${i}">🗑</button></div>`).join(''), 'لا توجد قواعد');
    } catch (e) { set(`<div class="empty">⚠️ ${esc(e.message)}<br>يحتاج صلاحية Manage Server</div>`); }
  }
  async function viewStickers() {
    const set = listPage('الستيكرز');
    try {
      const ss = await dapi('GET', `/guilds/${B.guild.id}/stickers`, T());
      set(ss.map(x => `<div class="list-item" style="cursor:default"><img style="border-radius:8px" src="https://media.discordapp.net/stickers/${esc(x.id)}.png?size=96" alt=""><div class="grow"><div class="n"><span class="uc">${esc(x.name)}</span></div><div class="s"><span class="uc">${esc(x.description || x.id)}</span></div></div></div>`).join(''), 'لا توجد ستيكرز');
    } catch (e) { set(`<div class="empty">⚠️ ${esc(e.message)}</div>`); }
  }
  async function viewMemList() {
    const set = listPage('قائمة الأعضاء');
    try {
      const ms = await dapi('GET', `/guilds/${B.guild.id}/members`, { token: B.token, query: { limit: 100 } }); B.found = ms;
      set(ms.map((m, i) => `<button class="list-item" data-act="bot.member" data-i="${i}"><img src="${esc(memberAvatar(B.guild.id, m, 64))}" alt=""><div class="grow"><div class="n"><span class="uc">${esc(displayName(m.user, m))}</span>${m.user.bot ? ' <span class="tag" style="background:var(--brand);color:#fff;font-size:10px;border-radius:4px;padding:1px 5px">APP</span>' : ''}</div><div class="s">@<span class="uc">${esc(m.user.username)}</span></div></div></button>`).join(''));
    } catch (e) { set(`<div class="empty">⚠️ ${esc(e.message)}<br>يحتاج تفعيل «Server Members Intent» من Developer Portal</div>`); }
  }
  async function roleMenu(r) {
    const base = `/guilds/${B.guild.id}/roles/${r.id}`;
    const patch = async json => { await dapi('PATCH', base, { token: B.token, json }); toast('تم', 'ok'); viewRoles(); };
    menuSheet(r.name, [
      { icon: '✏️', label: 'تغيير الاسم', fn: async () => { const v = await promptDlg({ title: 'اسم الرتبة', label: 'الاسم', value: r.name }); if (v && v.trim()) patch({ name: v.trim() }); } },
      { icon: '🎨', label: 'تغيير اللون', fn: async () => { const c = await colorPicker(r.color ? embedColor(r.color) : '#5865f2'); if (c) patch({ color: parseInt(c.slice(1), 16) }); } },
      { icon: '📌', label: r.hoist ? 'إلغاء عرضها منفصلة' : 'عرضها منفصلة', fn: () => patch({ hoist: !r.hoist }) },
      { icon: '@', label: r.mentionable ? 'منع منشنها' : 'السماح بمنشنها', fn: () => patch({ mentionable: !r.mentionable }) },
      { icon: '📋', label: 'نسخ المعرّف', fn: () => copyText(r.id) },
      !r.managed && { icon: '🗑️', label: 'حذف الرتبة', cls: 'red', fn: async () => { if (await confirmDlg(`حذف الرتبة «${r.name}»؟`, { danger: true, ok: 'حذف' })) { await dapi('DELETE', base, T()); toast('تم الحذف', 'ok'); viewRoles(); } } }
    ]);
  }
  async function roleNew() {
    const n = await promptDlg({ title: 'رتبة جديدة', label: 'الاسم' }); if (!n || !n.trim()) return;
    const c = await colorPicker('#5865f2');
    await dapi('POST', `/guilds/${B.guild.id}/roles`, { token: B.token, json: Object.assign({ name: n.trim() }, c ? { color: parseInt(c.slice(1), 16) } : {}) });
    toast('تم إنشاء الرتبة', 'ok'); viewRoles();
  }

  registerActions({
    'bot.presence': () => go(viewPresence), 'bot.gwon': gwOn, 'bot.gwoff': gwOff,
    'bot.cmds': () => go(viewCmds), 'bot.cmdnew': cmdNew,
    'bot.cmdedit': async t => { const c = B.cmds[+t.dataset.i]; const d = await promptDlg({ title: '/' + c.name, label: 'الوصف الجديد', value: c.description || '' }); if (d == null) return; try { await dapi('PATCH', `/applications/${B.bot.id}/commands/${c.id}`, { token: B.token, json: { description: d.trim() || '-' } }); toast('تم التعديل', 'ok'); viewCmds(); } catch (e) { toast(e.message, 'bad'); } },
    'bot.cmddel': async t => { const c = B.cmds[+t.dataset.i]; if (await confirmDlg(`حذف الأمر /${c.name}؟`, { danger: true, ok: 'حذف' })) { await dapi('DELETE', `/applications/${B.bot.id}/commands/${c.id}`, T()); toast('تم الحذف', 'ok'); viewCmds(); } },
    'bot.audit': () => go(viewAudit), 'bot.threads': () => go(viewThreads), 'bot.automod': () => go(viewAutomod), 'bot.stickers': () => go(viewStickers), 'bot.memlist': () => go(viewMemList),
    'bot.rtog': async t => { const r = B.rules[+t.dataset.i]; await dapi('PATCH', `/guilds/${B.guild.id}/auto-moderation/rules/${r.id}`, { token: B.token, json: { enabled: !r.enabled } }); viewAutomod(); },
    'bot.rdel': async t => { const r = B.rules[+t.dataset.i]; if (await confirmDlg(`حذف القاعدة «${r.name}»؟`, { danger: true, ok: 'حذف' })) { await dapi('DELETE', `/guilds/${B.guild.id}/auto-moderation/rules/${r.id}`, T()); viewAutomod(); } },
    'bot.role': t => roleMenu(B.rolesList[+t.dataset.i]), 'bot.rolenew': roleNew,
    'bot.banid': async () => { const v = await promptDlg({ title: 'حظر بالـ ID', label: 'User ID' }); if (!v || !isId(v)) return; if (await confirmDlg('حظر هذا المستخدم حتى لو لم يكن في السيرفر؟', { danger: true, ok: 'حظر' })) { await dapi('PUT', `/guilds/${B.guild.id}/bans/${v.trim()}`, { token: B.token, json: { delete_message_seconds: 0 } }); toast('تم الحظر', 'ok'); } },
    'bot.grename': async () => { const v = await promptDlg({ title: 'اسم السيرفر', label: 'الاسم', value: B.guild.name }); if (v && v.trim()) { const g = await dapi('PATCH', `/guilds/${B.guild.id}`, { token: B.token, json: { name: v.trim() } }); B.guild.name = g.name; toast('تم تغيير الاسم', 'ok'); viewGuild(); } },
    'bot.back': () => back(), 'bot.eye': () => { const i = $('#b-tok'); i.type = i.type === 'password' ? 'text' : 'password'; },
    'bot.login': t => doLogin(t),
    'bot.guilds': () => go(viewGuilds), 'bot.guild': t => openGuild(t.dataset.g),
    'bot.edit': editProfile, 'bot.invite': inviteBuilder,
    'bot.dm': async () => { const v = await promptDlg({ title: 'مراسلة مستخدم', label: 'User ID' }); if (v && isId(v)) dmTo(v.trim()); },
    'bot.logout': async () => { if (await confirmDlg('تسجيل الخروج وحذف التوكن المحفوظ؟', { ok: 'خروج' })) { Tokens.clear(); B.token = ''; B.bot = null; setBase(viewLogin); } },
    'bot.channels': () => go(viewChannels), 'bot.chan': t => openChat(t.dataset.c), 'bot.chmenu': t => chMenu(t.dataset.c), 'bot.newchan': newChan,
    'bot.members': () => go(viewMembers), 'bot.member': t => memberMenu(B.found[+t.dataset.i]),
    'bot.hooks': () => go(viewHooks), 'bot.roles': () => go(viewRoles), 'bot.bans': () => go(viewBans), 'bot.invites': () => go(viewInvites), 'bot.emojis': () => go(viewEmojis),
    'bot.hcopy': t => { const h = B.hooks[+t.dataset.i]; copyText(`https://discord.com/api/webhooks/${h.id}/${h.token}`, 'تم نسخ رابط الويبهوك'); },
    'bot.hdel': async t => { const h = B.hooks[+t.dataset.i]; if (await confirmDlg(`حذف الويبهوك «${h.name}»؟`, { danger: true, ok: 'حذف' })) { await dapi('DELETE', `/webhooks/${h.id}`, T()); toast('تم الحذف', 'ok'); viewHooks(); } },
    'bot.unban': async t => { const b = B.bansList[+t.dataset.i]; await dapi('DELETE', `/guilds/${B.guild.id}/bans/${b.user.id}`, T()); toast('تم فك الحظر', 'ok'); viewBans(); },
    'bot.icopy': t => copyText('https://discord.gg/' + B.invs[+t.dataset.i].code),
    'bot.idel': async t => { await dapi('DELETE', `/invites/${B.invs[+t.dataset.i].code}`, T()); toast('تم الحذف', 'ok'); viewInvites(); },
    'bot.ecopy': t => copyText(t.dataset.t), 'bot.eadd': addEmoji, 'bot.emenu': t => emojiMenu(t.dataset.id),
    'bot.leave': async () => { if (await confirmDlg(`مغادرة سيرفر «${B.guild.name}»؟`, { danger: true, ok: 'مغادرة' })) { await dapi('DELETE', `/users/@me/guilds/${B.guild.id}`, T()); B.guilds = B.guilds.filter(g => g.id !== B.guild.id); toast('غادر البوت السيرفر', 'ok'); B.stack = [viewHome, viewGuilds]; viewGuilds(); } }
  });
  return { mount, back, get active() { return !!B.token; }, _t: { analyzeChannel, exportChannel, B } };
})();

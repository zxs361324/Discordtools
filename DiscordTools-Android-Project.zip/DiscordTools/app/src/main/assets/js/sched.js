'use strict';
/* ============================================================
   sched.js — scheduled messages (sent while the app is open)
   ============================================================ */
const Sched = (() => {
  const KEY = 'sched';
  let timer = null, asked = false, busy = false;
  const all = () => store.get(KEY, []);
  const save = l => store.set(KEY, l);
  const count = () => all().length;
  const nativeSvc = () => { try { return !!(NATIVE && NATIVE.serviceOn && NATIVE.serviceOn()); } catch (e) { return false; } };
  function add(item) { if (item.dest && item.dest.mode !== 'webhook' && !item.dest.botToken) item.dest = Object.assign({}, item.dest, { botToken: Tokens.get() });
    return add0(item); }
  function add0(item) { const l = all(); l.push(Object.assign({ id: uid(), err: '' }, item)); l.sort((a, b) => a.at - b.at); save(l); }
  function remove(id) { save(all().filter(x => x.id !== id)); }
  async function post(it) {
    const d = it.dest;
    if (d.mode === 'webhook') return dapi('POST', `/webhooks/${d.id}/${d.token}`, { json: it.payload, query: Object.assign({ wait: 'true' }, it.query || {}) });
    return dapi('POST', `/channels/${d.channelId}/messages`, { token: d.botToken || Tokens.get(), json: it.payload });
  }
  async function sendNow(id) {
    const it = all().find(x => x.id === id); if (!it) return false;
    try { await post(it); remove(id); toast('أُرسلت رسالة مجدولة', 'ok'); return true; }
    catch (e) { const l = all(); const x = l.find(y => y.id === id); if (x) { x.err = e.message; save(l); } toast('فشلت الرسالة المجدولة: ' + e.message, 'bad'); return false; }
  }
  async function tick() {
    if (busy || nativeSvc()) return; busy = true;
    try {
      const now = Date.now(); const due = all().filter(x => x.at <= now && !x.err);
      if (!due.length) return;
      const late = due.filter(x => now - x.at > 120000);
      if (late.length && !asked) {
        asked = true;
        if (!await confirmDlg(`فاتك موعد ${late.length} رسالة مجدولة (كان التطبيق مغلقاً). إرسالها الآن؟`, { ok: 'إرسال الآن', cancel: 'لاحقاً' })) { late.forEach(x => { x.err = 'فات موعدها'; }); const l = all(); l.forEach(x => { if (late.find(y => y.id === x.id)) x.err = 'فات موعدها'; }); save(l); return; }
      }
      for (const it of due) await sendNow(it.id);
    } finally { busy = false; }
  }
  function start() { if (timer) return; setTimeout(tick, 1500); timer = setInterval(tick, 15000); }
  function sheet(onChange) {
    const draw = () => {
      const l = all();
      return `<p class="sub" style="margin:0 0 8px">${nativeSvc() ? 'تُرسل في موعدها حتى والتطبيق مغلق (الخدمة الخلفية مفعّلة).' : 'تُرسل في موعدها <b>والتطبيق مفتوح</b> فقط — فعّل «الخدمة الخلفية» من الإعدادات لتعمل والتطبيق مغلق.'}</p>` + (l.length ? l.map(x => `<div class="sch ${x.err ? 'bad' : ''}"><div class="sch-t">${esc(DatePick.fmt(DatePick.toVal(new Date(x.at))))}</div><div class="sch-s"><span class="uc">${esc(x.label || '')}</span></div>${x.err ? `<div class="sch-e">${esc(x.err)}</div>` : ''}<div class="sch-b"><button class="btn sm" data-now="${esc(x.id)}">إرسال الآن</button><button class="btn sm red" data-del="${esc(x.id)}">حذف</button></div></div>`).join('') : '<div class="empty">لا توجد رسائل مجدولة</div>');
    };
    const s = openSheet(`<div id="sch-l">${draw()}</div>`, { title: 'الرسائل المجدولة' });
    s.el.addEventListener('click', async e => {
      const n = e.target.closest('[data-now]'), d = e.target.closest('[data-del]');
      if (n) { await sendNow(n.dataset.now); } else if (d) { remove(d.dataset.del); } else return;
      $('#sch-l', s.el).innerHTML = draw(); if (onChange) onChange();
    });
  }
  return { nativeSvc, add, remove, all, count, start, sheet, tick };
})();

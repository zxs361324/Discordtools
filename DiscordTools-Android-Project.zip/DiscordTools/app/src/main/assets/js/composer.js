'use strict';
/* ============================================================
   composer.js — WYSIWYG Discord message / embed sender.
   The card looks like a real Discord message; every part is
   editable in place (tap and type).
   ============================================================ */
const Composer = (() => {
  let root = null;
  const SW = ['#5865f2', '#57f287', '#fee75c', '#ed4245', '#eb459e', '#faa61a', '#ffffff', '#1e1f22'];
  const newEmbed = () => ({ color: '#5865f2', title: '', url: '', description: '', author: null, thumb: null, image: null, footer: null, timestamp: false, fields: [] });
  const D = {
    dest: { mode: 'webhook', url: '', id: '', token: '', channelId: '', botToken: '', info: null },
    username: '', avatar: '', tts: false, content: '', embeds: [], rows: [], files: [],
    opt: { mentions: 'safe', suppressEmbeds: false, silent: false, threadId: '', threadName: '' },
    editing: null, preview: false
  };
  let hist = [];

  /* ---------- persistence ---------- */
  function snapshot() {
    const s = JSON.parse(JSON.stringify({ username: D.username, avatar: D.avatar, tts: D.tts, content: D.content, embeds: D.embeds, rows: D.rows, opt: D.opt }));
    return s;
  }
  let saveT = null;
  function persist() {
    clearTimeout(saveT);
    saveT = setTimeout(() => {
      store.set('draft', snapshot());
      const d = Object.assign({}, D.dest);
      if (!settings.all.remember) d.botToken = '';
      store.set('dest', d);
    }, 400);
  }
  function applySnapshot(s) {
    D.username = s.username || ''; D.avatar = s.avatar || ''; D.tts = !!s.tts; D.content = s.content || '';
    D.embeds = (s.embeds || []).map(e => Object.assign(newEmbed(), e));
    D.rows = s.rows || [];
    D.opt = Object.assign({ mentions: 'safe', suppressEmbeds: false, silent: false, threadId: '', threadName: '' }, s.opt || {});
  }

  /* ---------- Discord payload <-> editor model ---------- */
  function toEmbed(e) {
    const o = {};
    if (e.title) o.title = e.title;
    if (safeUrl(e.url)) o.url = e.url.trim();
    if (e.description) o.description = e.description;
    if (/^#[0-9a-f]{6}$/i.test(e.color)) o.color = parseInt(e.color.slice(1), 16);
    if (e.author && e.author.name) { o.author = { name: e.author.name }; if (safeUrl(e.author.url)) o.author.url = e.author.url.trim(); if (e.author.icon_url) o.author.icon_url = e.author.icon_url.trim(); }
    if (e.footer && e.footer.text) { o.footer = { text: e.footer.text }; if (e.footer.icon_url) o.footer.icon_url = e.footer.icon_url.trim(); }
    if (e.thumb) o.thumbnail = { url: e.thumb.trim() };
    if (e.image) o.image = { url: e.image.trim() };
    if (e.timestamp) o.timestamp = new Date().toISOString();
    const f = (e.fields || []).filter(x => x.name && x.value).map(x => ({ name: x.name, value: x.value, inline: !!x.inline }));
    if (f.length) o.fields = f;
    return o;
  }
  const embedNonEmpty = o => o.title || o.description || o.fields || o.author || o.footer || o.image || o.thumbnail;
  function fromEmbed(o) {
    const e = newEmbed();
    e.title = o.title || ''; e.url = o.url || ''; e.description = o.description || '';
    e.color = o.color != null ? embedColor(o.color) : '#5865f2';
    if (o.author) e.author = { name: o.author.name || '', url: o.author.url || '', icon_url: o.author.icon_url || '' };
    if (o.footer) e.footer = { text: o.footer.text || '', icon_url: o.footer.icon_url || '' };
    if (o.thumbnail) e.thumb = o.thumbnail.url || '';
    if (o.image) e.image = o.image.url || '';
    e.timestamp = !!o.timestamp;
    e.fields = (o.fields || []).map(f => ({ name: f.name || '', value: f.value || '', inline: !!f.inline }));
    return e;
  }
  function buildPayload(forEdit) {
    const p = {};
    const web = D.dest.mode === 'webhook';
    if (D.content || forEdit) p.content = D.content;
    if (web && !forEdit) {
      if (D.username.trim()) p.username = D.username.trim();
      if (safeUrl(D.avatar)) p.avatar_url = D.avatar.trim();
      if (D.opt.threadName.trim()) p.thread_name = D.opt.threadName.trim();
    }
    if (D.tts && !forEdit) p.tts = true;
    const em = D.embeds.map(toEmbed).filter(embedNonEmpty);
    if (em.length || forEdit) p.embeds = em;
    const comps = D.rows.filter(r => r.length).map(r => ({
      type: 1, components: r.map(b => {
        const c = { type: 2, style: 5, label: b.label, url: (b.url || '').trim() };
        if (b.emoji) c.emoji = { name: b.emoji };
        return c;
      })
    }));
    if (comps.length || forEdit) p.components = comps;
    if (D.opt.mentions === 'safe' && !settings.all.allowEveryone) p.allowed_mentions = { parse: ['users'] };
    if (D.opt.mentions === 'none') p.allowed_mentions = { parse: [] };
    let flags = 0;
    if (D.opt.suppressEmbeds) flags |= 4;
    if (D.opt.silent && !forEdit) flags |= 4096;
    if (flags) p.flags = flags;
    return p;
  }
  function loadPayload(p) {
    if (p && p.messages && p.messages[0] && p.messages[0].data) p = p.messages[0].data;
    if (!p || typeof p !== 'object') throw new Error('JSON غير صالح');
    D.content = p.content || '';
    if (p.username != null) D.username = p.username;
    if (p.avatar_url != null) D.avatar = p.avatar_url;
    D.tts = !!p.tts;
    D.embeds = (p.embeds || []).slice(0, 10).map(fromEmbed);
    D.rows = [];
    (p.components || []).forEach(r => {
      const row = (r.components || []).filter(c => c.type === 2 && c.url).map(c => ({ label: c.label || '', url: c.url, emoji: c.emoji && c.emoji.name || '' }));
      if (row.length) D.rows.push(row);
    });
    if (p.flags) { D.opt.suppressEmbeds = !!(p.flags & 4); D.opt.silent = !!(p.flags & 4096); }
  }
  function validate(p) {
    if (!p.content && !(p.embeds && p.embeds.length) && !D.files.length && !(p.components && p.components.length)) throw new Error('الرسالة فارغة — اكتب نصاً أو أضف Embed أو ملفاً');
    if ((p.content || '').length > 2000) throw new Error('النص أطول من 2000 حرف');
    let tot = 0;
    (p.embeds || []).forEach((e, i) => {
      const n = (e.title || '').length + (e.description || '').length + (e.footer ? e.footer.text.length : 0) + (e.author ? e.author.name.length : 0) + (e.fields || []).reduce((a, f) => a + f.name.length + f.value.length, 0);
      tot += n;
      if ((e.title || '').length > 256) throw new Error(`Embed ${i + 1}: العنوان أطول من 256`);
      if ((e.description || '').length > 4096) throw new Error(`Embed ${i + 1}: الوصف أطول من 4096`);
      if ((e.fields || []).length > 25) throw new Error(`Embed ${i + 1}: أكثر من 25 حقلاً`);
    });
    if (tot > 6000) throw new Error('مجموع أحرف الـ Embeds يتجاوز 6000');
    D.rows.forEach(r => r.forEach(b => {
      if (!b.label) throw new Error('كل زر يحتاج نصاً');
      if (!safeUrl(b.url)) throw new Error(`رابط الزر «${b.label}» غير صالح (يبدأ بـ https://)`);
    }));
    D.files.forEach(f => { if (f.file.size > 40 * 1048576) throw new Error('الملف «' + f.file.name + '» كبير جداً'); });
  }

  /* ---------- helpers ---------- */
  const getPath = p => p.split('.').reduce((o, k) => o == null ? o : o[k], D);
  function setPath(p, v) { const ks = p.split('.'); let o = D; for (let i = 0; i < ks.length - 1; i++) o = o[ks[i]]; o[ks[ks.length - 1]] = v; }
  function ed(path, ph, o = {}) {
    const v = getPath(path); const val = v == null ? '' : v;
    const cls = 'ed' + (o.cls ? ' ' + o.cls : '');
    if (o.area) return `<textarea class="${cls}" data-k="${path}" rows="${o.rows || 2}" placeholder="${esc(ph)}" dir="auto" ${o.max ? `maxlength="${o.max}"` : ''}>${esc(val)}</textarea>`;
    return `<input class="${cls}" type="text" data-k="${path}" placeholder="${esc(ph)}" value="${esc(val)}" ${o.ltr ? 'dir="ltr"' : 'dir="auto"'} ${o.max ? `maxlength="${o.max}"` : ''}>`;
  }
  function defaultIdentity() {
    const info = D.dest.info;
    if (D.dest.mode === 'bot') return { name: 'اسم البوت', avatar: defaultAvatar(0) };
    return { name: D.username || (info && info.name) || 'Webhook', avatar: safeUrl(D.avatar) || (info && info.avatar) || defaultAvatar(1) };
  }

  /* ---------- rendering ---------- */
  function destBar() {
    const d = D.dest;
    const ok = d.mode === 'webhook' ? (d.id && d.token) : (d.botToken && d.channelId);
    const title = d.mode === 'webhook' ? '🪝 ويبهوك' : '🤖 بوت → قناة';
    const sub = d.mode === 'webhook' ? (d.id ? (d.info ? d.info.name + ' · ' : '') + '…' + d.token.slice(-6) : 'اضغط لإضافة رابط الويبهوك') : (d.channelId ? 'قناة ' + d.channelId + (d.channelName ? ' · #' + d.channelName : '') : 'اضغط لاختيار القناة');
    return `<button class="dest" data-act="cmp.dest"><span class="dot ${ok ? '' : 'off'}"></span><div class="grow"><div class="n">${title}</div><div class="s">${esc(sub)}</div></div><span>⚙️</span></button>`;
  }
  function embedHTML(e, i) {
    const sw = SW.map(c => `<button class="sw ${c.toLowerCase() === e.color.toLowerCase() ? 'on' : ''}" style="background:${c}" data-act="cmp.color" data-i="${i}" data-c="${c}"></button>`).join('') + `<button class="sw custom ${SW.some(c => c.toLowerCase() === e.color.toLowerCase()) ? '' : 'on'}" style="${SW.some(c => c.toLowerCase() === e.color.toLowerCase()) ? '' : 'background:' + esc(e.color)}" data-act="cmp.colorx" data-i="${i}" aria-label="لون مخصص">🎨</button>`;
    const P = `embeds.${i}`;
    let h = `<div class="embed ed-embed" style="border-left-color:${esc(e.color)}"><div class="embed-in">`;
    if (e.author) h += `<div class="e-author">${e.author.icon_url ? `<img src="${esc(safeUrl(e.author.icon_url))}" alt="">` : ''}${ed(P + '.author.name', 'اسم المؤلف', { cls: 'b' })}<button class="x" data-act="cmp.epart" data-i="${i}" data-p="author" data-v="off">✕</button></div>
      <div class="two">${ed(P + '.author.url', 'رابط المؤلف', { ltr: 1 })}${ed(P + '.author.icon_url', 'أيقونة المؤلف (URL)', { ltr: 1 })}</div>`;
    h += `<div class="e-title">${ed(P + '.title', 'عنوان الـ Embed', { cls: 't' })}</div>`;
    if (e.title) h += ed(P + '.url', 'رابط العنوان (اختياري)', { ltr: 1, cls: 's' });
    h += `<div class="e-desc">${ed(P + '.description', 'وصف الـ Embed… يدعم **عريض** و _مائل_ و [رابط](https://…)', { area: 1, rows: 3 })}</div>`;
    if (e.fields.length) {
      h += '<div class="e-fields">' + e.fields.map((f, j) => `<div class="e-field ${f.inline ? 'inl' : ''}">
        <div class="frow">${ed(`${P}.fields.${j}.name`, 'اسم الحقل', { cls: 'b' })}<button class="x" data-act="cmp.fdel" data-i="${i}" data-j="${j}">✕</button></div>
        ${ed(`${P}.fields.${j}.value`, 'القيمة', { area: 1, rows: 1 })}
        <label class="mini"><input type="checkbox" data-k="${P}.fields.${j}.inline" data-chk="1" ${f.inline ? 'checked' : ''} data-rerender="1"> بجانب الحقل التالي (inline)</label></div>`).join('') + '</div>';
    }
    if (e.image !== null) h += `<div class="imgbox">${safeUrl(e.image) ? `<img class="e-img" src="${esc(e.image)}" alt="">` : ''}<div class="frow">${ed(P + '.image', 'رابط الصورة الكبيرة', { ltr: 1 })}<button class="x" data-act="cmp.epart" data-i="${i}" data-p="image" data-v="off">✕</button></div></div>`;
    if (e.thumb !== null) h += `<div class="imgbox">${safeUrl(e.thumb) ? `<img class="e-img" style="max-height:70px" src="${esc(e.thumb)}" alt="">` : ''}<div class="frow">${ed(P + '.thumb', 'رابط الصورة المصغّرة', { ltr: 1 })}<button class="x" data-act="cmp.epart" data-i="${i}" data-p="thumb" data-v="off">✕</button></div></div>`;
    if (e.footer) h += `<div class="e-foot">${e.footer.icon_url ? `<img src="${esc(safeUrl(e.footer.icon_url))}" alt="">` : ''}${ed(P + '.footer.text', 'نص التذييل')}<button class="x" data-act="cmp.epart" data-i="${i}" data-p="footer" data-v="off">✕</button></div>${ed(P + '.footer.icon_url', 'أيقونة التذييل (URL)', { ltr: 1, cls: 's' })}`;
    if (e.timestamp) h += `<div class="sub">🕒 سيُضاف وقت الإرسال <button class="x" data-act="cmp.epart" data-i="${i}" data-p="timestamp" data-v="off">✕</button></div>`;
    h += `<div class="etools"><div class="sws">${sw}</div><div class="adds">
      ${e.author ? '' : `<button data-act="cmp.epart" data-i="${i}" data-p="author" data-v="on">＋ مؤلف</button>`}
      <button data-act="cmp.fadd" data-i="${i}">＋ حقل</button>
      ${e.image === null ? `<button data-act="cmp.epart" data-i="${i}" data-p="image" data-v="on">＋ صورة</button>` : ''}
      ${e.thumb === null ? `<button data-act="cmp.epart" data-i="${i}" data-p="thumb" data-v="on">＋ مصغّرة</button>` : ''}
      ${e.footer ? '' : `<button data-act="cmp.epart" data-i="${i}" data-p="footer" data-v="on">＋ تذييل</button>`}
      ${e.timestamp ? '' : `<button data-act="cmp.epart" data-i="${i}" data-p="timestamp" data-v="on">＋ وقت</button>`}
      ${i > 0 ? `<button data-act="cmp.emove" data-i="${i}" data-d="-1">↑ للأعلى</button>` : ''}${i < D.embeds.length - 1 ? `<button data-act="cmp.emove" data-i="${i}" data-d="1">↓ للأسفل</button>` : ''}<button data-act="cmp.edup" data-i="${i}">نسخ الـ Embed</button>
      <button class="red" data-act="cmp.edel" data-i="${i}">🗑 حذف</button></div></div>`;
    return h + '</div></div>';
  }
  function filesHTML() {
    return D.files.map((f, i) => `<div class="cmp-file">${/^image\//.test(f.file.type) ? `<img src="${esc(f.url)}" alt="">` : '<span class="fi">📄</span>'}<div class="grow"><div class="fn">${esc(f.file.name)}</div><small>${fmtSize(f.file.size)}</small></div>
      <label class="mini"><input type="checkbox" data-chk="1" data-fspoil="${i}" ${f.spoiler ? 'checked' : ''}> Spoiler</label><button class="x" data-act="cmp.fdelfile" data-i="${i}">✕</button></div>`).join('');
  }
  function rowsHTML() {
    return D.rows.map((r, ri) => `<div class="btnrow ed-btns">${r.map((b, bi) => `<div class="dbtn link ed-btn">${ed(`rows.${ri}.${bi}.emoji`, '😀', { cls: 'em' })}${ed(`rows.${ri}.${bi}.label`, 'نص الزر')}${ed(`rows.${ri}.${bi}.url`, 'https://…', { ltr: 1, cls: 'u' })}<button class="x" data-act="cmp.bdel" data-r="${ri}" data-b="${bi}">✕</button></div>`).join('')}
      ${r.length < 5 ? `<button class="dbtn p" data-act="cmp.badd" data-r="${ri}">＋ زر</button>` : ''}</div>`).join('');
  }
  function messageCard() {
    const id = defaultIdentity(), bot = D.dest.mode === 'bot';
    if (D.preview) return `<div class="mcard pv">${previewHTML()}</div>`;
    return `<div class="mcard"><div class="msg first" style="padding:0"><img class="av" data-act="cmp.avatar" src="${esc(id.avatar)}" alt="">
      <div class="mb"><div class="mh">${bot ? `<span class="un">${esc(id.name)}</span>` : `<input class="ed un" type="text" data-k="username" dir="auto" placeholder="${esc(id.name)}" value="${esc(D.username)}" maxlength="80">`}<span class="tag">APP</span><time>الآن</time></div>
      <div class="fmtbar">${[['B', '**', '**'], ['I', '*', '*'], ['U', '__', '__'], ['S', '~~', '~~'], ['‹/›', '`', '`'], ['||', '||', '||'], ['❝', '> ', ''], ['H', '# ', ''], ['•', '- ', ''], ['{ }', '```\n', '\n```']].map(x => `<button data-act="cmp.fmt" data-a="${esc(x[1])}" data-b="${esc(x[2])}">${esc(x[0])}</button>`).join('')}<button data-act="cmp.mention">@</button><button data-act="cmp.chmention">#</button><button data-act="cmp.ts">🕒</button><button data-act="cmp.emoji">😀</button></div>
      ${ed('content', 'اكتب نص الرسالة هنا…', { area: 1, rows: 3, cls: 'ctext', max: 2000 })}
      <div class="count ${D.content.length > 1900 ? 'bad' : ''}" data-count="content">${D.content.length}/2000</div>
      ${D.embeds.map(embedHTML).join('')}${filesHTML()}${rowsHTML()}</div></div></div>`;
  }
  function previewHTML() {
    const id = defaultIdentity(), p = buildPayload();
    const att = {}; D.files.forEach(f => { att[f.file.name] = f.url; });
    const m = { id: 'pv', timestamp: new Date().toISOString(), author: { username: id.name, bot: true }, content: p.content || '', embeds: p.embeds || [], components: p.components || [], attachments: D.files.map(f => ({ filename: (f.spoiler ? 'SPOILER_' : '') + f.file.name, size: f.file.size, content_type: f.file.type, blobUrl: f.url })) };
    return renderMessage(m, { name: id.name, avatar: id.avatar, app: true, ctx: { attachmentUrls: att } }) || '';
  }
  function histHTML() {
    if (!hist.length) return '';
    return `<div class="sect">الرسائل المرسلة</div>` + hist.map((h, i) => `<div class="hist"><span>${h.dest.mode === 'webhook' ? '🪝' : '🤖'}</span><div class="t">${esc(h.snip || '(بدون نص)')}</div><time>${new Date(h.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</time>
      <button class="ibtn" style="width:32px;height:32px" data-act="cmp.hedit" data-i="${i}">✏️</button><button class="ibtn" style="width:32px;height:32px;color:#ff8d8f" data-act="cmp.hdel" data-i="${i}">🗑</button></div>`).join('');
  }
  function render() {
    const st = root.scrollTop;
    root.innerHTML = `<div class="pad">${destBar()}
      ${D.editing ? `<div class="note info">✏️ وضع التعديل — ستُحدَّث الرسالة المرسلة سابقاً. <button class="btn sm sec" data-act="cmp.canceledit" style="margin-inline-start:8px">إلغاء</button></div>` : ''}
      ${messageCard()}
      ${D.preview ? '' : `<div class="addbar"><button data-act="cmp.addembed">🧩 ＋ Embed</button><button data-act="cmp.addfile">📎 ＋ ملف</button><button data-act="cmp.addbtn">🔗 ＋ زر رابط</button><button data-act="cmp.opts">⚙️ خيارات</button></div>`}
      ${histHTML()}<div style="height:70px"></div></div>
      <div class="sendbar"><button class="btn sec" data-act="cmp.preview">${D.preview ? '✏️ تحرير' : '👁 معاينة'}</button><button class="btn sec" data-act="cmp.more">⋯</button>
      <button class="btn grow" data-act="cmp.send" ${D.editing ? '' : ''}>${D.editing ? '💾 حفظ التعديل' : 'إرسال ➤'}</button></div>`;
    $$('textarea', root).forEach(autoGrow);
    root.scrollTop = st;
  }

  /* ---------- input handling ---------- */
  function onInput(e) {
    const t = e.target, k = t.dataset && t.dataset.k;
    if (t.dataset.fspoil != null) { D.files[+t.dataset.fspoil].spoiler = t.checked; return; }
    if (!k) return;
    const v = t.dataset.chk ? t.checked : t.value;
    setPath(k, v);
    if (t.tagName === 'TEXTAREA') autoGrow(t);
    if (k === 'content') {
      const c = $('[data-count="content"]', root);
      if (c) { c.textContent = D.content.length + '/2000'; c.classList.toggle('bad', D.content.length > 1900); }
    }
    if (/\.(icon_url|image|thumb|url)$/.test(k) && t.dataset.rerender == null) { clearTimeout(onInput.t); onInput.t = setTimeout(() => { if (document.activeElement !== t) render(); }, 700); }
    if (t.dataset.rerender) render();
    persist();
  }
  function wrapSel(a, b) {
    const ta = $('textarea[data-k="content"]', root);
    if (!ta) return;
    const s = ta.selectionStart, en = ta.selectionEnd, v = ta.value, sel = v.slice(s, en);
    ta.value = v.slice(0, s) + a + sel + b + v.slice(en);
    ta.focus();
    ta.selectionStart = s + a.length; ta.selectionEnd = s + a.length + sel.length;
    D.content = ta.value; autoGrow(ta); persist();
    const c = $('[data-count="content"]', root); if (c) c.textContent = D.content.length + '/2000';
  }
  function insertAtCursor(txt) { wrapSel(txt, ''); }

  /* ---------- destination ---------- */
  const HOOK_RE = /^https:\/\/(?:(?:canary|ptb)\.)?(?:discord|discordapp)\.com\/api(?:\/v\d+)?\/webhooks\/(\d{15,25})\/([\w-]+)/i;
  function destSheet() {
    const d = D.dest;
    const s = openSheet(`<div class="seg" style="margin-bottom:12px"><button data-m="webhook" class="${d.mode === 'webhook' ? 'on' : ''}">🪝 رابط ويبهوك</button><button data-m="bot" class="${d.mode === 'bot' ? 'on' : ''}">🤖 بوت + قناة</button></div><div id="d-body"></div>`, { title: 'الوجهة' });
    const body = s.el.querySelector('#d-body');
    const draw = () => {
      if (d.mode === 'webhook') {
        body.innerHTML = `<div class="field"><label>رابط الويبهوك</label><input id="d-url" class="ltr" type="text" placeholder="https://discord.com/api/webhooks/…" value="${esc(d.url)}"></div>
          <div class="row"><button class="btn sec grow" id="d-check">🔍 فحص الويبهوك</button><button class="btn grow" id="d-save">حفظ</button></div><div id="d-info" class="sub" style="margin-top:10px"></div>
          <p class="sub" style="margin-top:12px">الرابط يُخزَّن على جهازك فقط. من لديه الرابط يستطيع الإرسال — لا تشاركه.</p>`;
        $('#d-check', body).onclick = async e => withBusy(e.currentTarget, async () => {
          const m = HOOK_RE.exec($('#d-url', body).value.trim());
          if (!m) throw new Error('رابط ويبهوك غير صالح');
          const w = await dapi('GET', `/webhooks/${m[1]}/${m[2]}`);
          $('#d-info', body).innerHTML = `<div class="botcard"><img src="${esc(w.avatar ? `${CDN}/avatars/${w.id}/${w.avatar}.png?size=128` : defaultAvatar(w.id))}" alt=""><div><div class="n" style="font-size:15px">${esc(w.name || '')}</div><div class="sub">قناة ${esc(w.channel_id || '')}</div></div></div>`;
        }).catch(er => toast(er.message, 'bad'));
        $('#d-save', body).onclick = async e => withBusy(e.currentTarget, async () => {
          const url = $('#d-url', body).value.trim(), m = HOOK_RE.exec(url);
          if (!m) throw new Error('رابط ويبهوك غير صالح');
          d.mode = 'webhook'; d.url = url; d.id = m[1]; d.token = m[2]; d.info = null;
          try { const w = await dapi('GET', `/webhooks/${m[1]}/${m[2]}`); d.info = { name: w.name, avatar: w.avatar ? `${CDN}/avatars/${w.id}/${w.avatar}.png?size=128` : defaultAvatar(w.id) }; } catch (er) { /* optional */ }
          persist(); s.close(); render(); toast('تم حفظ الوجهة', 'ok');
        }).catch(er => toast(er.message, 'bad'));
      } else {
        body.innerHTML = `<div class="field"><label>توكن البوت</label><input id="d-tok" class="ltr" type="password" value="${esc(d.botToken || Tokens.get())}"></div>
          <div class="field"><label>القناة</label><div class="row"><input id="d-ch" class="ltr" inputmode="numeric" placeholder="Channel ID" value="${esc(d.channelId)}"><button class="btn sec sm" id="d-pick">اختيار</button></div></div>
          <button class="btn block" id="d-save">حفظ</button><p class="sub" style="margin-top:10px">الإرسال كبوت يدعم الأزرار الرابطية والـ Embeds والملفات. الاسم والصورة هنا هما اسم البوت نفسه.</p>`;
        $('#d-pick', body).onclick = async () => {
          const t = $('#d-tok', body).value.trim(); if (!t) return toast('أدخل التوكن أولاً', 'bad');
          const c = await pickChannel(t); if (c) { $('#d-ch', body).value = c.id; d.channelName = c.name; }
        };
        $('#d-save', body).onclick = () => {
          const t = $('#d-tok', body).value.trim(), c = $('#d-ch', body).value.trim();
          if (!t || !isId(c)) return toast('التوكن أو القناة غير صالحين', 'bad');
          d.mode = 'bot'; d.botToken = t; d.channelId = c; Tokens.set(t); persist(); s.close(); render(); toast('تم حفظ الوجهة', 'ok');
        };
      }
    };
    s.el.querySelectorAll('[data-m]').forEach(b => b.onclick = () => { d.mode = b.dataset.m; s.el.querySelectorAll('[data-m]').forEach(x => x.classList.toggle('on', x === b)); draw(); });
    draw();
  }

  /* ---------- send / edit ---------- */
  function target(dest, msgId) {
    if (dest.mode === 'webhook') return { path: `/webhooks/${dest.id}/${dest.token}${msgId ? '/messages/' + msgId : ''}`, token: undefined };
    return { path: `/channels/${dest.channelId}/messages${msgId ? '/' + msgId : ''}`, token: dest.botToken || Tokens.get() };
  }
  async function send(btn) {
    const d = D.dest;
    if (d.mode === 'webhook' ? !(d.id && d.token) : !(d.botToken && d.channelId)) { destSheet(); throw new Error('حدد الوجهة أولاً'); }
    const edit = D.editing;
    const payload = buildPayload(!!edit);
    validate(payload);
    await withBusy(btn, async () => {
      const dest = edit ? edit.dest : Object.assign({}, d);
      const T = target(dest, edit && edit.id);
      const query = {};
      if (dest.mode === 'webhook') {
        if (payload.components && payload.components.length) query.with_components = 'true';
        if (!edit) query.wait = 'true';
        if (D.opt.threadId.trim()) query.thread_id = D.opt.threadId.trim();
      }
      const o = { token: T.token, json: payload, query: Object.keys(query).length ? query : undefined };
      if (!edit && D.files.length) {
        const fl = await filesPayload(D.files.map(f => f.spoiler ? new File([f.file], 'SPOILER_' + f.file.name, { type: f.file.type }) : f.file));
        o.files = fl;
        payload.attachments = fl.map((f, i) => ({ id: i, filename: f.name }));
      }
      const msg = await dapi(edit ? 'PATCH' : 'POST', T.path, o);
      if (edit) { D.editing = null; toast('تم تحديث الرسالة ✔', 'ok'); }
      else {
        const snap = snapshot();
        hist.unshift({ id: msg && msg.id, dest, ts: Date.now(), snip: clip(D.content || (D.embeds[0] && (D.embeds[0].title || D.embeds[0].description)) || '', 40), draft: snap });
        hist = hist.filter(h => h.id).slice(0, 15);
        store.set('sent', hist.map(h => Object.assign({}, h, { dest: Object.assign({}, h.dest, { botToken: '' }) })));
        toast('تم الإرسال ✔', 'ok');
      }
      render();
    });
  }
  async function histEdit(i) {
    const h = hist[i]; if (!h) return;
    applySnapshot(h.draft); D.files = []; D.editing = { id: h.id, dest: h.dest }; D.preview = false; render(); root.scrollTop = 0;
  }
  async function histDel(i) {
    const h = hist[i]; if (!h) return;
    if (!await confirmDlg('حذف هذه الرسالة من القناة؟', { danger: true, ok: 'حذف' })) return;
    const T = target(Object.assign({}, h.dest, { botToken: h.dest.botToken || D.dest.botToken }), h.id);
    try { await dapi('DELETE', T.path, { token: T.token }); } catch (e) { if (e.status !== 404) throw e; }
    hist.splice(i, 1); store.set('sent', hist); render(); toast('تم الحذف', 'ok');
  }

  /* ---------- sheets ---------- */
  function optsSheet() {
    const o = D.opt;
    const s = openSheet(`<div class="field"><label>التنبيهات (Mentions)</label><select id="o-m"><option value="safe">آمن — منشن الأعضاء فقط</option><option value="all">الكل (@everyone و الرتب)</option><option value="none">بدون أي منشن</option></select></div>
      <label class="switch"><span>TTS (نطق الرسالة)</span><input type="checkbox" id="o-tts" ${D.tts ? 'checked' : ''}></label>
      <label class="switch"><span>إخفاء معاينة الروابط</span><input type="checkbox" id="o-se" ${o.suppressEmbeds ? 'checked' : ''}></label>
      <label class="switch"><span>إرسال صامت (بدون إشعار)</span><input type="checkbox" id="o-si" ${o.silent ? 'checked' : ''}></label>
      ${D.dest.mode === 'webhook' ? `<div class="field"><label>Thread ID (الإرسال داخل ثريد)</label><input id="o-t" class="ltr" value="${esc(o.threadId)}"></div>
      <div class="field"><label>اسم موضوع جديد (قنوات المنتدى Forum)</label><input id="o-tn" type="text" value="${esc(o.threadName)}"></div>` : ''}
      <button class="btn block" id="o-ok">تم</button>`, { title: 'خيارات الرسالة' });
    $('#o-m', s.el).value = o.mentions;
    $('#o-ok', s.el).onclick = () => {
      o.mentions = $('#o-m', s.el).value; D.tts = $('#o-tts', s.el).checked; o.suppressEmbeds = $('#o-se', s.el).checked; o.silent = $('#o-si', s.el).checked;
      if ($('#o-t', s.el)) { o.threadId = $('#o-t', s.el).value.trim(); o.threadName = $('#o-tn', s.el).value; }
      persist(); s.close();
    };
  }
  /* ---------- Discohook interop & message restore ---------- */
  const b64u = str => btoa(String.fromCharCode(...new TextEncoder().encode(str))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const unb64u = b => { b = b.replace(/-/g, '+').replace(/_/g, '/'); b += '='.repeat((4 - b.length % 4) % 4); return new TextDecoder().decode(Uint8Array.from(atob(b), c => c.charCodeAt(0))); };
  function toDiscohook() { return 'https://discohook.org/?data=' + b64u(JSON.stringify({ messages: [{ data: buildPayload() }] })); }
  function fromDiscohook(txt) {
    const m = /[?&]data=([A-Za-z0-9_\-%=+/]+)/.exec(txt); if (!m) return null;
    try { return JSON.parse(unb64u(decodeURIComponent(m[1]))); } catch (e) { throw new Error('رابط Discohook غير مفهوم'); }
  }
  async function restoreMsg() {
    const v = await promptDlg({ title: 'استعادة رسالة', label: 'رابط الرسالة أو ID', placeholder: 'https://discord.com/channels/…/…/…' }); if (!v) return;
    const m = /channels\/(?:\d+|@me)\/(\d+)\/(\d+)/.exec(v), mid = m ? m[2] : v.trim(), cid = m ? m[1] : D.dest.channelId;
    if (!isId(mid)) throw new Error('رابط أو ID غير صالح');
    const d = D.dest; let msg;
    if (d.mode === 'webhook') { if (!(d.id && d.token)) { destSheet(); throw new Error('حدد الويبهوك أولاً'); } msg = await dapi('GET', `/webhooks/${d.id}/${d.token}/messages/${mid}`); }
    else { const tk = d.botToken || Tokens.get(); if (!tk || !isId(cid)) { destSheet(); throw new Error('حدد البوت والقناة أولاً'); } msg = await dapi('GET', `/channels/${cid}/messages/${mid}`, { token: tk }); }
    loadPayload(msg); D.files = []; D.editing = { id: mid, dest: Object.assign({}, d, d.mode === 'bot' ? { channelId: cid } : {}) }; persist(); render(); toast('تم تحميل الرسالة — عدّل ثم اضغط حفظ', 'ok');
  }
  async function editHook() {
    const d = D.dest, n = await promptDlg({ title: 'اسم الويبهوك', label: 'الاسم (اتركه فارغاً بدون تغيير)', value: (d.info && d.info.name) || '' });
    if (n === null) return;
    const av = await promptDlg({ title: 'صورة الويبهوك', label: 'رابط صورة (اتركه فارغاً بدون تغيير)', placeholder: 'https://…' });
    const body = {}; if (n && n.trim()) body.name = n.trim(); if (av && safeUrl(av)) body.avatar = await fetchImageDataUri(av.trim());
    if (!Object.keys(body).length) return;
    const r = await dapi('PATCH', `/webhooks/${d.id}/${d.token}`, { json: body }); d.info = Object.assign({}, d.info, r); persist(); render(); toast('تم تحديث الويبهوك', 'ok');
  }
  function jsonSheet() {
    const txt = JSON.stringify(buildPayload(), null, 2);
    const s = openSheet(`<div class="field"><label>JSON (يمكنك اللصق من Discohook أو أي مصدر)</label><textarea id="j-t" rows="10" class="ltr" style="font:12px monospace">${esc(txt)}</textarea></div>
      <div class="row"><button class="btn grow" id="j-imp">⬇ استيراد</button><button class="btn sec grow" id="j-cp">📋 نسخ</button></div>`, { title: 'JSON' });
    $('#j-cp', s.el).onclick = () => copyText($('#j-t', s.el).value);
    $('#j-imp', s.el).onclick = () => { try { const raw = $('#j-t', s.el).value; loadPayload(fromDiscohook(raw) || JSON.parse(raw)); s.close(); render(); persist(); toast('تم الاستيراد', 'ok'); } catch (e) { toast('JSON غير صالح: ' + e.message, 'bad'); } };
  }
  function templatesSheet() {
    const list = store.get('templates', []);
    const s = openSheet(`<button class="btn block" id="t-save">💾 حفظ الرسالة الحالية كقالب</button><div id="t-list" style="margin-top:12px"></div>`, { title: 'القوالب' });
    const draw = () => {
      const l = store.get('templates', []);
      $('#t-list', s.el).innerHTML = l.length ? l.map((t, i) => `<div class="hist"><div class="t">${esc(t.name)}</div><button class="btn sm" data-l="${i}">تحميل</button><button class="ibtn" style="width:32px;height:32px;color:#ff8d8f" data-d="${i}">🗑</button></div>`).join('') : '<div class="empty">لا توجد قوالب</div>';
      s.el.querySelectorAll('[data-l]').forEach(b => b.onclick = () => { applySnapshot(l[+b.dataset.l].draft); D.editing = null; s.close(); render(); persist(); });
      s.el.querySelectorAll('[data-d]').forEach(b => b.onclick = () => { l.splice(+b.dataset.d, 1); store.set('templates', l); draw(); });
    };
    $('#t-save', s.el).onclick = async () => {
      const n = await promptDlg({ title: 'اسم القالب', label: 'الاسم' });
      if (n && n.trim()) { const l = store.get('templates', []); l.unshift({ name: n.trim(), draft: snapshot() }); store.set('templates', l.slice(0, 30)); draw(); toast('تم الحفظ', 'ok'); }
    };
    draw();
  }
  function tsSheet() {
    const now = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    const s = openSheet(`<div class="field"><label>التاريخ والوقت</label><input type="datetime-local" id="ts-d" value="${now}"></div>
      <div class="field"><label>الصيغة</label><select id="ts-f"><option value="f">f — تاريخ ووقت</option><option value="F">F — كامل</option><option value="d">d — تاريخ قصير</option><option value="D">D — تاريخ طويل</option><option value="t">t — وقت</option><option value="T">T — وقت بالثواني</option><option value="R">R — نسبي (منذ…)</option></select></div>
      <button class="btn block" id="ts-ok">إدراج</button>`, { title: 'Discord Timestamp' });
    $('#ts-ok', s.el).onclick = () => { const n = Math.floor(new Date($('#ts-d', s.el).value).getTime() / 1000); if (!n) return toast('اختر وقتاً', 'bad'); s.close(); insertAtCursor(`<t:${n}:${$('#ts-f', s.el).value}>`); };
  }

  /* ---------- actions ---------- */
  const fi = document.createElement('input');
  fi.type = 'file'; fi.multiple = true; fi.style.display = 'none';
  document.body.appendChild(fi);
  fi.addEventListener('change', () => {
    Array.from(fi.files || []).forEach(f => D.files.push({ file: f, url: URL.createObjectURL(f), spoiler: false }));
    fi.value = ''; render();
  });

  registerActions({
    'cmp.dest': destSheet,
    'cmp.addembed': () => { if (D.embeds.length >= 10) return toast('الحد الأقصى 10 Embeds', 'bad'); D.embeds.push(newEmbed()); persist(); render(); },
    'cmp.emove': t => { const i = +t.dataset.i, j = i + +t.dataset.d; if (j < 0 || j >= D.embeds.length) return; const x = D.embeds[i]; D.embeds[i] = D.embeds[j]; D.embeds[j] = x; persist(); render(); },
    'cmp.edup': t => { if (D.embeds.length >= 10) return toast('الحد الأقصى 10 Embeds', 'bad'); D.embeds.splice(+t.dataset.i + 1, 0, JSON.parse(JSON.stringify(D.embeds[+t.dataset.i]))); persist(); render(); },
    'cmp.edel': t => { D.embeds.splice(+t.dataset.i, 1); persist(); render(); },
    'cmp.colorx': async t => { const i = +t.dataset.i; const c = await colorPicker(D.embeds[i].color); if (c) { D.embeds[i].color = c; persist(); render(); } },
    'cmp.color': t => { D.embeds[+t.dataset.i].color = t.dataset.c; persist(); render(); },
    'cmp.epart': t => {
      const e = D.embeds[+t.dataset.i], p = t.dataset.p, on = t.dataset.v === 'on';
      if (p === 'author') e.author = on ? { name: '', url: '', icon_url: '' } : null;
      else if (p === 'footer') e.footer = on ? { text: '', icon_url: '' } : null;
      else if (p === 'image' || p === 'thumb') e[p] = on ? '' : null;
      else if (p === 'timestamp') e.timestamp = on;
      persist(); render();
    },
    'cmp.fadd': t => { const e = D.embeds[+t.dataset.i]; if (e.fields.length >= 25) return toast('الحد الأقصى 25 حقلاً', 'bad'); e.fields.push({ name: '', value: '', inline: false }); persist(); render(); },
    'cmp.fdel': t => { D.embeds[+t.dataset.i].fields.splice(+t.dataset.j, 1); persist(); render(); },
    'cmp.addfile': () => fi.click(),
    'cmp.fdelfile': t => { const f = D.files.splice(+t.dataset.i, 1)[0]; if (f) URL.revokeObjectURL(f.url); render(); },
    'cmp.addbtn': () => { if (!D.rows.length) D.rows.push([]); const r = D.rows[D.rows.length - 1]; if (r.length >= 5) { if (D.rows.length >= 5) return toast('الحد 5 صفوف', 'bad'); D.rows.push([]); } D.rows[D.rows.length - 1].push({ label: '', url: '', emoji: '' }); persist(); render(); },
    'cmp.badd': t => { D.rows[+t.dataset.r].push({ label: '', url: '', emoji: '' }); persist(); render(); },
    'cmp.bdel': t => { const r = D.rows[+t.dataset.r]; r.splice(+t.dataset.b, 1); if (!r.length) D.rows.splice(+t.dataset.r, 1); persist(); render(); },
    'cmp.emoji': async () => {
      const token = D.botToken || Tokens.get() || null; let gid = (D.info && D.info.guild_id) || D.guildId || null;
      if (!gid && token && D.channelId) { try { gid = (await dapi('GET', `/channels/${D.channelId}`, { token })).guild_id; D.guildId = gid; } catch (e) { /* ignore */ } }
      emojiSheet(t => { insertAtCursor(t); toast('أُدرج', 'ok'); }, token, gid);
    },
    'cmp.fmt': t => wrapSel(t.dataset.a, t.dataset.b),
    'cmp.mention': async () => { const v = await promptDlg({ title: 'منشن عضو', label: 'User ID', placeholder: '123456789012345678' }); if (v && isId(v)) insertAtCursor(`<@${v.trim()}>`); },
    'cmp.chmention': async () => { const v = await promptDlg({ title: 'منشن قناة', label: 'Channel ID' }); if (v && isId(v)) insertAtCursor(`<#${v.trim()}>`); },
    'cmp.ts': tsSheet,
    'cmp.avatar': async () => {
      if (D.dest.mode === 'bot') return;
      const v = await promptDlg({ title: 'صورة المرسل', label: 'رابط الصورة (URL)', value: D.avatar, placeholder: 'https://…' });
      if (v != null) { D.avatar = v.trim(); persist(); render(); }
    },
    'cmp.opts': optsSheet,
    'cmp.preview': () => { D.preview = !D.preview; render(); },
    'cmp.send': t => send(t),
    'cmp.canceledit': () => { D.editing = null; render(); },
    'cmp.hedit': t => histEdit(+t.dataset.i), 'cmp.hdel': t => histDel(+t.dataset.i),
    'cmp.more': () => menuSheet('المزيد', [
      { icon: '{ }', label: 'JSON — استيراد / تصدير', fn: jsonSheet },
      { icon: '🔗', label: 'نسخ رابط Discohook', fn: () => { copyText(toDiscohook()); } },
      { icon: '📥', label: 'استعادة رسالة من رابط / ID', fn: restoreMsg },
      D.dest.mode === 'webhook' && D.dest.id && { icon: '🪝', label: 'تعديل اسم / صورة الويبهوك نفسه', fn: editHook },
      { icon: '💾', label: 'القوالب', fn: templatesSheet },
      { icon: '⚙️', label: 'خيارات الرسالة', fn: optsSheet },
      { icon: '🧹', label: 'مسح المحتوى', cls: 'red', fn: async () => { if (await confirmDlg('مسح كل محتوى الرسالة؟', { danger: true, ok: 'مسح' })) { applySnapshot({}); D.files = []; D.editing = null; persist(); render(); } } }
    ])
  });

  function mount(el) {
    root = el;
    const dst = store.get('dest', null); if (dst) Object.assign(D.dest, dst);
    if (!D.dest.botToken) D.dest.botToken = Tokens.get();
    const dr = store.get('draft', null); if (dr) applySnapshot(dr);
    hist = store.get('sent', []);
    root.addEventListener('input', onInput);
    root.addEventListener('change', onInput);
    root.addEventListener('mousedown', e => { if (e.target.closest('.fmtbar')) e.preventDefault(); });
    render();
  }
  function back() { if (D.preview) { D.preview = false; render(); return true; } return false; }
  return { mount, back, load: loadPayload, render, get D() { return D; }, build: buildPayload };
})();

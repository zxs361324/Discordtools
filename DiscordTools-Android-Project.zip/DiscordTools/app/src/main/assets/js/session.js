'use strict';
/* ============================================================
   session.js — "member identity" live chat session
   bot token + channel + member  ->  temporary webhook that looks
   exactly like the member; chat, reply, edit, delete; cleanup.
   ============================================================ */
const Tokens = {
  get() { return store.get('token', ''); },
  set(t) { if (settings.all.remember) store.set('token', t); },
  clear() { store.del('token'); }
};
const Pending = {
  all() { return store.get('pending_hooks', []); },
  add(h) { const l = Pending.all().filter(x => x.id !== h.id); l.push(h); store.set('pending_hooks', l); },
  remove(id) { store.set('pending_hooks', Pending.all().filter(x => x.id !== id)); }
};
function mentionsCfg() { return settings.all.allowEveryone ? undefined : { parse: ['users'] }; }
async function deleteHook(h) {
  try { await dapi('DELETE', `/webhooks/${h.id}/${h.token}`); }
  catch (e) { if (e.status !== 404 && e.status !== 401) throw e; }
  Pending.remove(h.id);
}

const Session = (() => {
  let root = null;
  const S = { channel: null, member: null, pv: null, hook: null, ident: null, cv: null, token: '', sent: [] };

  function mount(el) { root = el; renderSetup(); }
  function back() {
    if (S.hook) { endFlow(); return true; }
    return false;
  }

  /* ---------- setup ---------- */
  function renderSetup() {
    root.classList.remove('flex');
    const tok = Tokens.get();
    const pend = Pending.all();
    root.innerHTML = `<div class="pad">
      <div class="h1">🎭 جلسة بهوية عضو</div>
      <p class="sub">أنشئ ويبهوك مؤقتاً يحمل اسم وصورة عضو من السيرفر، وتحادث به داخل التطبيق، ثم يُحذف عند الانتهاء.</p>
      <div class="note info" style="margin-top:12px">الرسائل تُرسل عبر ويبهوك باسم وصورة العضو، وتظهر في ديسكورد بعلامة <b>APP</b>. استخدمها في سيرفرك أو بموافقة أصحاب الشأن.</div>
      ${pend.length ? `<div class="note bad">لديك ${pend.length} ويبهوك لم يُحذف من جلسة سابقة. <button class="btn sm red" data-act="sess.cleanup" style="margin-inline-start:8px">احذفها الآن</button></div>` : ''}
      <div class="card">
        <div class="field"><label>توكن البوت</label>
          <div class="row"><input id="s-token" class="ltr" type="password" autocomplete="off" placeholder="MTA…" value="${esc(tok)}"><button class="ibtn" data-act="sess.eye">👁</button></div></div>
        <label class="switch"><span>تذكّر التوكن على هذا الجهاز</span><input type="checkbox" id="s-remember" ${settings.all.remember ? 'checked' : ''}></label>
        <div class="field"><label>القناة</label>
          <div class="row"><input id="s-chan" class="ltr" inputmode="numeric" placeholder="Channel ID" value="${esc(S.channel ? S.channel.id : '')}"><button class="btn sec sm" data-act="sess.pickchan">اختيار</button></div></div>
        <div class="field"><label>العضو</label>
          <div class="row"><input id="s-mem" class="ltr" inputmode="numeric" placeholder="User ID" value="${esc(S.member ? S.member.user.id : '')}"><button class="btn sec sm" data-act="sess.pickmem">بحث</button></div></div>
        <button class="btn block" data-act="sess.preview">معاينة الهوية ←</button>
      </div>
      <div id="s-preview"></div>
      <p class="sub" style="text-align:center">يحتاج البوت صلاحية <b>Manage Webhooks</b> في القناة. لقراءة رسائل الأعضاء فعّل <b>Message Content Intent</b>.</p>
    </div>`;
    if (S.pv) drawPreview();
  }

  async function currentToken() {
    const t = ($('#s-token') ? $('#s-token').value : S.token).trim();
    if (!t) throw new Error('أدخل توكن البوت');
    S.token = t;
    return t;
  }

  async function pickChan() {
    const token = await currentToken();
    const c = await pickChannel(token);
    if (c) { S.channel = c; $('#s-chan').value = c.id; }
  }
  async function pickMem() {
    const token = await currentToken();
    const cid = $('#s-chan').value.trim();
    let gid = S.channel && S.channel.id === cid ? S.channel.guild_id : null;
    if (!gid) {
      if (!isId(cid)) throw new Error('اختر القناة أولاً لنعرف السيرفر');
      const ch = await dapi('GET', `/channels/${cid}`, { token });
      gid = ch.guild_id;
      S.channel = { id: ch.id, name: ch.name, guild_id: gid };
    }
    const m = await pickMember(token, gid);
    if (m) { S.member = m; $('#s-mem').value = m.user.id; }
  }

  async function preview(btn) {
    const token = await currentToken();
    settings.set('remember', $('#s-remember').checked);
    if ($('#s-remember').checked) Tokens.set(token); else Tokens.clear();
    const cid = $('#s-chan').value.trim(), uid2 = $('#s-mem').value.trim();
    if (!isId(cid)) throw new Error('Channel ID غير صالح');
    if (!isId(uid2)) throw new Error('User ID غير صالح');
    await withBusy(btn, async () => {
      const bot = await dapi('GET', '/users/@me', { token });
      const ch = await dapi('GET', `/channels/${cid}`, { token });
      if (![0, 5].includes(ch.type)) throw new Error('اختر قناة نصية (Text / Announcement)');
      if (!ch.guild_id) throw new Error('هذه القناة ليست داخل سيرفر');
      const member = await lookupMember(token, ch.guild_id, uid2);
      let gname = (S.channel && S.channel.guild_name) || '';
      if (!gname) { try { gname = (await dapi('GET', `/guilds/${ch.guild_id}`, { token })).name; } catch (e) { /* ignore */ } }
      S.channel = { id: ch.id, name: ch.name, guild_id: ch.guild_id, guild_name: gname };
      S.member = member;
      S.pv = { bot, name: displayName(member.user, member).slice(0, 80), avatar: memberAvatar(ch.guild_id, member, 256) };
      drawPreview();
    });
  }
  function drawPreview() {
    const box = $('#s-preview');
    if (!box || !S.pv) return;
    const m = S.member;
    box.innerHTML = `<div class="card"><div class="botcard"><img src="${esc(S.pv.avatar)}" alt="">
      <div class="grow"><div class="lbl">الهوية التي ستُنشأ</div><input id="s-name" type="text" maxlength="80" value="${esc(S.pv.name)}" style="font-weight:800">
      <div class="sub" style="margin-top:6px">@${esc(m.user.username)} · #${esc(S.channel.name || '')}${S.channel.guild_name ? ' · ' + esc(S.channel.guild_name) : ''}</div></div></div>
      ${m._notMember ? '<div class="note" style="margin-top:10px">العضو ليس في السيرفر — سنستخدم اسمه وصورته العامة.</div>' : ''}
      <button class="btn green block" style="margin-top:12px" data-act="sess.start">▶ ابدأ الجلسة</button></div>`;
  }

  /* ---------- start ---------- */
  async function start(btn) {
    const token = S.token, name = ($('#s-name').value || '').trim();
    if (!name) throw new Error('الاسم فارغ');
    await withBusy(btn, async () => {
      let avatar = null;
      try { avatar = await fetchImageDataUri(S.pv.avatar); } catch (e) { /* avatar optional */ }
      const body = { name };
      if (avatar) body.avatar = avatar;
      const hook = await dapi('POST', `/channels/${S.channel.id}/webhooks`, { token, json: body, reason: 'Discord Tools session' });
      Pending.add({ id: hook.id, token: hook.token, name, channel: S.channel.name, ts: Date.now() });
      S.hook = { id: hook.id, token: hook.token };
      S.ident = { name, avatar_url: memberAvatar(S.channel.guild_id, S.member, 128), id: S.member.user.id };
      S.recent = [S.ident];
      S.sent = [];
      renderChat();
    });
  }

  /* ---------- chat ---------- */
  function renderChat() {
    root.classList.add('flex');
    root.innerHTML = `<div class="ident"><img id="i-av" src="${esc(S.ident.avatar_url)}" alt=""><div class="grow"><div class="n" id="i-name">${esc(S.ident.name)}</div><div class="s"><span class="dot"></span> جلسة نشطة · #${esc(S.channel.name || '')}</div></div>
      <button class="ibtn" data-act="sess.ident" title="الهوية">🎭</button><button class="ibtn" data-act="sess.end" title="إنهاء" style="color:#ff8d8f">⏹</button></div>
      <div style="flex:1;min-height:0" id="s-chat"></div>`;
    const token = S.token, hook = S.hook, cid = S.channel.id;
    const hp = `/webhooks/${hook.id}/${hook.token}`;
    S.cv = new ChatView($('#s-chat'), {
      channelId: cid, guildId: S.channel.guild_id, replyMode: 'quote', intervalMs: settings.all.pollMs, token,
      placeholder: `رسالة إلى #${S.channel.name || ''} بهوية ${S.ident.name}`,
      profile: { useLabel: 'ابدأ استخدام هذه الهوية', onUse: u => setIdent(u.name.slice(0, 80), u.avatar, u.id) },
      getMessages: () => dapi('GET', `/channels/${cid}/messages`, { token, query: { limit: 50 } }),
      isMine: m => m.webhook_id === hook.id,
      send: async ({ text, files }) => {
        const json = { content: text, username: S.ident.name, avatar_url: S.ident.avatar_url, allowed_mentions: mentionsCfg() };
        const msg = await dapi('POST', hp, { json, query: { wait: 'true' }, files: files.length ? await filesPayload(files) : undefined });
        if (msg && msg.id) S.sent.push(msg.id);
        return msg;
      },
      edit: (m, text) => dapi('PATCH', `${hp}/messages/${m.id}`, { json: { content: text, allowed_mentions: mentionsCfg() } }),
      del: m => dapi('DELETE', `${hp}/messages/${m.id}`),
      botDel: m => dapi('DELETE', `/channels/${cid}/messages/${m.id}`, { token }),
      react: (m, emoji) => dapi('PUT', `/channels/${cid}/messages/${m.id}/reactions/${encodeURIComponent(emoji)}/@me`, { token }),
      onFatal: e => toast('توقفت المزامنة: ' + e.message, 'bad')
    });
    S.cv.start();
  }

  function identMenu() {
    const rec = (S.recent || []).filter(x => x.name !== S.ident.name || x.avatar_url !== S.ident.avatar_url);
    menuSheet('الهوية الحالية', rec.slice(0, 4).map(r => ({ icon: '🕘', label: 'العودة إلى: ' + r.name, fn: () => setIdent(r.name, r.avatar_url, r.id) })).concat([
      { icon: '👤', label: 'التحدث بهوية عضو آخر', fn: async () => {
        const m = await pickMember(S.token, S.channel.guild_id);
        if (m) setIdent(displayName(m.user, m).slice(0, 80), memberAvatar(S.channel.guild_id, m, 128), m.user.id);
      } },
      { icon: '✏️', label: 'تغيير الاسم', fn: async () => {
        const v = await promptDlg({ title: 'الاسم الظاهر', label: 'الاسم', value: S.ident.name });
        if (v && v.trim()) setIdent(v.trim().slice(0, 80), S.ident.avatar_url);
      } },
      { icon: '🖼️', label: 'تغيير رابط الصورة', fn: async () => {
        const v = await promptDlg({ title: 'رابط الصورة', label: 'URL', value: S.ident.avatar_url, placeholder: 'https://…' });
        if (v && safeUrl(v)) setIdent(S.ident.name, v.trim());
      } }
    ]));
  }
  function setIdent(name, avatar, id) {
    S.ident = { name, avatar_url: avatar, id };
    S.recent = [S.ident].concat((S.recent || []).filter(x => x.name !== name || x.avatar_url !== avatar)).slice(0, 8);
    $('#i-name').textContent = name;
    $('#i-av').src = avatar;
    if (S.cv) $('textarea', S.cv.root).placeholder = `رسالة إلى #${S.channel.name || ''} بهوية ${name}`;
    toast('أصبحت تتحدث بهوية: ' + name, 'ok');
  }

  function endFlow() {
    const sentCount = S.sent.length;
    const s = openSheet(`<p style="margin:2px 0 10px;line-height:1.8">سيتم <b>حذف الويبهوك</b> من القناة نهائياً. رسائلك السابقة تبقى في القناة${sentCount ? '' : '.'}</p>
      ${sentCount ? `<label class="switch"><span>احذف أيضاً رسائل هذه الجلسة (${sentCount})</span><input type="checkbox" id="e-del"></label>` : ''}
      <div class="row" style="margin-top:8px"><button class="btn red grow" data-ok>إنهاء وحذف الويبهوك</button><button class="btn sec grow" data-no>متابعة</button></div>`, { title: 'إنهاء الجلسة' });
    s.el.querySelector('[data-no]').onclick = () => s.close();
    s.el.querySelector('[data-ok]').onclick = async e => {
      const delMsgs = !!(s.el.querySelector('#e-del') && s.el.querySelector('#e-del').checked);
      await withBusy(e.currentTarget, async () => {
        try {
          if (delMsgs) {
            for (const id of S.sent) {
              try { await dapi('DELETE', `/webhooks/${S.hook.id}/${S.hook.token}/messages/${id}`); } catch (er) { /* already gone */ }
            }
          }
          await deleteHook(S.hook);
          if (S.cv) S.cv.stop();
          S.cv = null; S.hook = null; S.ident = null; S.pv = null;
          s.close();
          renderSetup();
          toast('تم حذف الويبهوك وإنهاء الجلسة ✔', 'ok');
        } catch (er) { toast(er.message, 'bad'); }
      });
    };
  }

  async function cleanup(btn) {
    await withBusy(btn, async () => {
      for (const h of Pending.all()) {
        try { await deleteHook(h); } catch (e) { toast(`تعذر حذف ${h.name}: ${e.message}`, 'bad'); }
      }
      renderSetup();
      toast('تم تنظيف الويبهوكات', 'ok');
    });
  }

  registerActions({
    'sess.eye': () => { const i = $('#s-token'); i.type = i.type === 'password' ? 'text' : 'password'; },
    'sess.pickchan': pickChan, 'sess.pickmem': pickMem, 'sess.preview': t => preview(t),
    'sess.start': t => start(t), 'sess.ident': identMenu, 'sess.end': endFlow, 'sess.cleanup': t => cleanup(t)
  });
  return { mount, back, get active() { return !!S.hook; } };
})();

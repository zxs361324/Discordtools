package com.discordtools.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends Activity {

    private static final int REQ_FILES = 1001;
    private static final String UA = "DiscordBot (https://discordtools.local, 2.0)";

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private SharedPreferences prefs;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(90, TimeUnit.SECONDS)
            .build();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("dt_store", MODE_PRIVATE);

        final int bg = Color.parseColor("#1E1F22");
        Window w = getWindow();
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(bg);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(bg);

        web = new WebView(this);
        web.setBackgroundColor(bg);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets i = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                v.setPadding(i.left, i.top, i.right, i.bottom);
                return WindowInsets.CONSUMED;
            });
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        web.addJavascriptInterface(new Bridge(), "Native");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String sch = u.getScheme();
                if ("http".equals(sch) || "https".equals(sch)) {
                    openExternal(u.toString());
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView wv, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                String type = "*/*";
                String[] accept = params.getAcceptTypes();
                if (accept != null && accept.length == 1 && accept[0] != null
                        && accept[0].trim().length() > 0) {
                    type = accept[0].trim();
                }
                i.setType(type);
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                        params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(Intent.createChooser(i, "Files"), REQ_FILES);
                } catch (Exception e) {
                    filePathCallback = null;
                    cb.onReceiveValue(null);
                }
                return true;
            }
        });

        setContentView(root);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILES) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__back ? window.__back() : false)", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if (!"true".equals(v)) {
                    finish();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        pool.shutdownNow();
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }

    private void openExternal(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    private static boolean hostAllowed(String host) {
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT);
        String[] roots = {"discord.com", "discordapp.com", "discordapp.net"};
        for (String r : roots) {
            if (host.equals(r) || host.endsWith("." + r)) return true;
        }
        return false;
    }

    private void deliver(final String id, final String resp) {
        final String js = "window.__nativeResp(" + JSONObject.quote(id) + ","
                + JSONObject.quote(resp) + ")";
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) {
                    web.evaluateJavascript(js, null);
                }
            }
        });
    }

    private String doRequest(String json) {
        JSONObject out = new JSONObject();
        try {
            JSONObject r = new JSONObject(json);
            String method = r.optString("method", "GET").toUpperCase(Locale.ROOT);
            String url = r.getString("url");
            Uri u = Uri.parse(url);
            if (!"https".equals(u.getScheme()) || !hostAllowed(u.getHost())) {
                out.put("status", 0);
                out.put("error", "blocked host: " + u.getHost());
                return out.toString();
            }

            Request.Builder rb = new Request.Builder().url(url);
            rb.header("User-Agent", UA);
            JSONObject headers = r.optJSONObject("headers");
            if (headers != null) {
                JSONArray names = headers.names();
                if (names != null) {
                    for (int i = 0; i < names.length(); i++) {
                        String k = names.getString(i);
                        rb.header(k, headers.getString(k));
                    }
                }
            }

            RequestBody body = null;
            JSONObject mp = r.optJSONObject("multipart");
            if (mp != null) {
                MultipartBody.Builder mb = new MultipartBody.Builder().setType(MultipartBody.FORM);
                String payload = mp.optString("payload", "{}");
                mb.addFormDataPart("payload_json", null,
                        RequestBody.create(payload.getBytes("UTF-8"),
                                MediaType.parse("application/json; charset=utf-8")));
                JSONArray files = mp.optJSONArray("files");
                if (files != null) {
                    for (int i = 0; i < files.length(); i++) {
                        JSONObject f = files.getJSONObject(i);
                        byte[] bytes = Base64.decode(f.getString("b64"), Base64.DEFAULT);
                        String ct = f.optString("type", "application/octet-stream");
                        if (ct.length() == 0) ct = "application/octet-stream";
                        MediaType mt = MediaType.parse(ct);
                        if (mt == null) mt = MediaType.parse("application/octet-stream");
                        mb.addFormDataPart("files[" + i + "]", f.optString("name", "file" + i),
                                RequestBody.create(bytes, mt));
                    }
                }
                body = mb.build();
            } else if (r.has("body") && !r.isNull("body")) {
                String ct = r.optString("contentType", "application/json");
                body = RequestBody.create(r.getString("body").getBytes("UTF-8"),
                        MediaType.parse(ct + "; charset=utf-8"));
            }

            boolean needsBody = method.equals("POST") || method.equals("PUT") || method.equals("PATCH");
            if (needsBody && body == null) {
                body = RequestBody.create(new byte[0], null);
            }
            if (method.equals("GET") || method.equals("HEAD")) {
                body = null;
            }
            rb.method(method, body);

            Response resp = client.newCall(rb.build()).execute();
            try {
                byte[] bytes = resp.body() != null ? resp.body().bytes() : new byte[0];
                out.put("status", resp.code());
                String ra = resp.header("Retry-After");
                if (ra != null) out.put("retryAfter", ra);
                String ct = resp.header("Content-Type");
                if (ct != null) out.put("contentType", ct);
                if (r.optBoolean("binary", false)) {
                    out.put("binary", true);
                    out.put("body", Base64.encodeToString(bytes, Base64.NO_WRAP));
                } else {
                    out.put("body", new String(bytes, "UTF-8"));
                }
            } finally {
                resp.close();
            }
        } catch (Throwable t) {
            try {
                out = new JSONObject();
                out.put("status", 0);
                out.put("error", String.valueOf(t.getMessage() != null ? t.getMessage() : t));
            } catch (Exception ignored) {
            }
        }
        return out.toString();
    }

    private class Bridge {
        @JavascriptInterface
        public void request(final String id, final String json) {
            pool.execute(new Runnable() {
                @Override
                public void run() {
                    deliver(id, doRequest(json));
                }
            });
        }

        @JavascriptInterface
        public String storeGet(String k) {
            return prefs.getString(k, null);
        }

        @JavascriptInterface
        public void storeSet(String k, String v) {
            prefs.edit().putString(k, v).apply();
        }

        @JavascriptInterface
        public void storeDel(String k) {
            prefs.edit().remove(k).apply();
        }

        @JavascriptInterface
        public void storeClear() {
            prefs.edit().clear().apply();
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText("Discord Tools", text));
                    }
                }
            });
        }

        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "Share"));
                }
            });
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            if (url == null) return;
            if (!(url.startsWith("https://") || url.startsWith("http://"))) return;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openExternal(url);
                }
            });
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}

package com.discordtools.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Size;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends Activity {

    private static final int REQ_FILES = 1001;
    private static final int REQ_MEDIA = 1002;
    private static final int REQ_MIC = 1003;
    private static final String MEDIA_HOST = "appmedia.local";
    private static final String UA = "DiscordBot (https://discordtools.local, 2.0)";

    private WebView web;
    private FrameLayout rootView;
    private String permCallbackId;
    private MediaRecorder recorder;
    private File recFile;
    private long recStart;
    private final ArrayList<Integer> amps = new ArrayList<Integer>();
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable ampTick = new Runnable() {
        @Override
        public void run() {
            if (recorder != null) {
                try {
                    amps.add(recorder.getMaxAmplitude());
                } catch (Exception ignored) {
                }
                uiHandler.postDelayed(this, 100);
            }
        }
    };
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingText = null;
    private String pendingGo = null;
    private final ArrayList<String[]> pendingFiles = new ArrayList<String[]>();
    private SharedPreferences prefs;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(90, TimeUnit.SECONDS)
            .build();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("dt_store", MODE_PRIVATE);

        final int bg = Color.parseColor("#1A191E");
        Window w = getWindow();
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(bg);

        FrameLayout root = new FrameLayout(this);
        rootView = root;
        root.setBackgroundColor(bg);

        web = new WebView(this);
        web.setBackgroundColor(bg);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets i = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                v.setPadding(i.left, i.top, i.right, i.bottom);
                return WindowInsets.CONSUMED;
            });
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        web.addJavascriptInterface(new Bridge(), "Native");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (u != null && MEDIA_HOST.equals(u.getHost())) {
                    return serveMedia(u);
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String sch = u.getScheme();
                if ("http".equals(sch) || "https".equals(sch)) {
                    openExternal(u.toString());
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView wv, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                String type = "*/*";
                String[] accept = params.getAcceptTypes();
                if (accept != null && accept.length == 1 && accept[0] != null
                        && accept[0].trim().length() > 0) {
                    type = accept[0].trim();
                }
                i.setType(type);
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                        params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(Intent.createChooser(i, "Files"), REQ_FILES);
                } catch (Exception e) {
                    filePathCallback = null;
                    cb.onReceiveValue(null);
                }
                return true;
            }
        });

        setContentView(root);
        web.loadUrl("file:///android_asset/index.html");
        handleIntent(getIntent());
        if (prefs.getBoolean("svc_on", false)) {
            try {
                Intent si = new Intent(this, KeepAliveService.class);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(si); else startService(si);
            } catch (Throwable ignored) { }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
        try { web.evaluateJavascript("window.__shared&&window.__shared()", null); } catch (Throwable ignored) { }
    }

    private void handleIntent(Intent in) {
        if (in == null) return;
        try {
            String act = in.getAction();
            if ("com.discordtools.app.GO".equals(act)) {
                pendingGo = in.getStringExtra("go");
            } else if (Intent.ACTION_SEND.equals(act) || Intent.ACTION_SEND_MULTIPLE.equals(act)) {
                String t = in.getStringExtra(Intent.EXTRA_TEXT);
                if (t != null) pendingText = t;
                ArrayList<Uri> uris = new ArrayList<Uri>();
                if (Intent.ACTION_SEND.equals(act)) {
                    Uri one = in.getParcelableExtra(Intent.EXTRA_STREAM);
                    if (one != null) uris.add(one);
                } else {
                    ArrayList<Uri> l = in.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                    if (l != null) uris.addAll(l);
                }
                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists()) dir.mkdirs();
                int n = 0;
                for (Uri u : uris) {
                    if (n++ >= 10) break;
                    String mime = getContentResolver().getType(u);
                    if (mime == null) mime = "application/octet-stream";
                    String name = "file" + n;
                    Cursor c = null;
                    try {
                        c = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null);
                        if (c != null && c.moveToFirst()) name = c.getString(0);
                    } catch (Throwable ignored) {
                    } finally {
                        if (c != null) c.close();
                    }
                    String safe = n + "_" + name.replaceAll("[^A-Za-z0-9._-]", "_");
                    File out = new File(dir, safe);
                    InputStream is = getContentResolver().openInputStream(u);
                    if (is == null) continue;
                    java.io.FileOutputStream fo = new java.io.FileOutputStream(out);
                    byte[] buf = new byte[16384];
                    int r;
                    while ((r = is.read(buf)) > 0) fo.write(buf, 0, r);
                    fo.close();
                    is.close();
                    pendingFiles.add(new String[]{safe, name, mime});
                }
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILES) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_MEDIA || requestCode == REQ_MIC) {
            boolean ok = false;
            if (grantResults != null) {
                for (int g : grantResults) {
                    if (g == PackageManager.PERMISSION_GRANTED) ok = true;
                }
            }
            if (requestCode == REQ_MIC) {
                ok = grantResults != null && grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            }
            final String id = permCallbackId;
            permCallbackId = null;
            if (id != null && web != null) {
                web.evaluateJavascript("window.__permResp(" + JSONObject.quote(id) + ","
                        + (ok ? "true" : "false") + ")", null);
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onPause() {
        stopRecording(true);
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__back ? window.__back() : false)", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if (!"true".equals(v)) {
                    if (prefs.getBoolean("svc_on", false)) moveTaskToBack(true);
                    else finish();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        pool.shutdownNow();
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }

    private void openExternal(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    private static boolean hostAllowed(String host) {
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT);
        String[] roots = {"discord.com", "discordapp.com", "discordapp.net"};
        for (String r : roots) {
            if (host.equals(r) || host.endsWith("." + r)) return true;
        }
        return false;
    }

    private void deliver(final String id, final String resp) {
        final String js = "window.__nativeResp(" + JSONObject.quote(id) + ","
                + JSONObject.quote(resp) + ")";
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) {
                    web.evaluateJavascript(js, null);
                }
            }
        });
    }

    private String doRequest(String json) {
        JSONObject out = new JSONObject();
        try {
            JSONObject r = new JSONObject(json);
            String method = r.optString("method", "GET").toUpperCase(Locale.ROOT);
            String url = r.getString("url");
            Uri u = Uri.parse(url);
            if (!"https".equals(u.getScheme()) || !hostAllowed(u.getHost())) {
                out.put("status", 0);
                out.put("error", "blocked host: " + u.getHost());
                return out.toString();
            }

            Request.Builder rb = new Request.Builder().url(url);
            rb.header("User-Agent", UA);
            JSONObject headers = r.optJSONObject("headers");
            if (headers != null) {
                JSONArray names = headers.names();
                if (names != null) {
                    for (int i = 0; i < names.length(); i++) {
                        String k = names.getString(i);
                        rb.header(k, headers.getString(k));
                    }
                }
            }

            RequestBody body = null;
            JSONObject mp = r.optJSONObject("multipart");
            if (mp != null) {
                MultipartBody.Builder mb = new MultipartBody.Builder().setType(MultipartBody.FORM);
                String payload = mp.optString("payload", "{}");
                mb.addFormDataPart("payload_json", null,
                        RequestBody.create(payload.getBytes("UTF-8"),
                                MediaType.parse("application/json; charset=utf-8")));
                JSONArray files = mp.optJSONArray("files");
                if (files != null) {
                    for (int i = 0; i < files.length(); i++) {
                        JSONObject f = files.getJSONObject(i);
                        byte[] bytes = Base64.decode(f.getString("b64"), Base64.DEFAULT);
                        String ct = f.optString("type", "application/octet-stream");
                        if (ct.length() == 0) ct = "application/octet-stream";
                        MediaType mt = MediaType.parse(ct);
                        if (mt == null) mt = MediaType.parse("application/octet-stream");
                        mb.addFormDataPart("files[" + i + "]", f.optString("name", "file" + i),
                                RequestBody.create(bytes, mt));
                    }
                }
                body = mb.build();
            } else if (r.has("body") && !r.isNull("body")) {
                String ct = r.optString("contentType", "application/json");
                body = RequestBody.create(r.getString("body").getBytes("UTF-8"),
                        MediaType.parse(ct + "; charset=utf-8"));
            }

            boolean needsBody = method.equals("POST") || method.equals("PUT") || method.equals("PATCH");
            if (needsBody && body == null) {
                body = RequestBody.create(new byte[0], null);
            }
            if (method.equals("GET") || method.equals("HEAD")) {
                body = null;
            }
            rb.method(method, body);

            Response resp = client.newCall(rb.build()).execute();
            try {
                byte[] bytes = resp.body() != null ? resp.body().bytes() : new byte[0];
                out.put("status", resp.code());
                String ra = resp.header("Retry-After");
                if (ra != null) out.put("retryAfter", ra);
                String ct = resp.header("Content-Type");
                if (ct != null) out.put("contentType", ct);
                if (r.optBoolean("binary", false)) {
                    out.put("binary", true);
                    out.put("body", Base64.encodeToString(bytes, Base64.NO_WRAP));
                } else {
                    out.put("body", new String(bytes, "UTF-8"));
                }
            } finally {
                resp.close();
            }
        } catch (Throwable t) {
            try {
                out = new JSONObject();
                out.put("status", 0);
                out.put("error", String.valueOf(t.getMessage() != null ? t.getMessage() : t));
            } catch (Exception ignored) {
            }
        }
        return out.toString();
    }

    /* ---------------- media (photos / videos) ---------------- */

    private boolean hasMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            boolean img = checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES)
                    == PackageManager.PERMISSION_GRANTED;
            if (img) return true;
            if (Build.VERSION.SDK_INT >= 34) {
                return checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
                        == PackageManager.PERMISSION_GRANTED;
            }
            return false;
        }
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    private Uri mediaUri(boolean video, long id) {
        Uri base = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        return ContentUris.withAppendedId(base, id);
    }

    private String listMediaJson(int offset, int limit) {
        JSONArray arr = new JSONArray();
        if (!hasMediaPermission()) return arr.toString();
        Cursor c = null;
        try {
            String[] proj = {
                    MediaStore.Files.FileColumns._ID,
                    MediaStore.Files.FileColumns.MEDIA_TYPE,
                    MediaStore.Files.FileColumns.MIME_TYPE,
                    MediaStore.Files.FileColumns.DISPLAY_NAME,
                    MediaStore.Files.FileColumns.SIZE
            };
            String sel = MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                    + MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE + " OR "
                    + MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                    + MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;
            c = getContentResolver().query(MediaStore.Files.getContentUri("external"), proj, sel, null,
                    MediaStore.Files.FileColumns.DATE_ADDED + " DESC");
            if (c != null && c.moveToPosition(offset)) {
                int n = 0;
                do {
                    JSONObject o = new JSONObject();
                    o.put("id", c.getLong(0));
                    o.put("video", c.getInt(1) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO);
                    o.put("mime", c.getString(2) == null ? "" : c.getString(2));
                    o.put("name", c.getString(3) == null ? "media" : c.getString(3));
                    o.put("size", c.getLong(4));
                    arr.put(o);
                    n++;
                } while (n < limit && c.moveToNext());
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) c.close();
        }
        return arr.toString();
    }

    private WebResourceResponse serveMedia(Uri u) {
        Map<String, String> headers = new HashMap<String, String>();
        headers.put("Access-Control-Allow-Origin", "*");
        try {
            java.util.List<String> seg = u.getPathSegments();
            if (seg.size() == 3 && ("t".equals(seg.get(0)) || "f".equals(seg.get(0)))) {
                boolean thumb = "t".equals(seg.get(0));
                boolean video = "v".equals(seg.get(1));
                long id = Long.parseLong(seg.get(2));
                if (!hasMediaPermission()) return notFound(headers);
                Uri uri = mediaUri(video, id);
                if (thumb) {
                    Bitmap bm = null;
                    if (Build.VERSION.SDK_INT >= 29) {
                        bm = getContentResolver().loadThumbnail(uri, new Size(320, 320), null);
                    } else if (video) {
                        bm = MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), id,
                                MediaStore.Video.Thumbnails.MINI_KIND, null);
                    } else {
                        bm = MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), id,
                                MediaStore.Images.Thumbnails.MINI_KIND, null);
                    }
                    if (bm == null) return notFound(headers);
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    bm.compress(Bitmap.CompressFormat.JPEG, 82, bos);
                    return new WebResourceResponse("image/jpeg", null, 200, "OK", headers,
                            new ByteArrayInputStream(bos.toByteArray()));
                }
                String type = getContentResolver().getType(uri);
                if (type == null) type = "application/octet-stream";
                InputStream in = getContentResolver().openInputStream(uri);
                if (in == null) return notFound(headers);
                return new WebResourceResponse(type, null, 200, "OK", headers, in);
            }
            if (seg.size() == 2 && "s".equals(seg.get(0))) {
                File sf = new File(new File(getCacheDir(), "shared"), seg.get(1));
                if (sf.exists()) {
                    String mt = "application/octet-stream";
                    for (String[] pf : pendingFiles) if (pf[0].equals(seg.get(1))) mt = pf[2];
                    return new WebResourceResponse(mt, null, 200, "OK", headers, new FileInputStream(sf));
                }
            }
            if (seg.size() == 2 && "r".equals(seg.get(0)) && recFile != null && recFile.exists()) {
                return new WebResourceResponse("audio/ogg", null, 200, "OK", headers,
                        new FileInputStream(recFile));
            }
        } catch (Throwable ignored) {
        }
        return notFound(headers);
    }

    private WebResourceResponse notFound(Map<String, String> headers) {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", headers,
                new ByteArrayInputStream(new byte[0]));
    }

    /* ---------------- voice recording (Ogg/Opus, Android 10+) ---------------- */

    private boolean hasMicPermission() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
    }

    private String startRecording() {
        if (Build.VERSION.SDK_INT < 29) return "unsupported";
        if (!hasMicPermission()) return "permission";
        stopRecording(true);
        try {
            recFile = new File(getCacheDir(), "voice-message.ogg");
            if (recFile.exists()) recFile.delete();
            MediaRecorder r = new MediaRecorder();
            r.setAudioSource(MediaRecorder.AudioSource.MIC);
            r.setOutputFormat(MediaRecorder.OutputFormat.OGG);
            r.setAudioEncoder(MediaRecorder.AudioEncoder.OPUS);
            r.setAudioChannels(1);
            r.setAudioSamplingRate(48000);
            r.setAudioEncodingBitRate(32000);
            r.setOutputFile(recFile.getAbsolutePath());
            r.prepare();
            r.start();
            recorder = r;
            recStart = System.currentTimeMillis();
            amps.clear();
            uiHandler.postDelayed(ampTick, 100);
            return "ok";
        } catch (Throwable t) {
            recorder = null;
            return "error";
        }
    }

    private String stopRecording(boolean cancel) {
        JSONObject out = new JSONObject();
        try {
            if (recorder == null) {
                out.put("ok", false);
                return out.toString();
            }
            uiHandler.removeCallbacks(ampTick);
            long dur = System.currentTimeMillis() - recStart;
            boolean ok = true;
            try {
                recorder.stop();
            } catch (RuntimeException e) {
                ok = false;
            }
            recorder.release();
            recorder = null;
            if (cancel || !ok) {
                if (recFile != null) recFile.delete();
                out.put("ok", false);
                return out.toString();
            }
            int n = amps.size();
            int buckets = Math.max(1, Math.min(256, n));
            int maxAmp = 1;
            for (int a : amps) {
                if (a > maxAmp) maxAmp = a;
            }
            byte[] wf = new byte[buckets];
            for (int i = 0; i < buckets; i++) {
                int from = n == 0 ? 0 : (int) ((long) i * n / buckets);
                int to = n == 0 ? 0 : Math.max(from + 1, (int) ((long) (i + 1) * n / buckets));
                int sum = 0;
                int cnt = 0;
                for (int j = from; j < to && j < n; j++) {
                    sum += amps.get(j);
                    cnt++;
                }
                int avg = cnt == 0 ? 0 : sum / cnt;
                wf[i] = (byte) Math.min(255, (int) (avg * 255L / maxAmp));
            }
            out.put("ok", true);
            out.put("duration", dur / 1000.0);
            out.put("waveform", Base64.encodeToString(wf, Base64.NO_WRAP));
            out.put("size", recFile.length());
        } catch (Throwable t) {
            try {
                out = new JSONObject();
                out.put("ok", false);
            } catch (Exception ignored) {
            }
        }
        return out.toString();
    }

    private class Bridge {
        @JavascriptInterface
        public void request(final String id, final String json) {
            pool.execute(new Runnable() {
                @Override
                public void run() {
                    deliver(id, doRequest(json));
                }
            });
        }

        @JavascriptInterface
        public boolean serviceOn() {
            return prefs.getBoolean("svc_on", false);
        }

        @JavascriptInterface
        public void serviceSet(final boolean on) {
            prefs.edit().putBoolean("svc_on", on).apply();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent si = new Intent(MainActivity.this, KeepAliveService.class);
                        if (on) {
                            if (Build.VERSION.SDK_INT >= 33
                                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1010);
                            }
                            if (Build.VERSION.SDK_INT >= 26) startForegroundService(si);
                            else startService(si);
                        } else {
                            stopService(si);
                        }
                    } catch (Throwable ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void notify(final String title, final String text) {
            KeepAliveService.notifyUser(MainActivity.this, title, text);
        }

        @JavascriptInterface
        public String takeShared() {
            JSONObject o = new JSONObject();
            try {
                if (pendingText != null) o.put("text", pendingText);
                if (pendingGo != null) o.put("go", pendingGo);
                JSONArray fa = new JSONArray();
                for (String[] f : pendingFiles) {
                    JSONObject fo = new JSONObject();
                    fo.put("url", "https://" + MEDIA_HOST + "/s/" + f[0]);
                    fo.put("name", f[1]);
                    fo.put("type", f[2]);
                    fa.put(fo);
                }
                if (fa.length() > 0) o.put("files", fa);
            } catch (Throwable ignored) { }
            pendingText = null;
            pendingGo = null;
            return o.toString();
        }

        @JavascriptInterface
        public void haptic(final String kind) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        int c = "ok".equals(kind) ? HapticFeedbackConstants.CONFIRM : "bad".equals(kind) ? HapticFeedbackConstants.REJECT : HapticFeedbackConstants.KEYBOARD_TAP;
                        if (android.os.Build.VERSION.SDK_INT < 30 && !"tap".equals(kind)) c = HapticFeedbackConstants.LONG_PRESS;
                        web.performHapticFeedback(c);
                    } catch (Throwable ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void setBars(final String hex, final boolean light) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        int col = Color.parseColor(hex);
                        Window w = getWindow();
                        w.setStatusBarColor(col);
                        w.setNavigationBarColor(col);
                        if (rootView != null) rootView.setBackgroundColor(col);
                        if (web != null) web.setBackgroundColor(col);
                        View d = w.getDecorView();
                        int f = d.getSystemUiVisibility();
                        if (light) f |= (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | (android.os.Build.VERSION.SDK_INT >= 26 ? View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0));
                        else f &= ~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | (android.os.Build.VERSION.SDK_INT >= 26 ? View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0));
                        d.setSystemUiVisibility(f);
                    } catch (Throwable ignored) { }
                }
            });
        }

        @JavascriptInterface
        public String storeGet(String k) {
            return prefs.getString(k, null);
        }

        @JavascriptInterface
        public void storeSet(String k, String v) {
            prefs.edit().putString(k, v).apply();
        }

        @JavascriptInterface
        public void storeDel(String k) {
            prefs.edit().remove(k).apply();
        }

        @JavascriptInterface
        public String storeKeys() {
            JSONArray a = new JSONArray();
            for (String k : prefs.getAll().keySet()) if (!"svc_on".equals(k)) a.put(k);
            return a.toString();
        }

        @JavascriptInterface
        public void storeClear() {
            prefs.edit().clear().apply();
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText("Discord Tools", text));
                    }
                }
            });
        }

        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "Share"));
                }
            });
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            if (url == null) return;
            if (!(url.startsWith("https://") || url.startsWith("http://"))) return;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openExternal(url);
                }
            });
        }

        @JavascriptInterface
        public boolean hasMedia() {
            return hasMediaPermission();
        }

        @JavascriptInterface
        public void askMedia(final String id) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    permCallbackId = id;
                    if (Build.VERSION.SDK_INT >= 34) {
                        requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES,
                                Manifest.permission.READ_MEDIA_VIDEO,
                                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED}, REQ_MEDIA);
                    } else if (Build.VERSION.SDK_INT >= 33) {
                        requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES,
                                Manifest.permission.READ_MEDIA_VIDEO}, REQ_MEDIA);
                    } else {
                        requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_MEDIA);
                    }
                }
            });
        }

        @JavascriptInterface
        public String listMedia(int offset, int limit) {
            return listMediaJson(offset, limit);
        }

        @JavascriptInterface
        public boolean hasMic() {
            return hasMicPermission();
        }

        @JavascriptInterface
        public void askMic(final String id) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    permCallbackId = id;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                }
            });
        }

        @JavascriptInterface
        public String recStart() {
            return startRecording();
        }

        @JavascriptInterface
        public String recStop(boolean cancel) {
            return stopRecording(cancel);
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}

package com.discordtools.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/** Foreground service: keeps the process alive and sends due scheduled messages natively. */
public class KeepAliveService extends Service {
    static final String CH = "dt_keep";
    static final String CH_ALERT = "dt_alert";
    static final int NID = 71;
    private HandlerThread thread;
    private Handler h;
    private PowerManager.WakeLock lock;
    private SharedPreferences prefs;
    private final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build();
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            try { process(); } catch (Throwable ignored) { }
            if (h != null) h.postDelayed(this, 15000);
        }
    };

    static void ensureChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel a = new NotificationChannel(CH, "Background service", NotificationManager.IMPORTANCE_MIN);
        a.setShowBadge(false);
        nm.createNotificationChannel(a);
        NotificationChannel b = new NotificationChannel(CH_ALERT, "Alerts", NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(b);
    }

    static void notifyUser(Context c, String title, String text) {
        try {
            ensureChannels(c);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            Intent i = new Intent(c, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH_ALERT) : new Notification.Builder(c);
            b.setSmallIcon(android.R.drawable.stat_notify_chat).setContentTitle(title).setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(pi);
            nm.notify((int) (System.currentTimeMillis() % 100000) + 100, b.build());
        } catch (Throwable ignored) { }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("dt_store", MODE_PRIVATE);
        ensureChannels(this);
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.stat_notify_sync_noanim).setContentTitle("Discord Tools")
                .setContentText("يعمل في الخلفية").setOngoing(true).setContentIntent(pi);
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NID, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NID, b.build());
        }
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "discordtools:keep");
            lock.setReferenceCounted(false);
            lock.acquire();
        } catch (Throwable ignored) { }
        thread = new HandlerThread("dt-keep");
        thread.start();
        h = new Handler(thread.getLooper());
        h.postDelayed(tick, 3000);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (h != null) h.removeCallbacksAndMessages(null);
        if (thread != null) thread.quitSafely();
        try { if (lock != null && lock.isHeld()) lock.release(); } catch (Throwable ignored) { }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private synchronized void process() throws Exception {
        String raw = prefs.getString("sched", null);
        if (raw == null) return;
        JSONArray arr = new JSONArray(raw);
        long now = System.currentTimeMillis();
        boolean changed = false;
        JSONArray out = new JSONArray();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject it = arr.getJSONObject(i);
            if (it.optLong("at", Long.MAX_VALUE) <= now && it.optString("err", "").length() == 0) {
                String err = send(it);
                changed = true;
                if (err == null) {
                    notifyUser(this, "أُرسلت رسالة مجدولة", it.optString("label", ""));
                    continue;
                }
                it.put("err", err);
                notifyUser(this, "فشلت رسالة مجدولة", err);
            }
            out.put(it);
        }
        if (changed) {
            // re-read to avoid clobbering items added meanwhile by the UI
            String cur = prefs.getString("sched", null);
            if (cur != null && !cur.equals(raw)) {
                JSONArray now2 = new JSONArray(cur);
                for (int i = 0; i < now2.length(); i++) {
                    JSONObject x = now2.getJSONObject(i);
                    boolean known = false;
                    for (int j = 0; j < arr.length(); j++) if (arr.getJSONObject(j).optString("id").equals(x.optString("id"))) known = true;
                    if (!known) out.put(x);
                }
            }
            prefs.edit().putString("sched", out.toString()).commit();
        }
    }

    /** returns null on success, otherwise an error text */
    private String send(JSONObject it) {
        try {
            JSONObject d = it.getJSONObject("dest");
            String url;
            Request.Builder rb = new Request.Builder().header("User-Agent", "DiscordBot (https://discordtools.local, 2.0)");
            if ("webhook".equals(d.optString("mode"))) {
                url = "https://discord.com/api/v10/webhooks/" + d.getString("id") + "/" + d.getString("token") + "?wait=true";
                JSONObject q = it.optJSONObject("query");
                if (q != null && q.has("thread_id")) url += "&thread_id=" + q.getString("thread_id");
                if (q != null && q.has("with_components")) url += "&with_components=true";
            } else {
                url = "https://discord.com/api/v10/channels/" + d.getString("channelId") + "/messages";
                String t = d.optString("botToken", "");
                if (t.length() == 0) return "لا يوجد توكن";
                rb.header("Authorization", t.startsWith("Bot ") ? t : "Bot " + t);
            }
            RequestBody body = RequestBody.create(it.getJSONObject("payload").toString().getBytes("UTF-8"),
                    MediaType.parse("application/json; charset=utf-8"));
            try (Response r = client.newCall(rb.url(url).post(body).build()).execute()) {
                if (r.isSuccessful()) return null;
                String b = r.body() != null ? r.body().string() : "";
                return "HTTP " + r.code() + (b.length() > 120 ? " " + b.substring(0, 120) : " " + b);
            }
        } catch (Throwable e) {
            return String.valueOf(e.getMessage());
        }
    }
}
